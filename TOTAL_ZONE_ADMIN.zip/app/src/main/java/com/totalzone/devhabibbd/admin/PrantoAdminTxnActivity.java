package com.totalzone.devhabibbd.admin;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.google.firebase.FirebaseApp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class PrantoAdminTxnActivity extends AppCompatActivity {
	
	private HashMap<String, Object> mapU1 = new HashMap<>();
	private String Save = "";
	private double Frame = 0;
	private double Bye = 0;
	private HashMap<String, Object> IM_PRANTO = new HashMap<>();
	private HashMap<String, Object> admin = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> adminTxn = new ArrayList<>();
	
	private LinearLayout BG;
	private LinearLayout linear3;
	private LinearLayout BG1;
	private ImageView imageview1;
	private TextView textview3;
	private LinearLayout BOX1;
	private TextView textview1;
	private RecyclerView TrxView;
	private LinearLayout LiadingBg;
	private ImageView imageview4;
	private EditText E1;
	private ProgressBar prog;
	
	private RequestNetwork Admin_Txn;
	private RequestNetwork.RequestListener _Admin_Txn_request_listener;
	private SharedPreferences Auth;
	private SharedPreferences app_infos;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.pranto_admin_txn);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		BG = findViewById(R.id.BG);
		linear3 = findViewById(R.id.linear3);
		BG1 = findViewById(R.id.BG1);
		imageview1 = findViewById(R.id.imageview1);
		textview3 = findViewById(R.id.textview3);
		BOX1 = findViewById(R.id.BOX1);
		textview1 = findViewById(R.id.textview1);
		TrxView = findViewById(R.id.TrxView);
		LiadingBg = findViewById(R.id.LiadingBg);
		imageview4 = findViewById(R.id.imageview4);
		E1 = findViewById(R.id.E1);
		prog = findViewById(R.id.prog);
		Admin_Txn = new RequestNetwork(this);
		Auth = getSharedPreferences("Auth", Activity.MODE_PRIVATE);
		app_infos = getSharedPreferences("app_infos", Activity.MODE_PRIVATE);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
				overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
			}
		});
		
		E1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				adminTxn = new Gson().fromJson(Save, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				if (_charSeq.length() > 0) {
					Frame = adminTxn.size() - 1;
					Bye = adminTxn.size();
					for(int _repeat21 = 0; _repeat21 < (int)(Bye); _repeat21++) {
						if (adminTxn.get((int)Frame).get("admin_id").toString().toLowerCase().contains(_charSeq.toLowerCase())) {
							
						} else {
							adminTxn.remove((int)(Frame));
							TrxView.setAdapter(new TrxViewAdapter(adminTxn));
						}
						Frame--;
					}
				}
				TrxView.setAdapter(new TrxViewAdapter(adminTxn));
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		_Admin_Txn_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				LiadingBg.setVisibility(View.GONE);
				mapU1.clear();
				adminTxn.clear();
				try {
					try {
							JSONArray Array1 = new JSONArray(_response);
							for (int Ps1 = 0; Ps1 < Array1.length(); Ps1++) {
									JSONObject PRANTO1 = Array1.getJSONObject(Ps1);
									try { 
								mapU1 = new HashMap<>();
								mapU1.put("id", PRANTO1.getString("id"));
								mapU1.put("admin_id", PRANTO1.getString("admin_id"));
								mapU1.put("title", PRANTO1.getString("title"));
								mapU1.put("description", PRANTO1.getString("description"));
								mapU1.put("date", PRANTO1.getString("date"));
								adminTxn.add(mapU1);
								Save = new Gson().toJson(adminTxn);
								TrxView.setAdapter(new TrxViewAdapter(adminTxn));
							}catch(Exception ex){ex.printStackTrace();}
							}
					} catch (JSONException e) {
							e.printStackTrace();
					}
				} catch (Exception e) {
					
				}
				if (adminTxn.size() == 0) {
					TrxView.setVisibility(View.GONE);
				} else {
					TrxView.setVisibility(View.VISIBLE);
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
			Window w =PrantoAdminTxnActivity.this.getWindow();
			w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFF000000);
		}
		TrxView.setLayoutManager(new LinearLayoutManager(this));
		LiadingBg.setVisibility(View.VISIBLE);
		TrxView.setVisibility(View.GONE);
		BOX1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		new java.util.Timer().schedule(new java.util.TimerTask() {
			    @Override
			    public void run() {
				        
				if (vpn()) {
				} else {
					IM_PRANTO = new HashMap<>();
					admin = new HashMap<>();
					admin.put("type", "all");
					admin.put("email", Auth.getString("Email", ""));
					admin.put("session_id", Auth.getString("Session_id", ""));
					IM_PRANTO.put("X-IM-PRANTO", (new Object() {
						   int t;
						   public String toString() {
							      byte[] buf = new byte[22];
							      t = 5242880;
							      buf[0] = (byte) (t >>> 16);
							      t = 116736;
							      buf[1] = (byte) (t >>> 10);
							      t = 12713984;
							      buf[2] = (byte) (t >>> 17);
							      t = 28835840;
							      buf[3] = (byte) (t >>> 18);
							      t = 30408704;
							      buf[4] = (byte) (t >>> 18);
							      t = 56832;
							      buf[5] = (byte) (t >>> 9);
							      t = 3112960;
							      buf[6] = (byte) (t >>> 15);
							      t = 104857600;
							      buf[7] = (byte) (t >>> 21);
							      t = 100663296;
							      buf[8] = (byte) (t >>> 21);
							      t = 6291456;
							      buf[9] = (byte) (t >>> 17);
							      t = 230686720;
							      buf[10] = (byte) (t >>> 22);
							      t = 24320;
							      buf[11] = (byte) (t >>> 8);
							      t = 4928;
							      buf[12] = (byte) (t >>> 6);
							      t = 199229440;
							      buf[13] = (byte) (t >>> 21);
							      t = 1359872;
							      buf[14] = (byte) (t >>> 14);
							      t = 105906176;
							      buf[15] = (byte) (t >>> 20);
							      t = 25952256;
							      buf[16] = (byte) (t >>> 18);
							      t = 245366784;
							      buf[17] = (byte) (t >>> 21);
							      t = 478150656;
							      buf[18] = (byte) (t >>> 22);
							      t = 880803840;
							      buf[19] = (byte) (t >>> 23);
							      t = 14848;
							      buf[20] = (byte) (t >>> 7);
							      t = 7929856;
							      buf[21] = (byte) (t >>> 16);
							      return new String(buf);
							   }
					}.toString()));
					Admin_Txn.setHeaders(IM_PRANTO);
					Admin_Txn.setParams(admin, RequestNetworkController.REQUEST_PARAM);
					Admin_Txn.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("admin_trx.php"), "", _Admin_Txn_request_listener);
					admin.clear();
					IM_PRANTO.clear();
				}
				
				    }
		}, 50);
	}
	
	@Override
	public void onBackPressed() {
		finish();
		overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
	}
	public void _vpn() {
	}
	public boolean vpn() {
		    String iface = "";
		    try {
			        for (java.net.NetworkInterface networkInterface : Collections.list(java.net.NetworkInterface.getNetworkInterfaces())) {
				            if (networkInterface.isUp())
				                iface = networkInterface.getName();
				                Log.d("DEBUG", "IFACE NAME: " + iface);
				            if ( iface.contains("tun") || iface.contains("ppp") || iface.contains("pptp")) {
					                return true;
					            }
				        }
			    } catch (Exception e1) {
			        e1.printStackTrace();
			    }
		
		    return false;
	}
	{
	}
	
	public class TrxViewAdapter extends RecyclerView.Adapter<TrxViewAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public TrxViewAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.admin_trx, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout BG1 = _view.findViewById(R.id.BG1);
			final LinearLayout div = _view.findViewById(R.id.div);
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final TextView descriptionTv = _view.findViewById(R.id.descriptionTv);
			final TextView admin_id = _view.findViewById(R.id.admin_id);
			final TextView dateTv = _view.findViewById(R.id.dateTv);
			final TextView Tv1 = _view.findViewById(R.id.Tv1);
			
			Tv1.setText(_data.get((int)_position).get("title").toString());
			descriptionTv.setText(_data.get((int)_position).get("description").toString());
			dateTv.setText(_data.get((int)_position).get("date").toString());
			admin_id.setText("Admin ID : #".concat(String.valueOf((long)(Double.parseDouble(_data.get((int)_position).get("admin_id").toString())))));
			if (_position < (_data.size() - 1)) {
				div.setVisibility(View.VISIBLE);
			} else {
				div.setVisibility(View.GONE);
			}
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}
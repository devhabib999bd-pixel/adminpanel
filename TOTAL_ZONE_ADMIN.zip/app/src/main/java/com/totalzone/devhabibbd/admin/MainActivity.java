package com.totalzone.devhabibbd.admin;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessaging;
import com.totalzone.devhabibbd.admin.CustomLoaderView;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import android.content.pm.PackageManager;
import androidx.appcompat.app.AppCompatActivity;
import android.provider.Settings;
import android.Manifest;
import android.net.Uri;

public class MainActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private LinearLayout BG;
	private LinearLayout linear2;
	private FrameLayout glowLayout;
	private LinearLayout linear3;
	private TextView textview1;
	private TextView textview2;
	private CustomLoaderView customLoader;
	private LinearLayout linear1;
	private TextView textview3;
	private ImageView ICON;
	
	private SharedPreferences app_infos;
	private RequestNetwork WiFi;
	private RequestNetwork.RequestListener _WiFi_request_listener;
	private Intent New_Activity = new Intent();
	private SharedPreferences Auth;
	private TimerTask Timee;
	
	private OnCompleteListener FCM_onCompleteListener;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		BG = findViewById(R.id.BG);
		linear2 = findViewById(R.id.linear2);
		glowLayout = findViewById(R.id.glowLayout);
		linear3 = findViewById(R.id.linear3);
		textview1 = findViewById(R.id.textview1);
		textview2 = findViewById(R.id.textview2);
		customLoader = findViewById(R.id.customLoader);
		linear1 = findViewById(R.id.linear1);
		textview3 = findViewById(R.id.textview3);
		ICON = findViewById(R.id.ICON);
		app_infos = getSharedPreferences("app_infos", Activity.MODE_PRIVATE);
		WiFi = new RequestNetwork(this);
		Auth = getSharedPreferences("Auth", Activity.MODE_PRIVATE);
		auth = FirebaseAuth.getInstance();
		
		_WiFi_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				Timee = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								textview2.setText("Loading app data...");
							}
						});
					}
				};
				_timer.schedule(Timee, (int)(500));
				Timee = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								textview2.setText("Processing result...");
							}
						});
					}
				};
				_timer.schedule(Timee, (int)(2000));
				Timee = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								if (Auth.contains("Login")) {
									New_Activity.setClass(getApplicationContext(), PrantoHomeActivity.class);
									startActivity(New_Activity);
									overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
								} else {
									New_Activity.setClass(getApplicationContext(), PrantoLoginActivity.class);
									startActivity(New_Activity);
									overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
								}
							}
						});
					}
				};
				_timer.schedule(Timee, (int)(2500));
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				Timee = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								New_Activity.setClass(getApplicationContext(), PrantoNonetworkActivity.class);
								startActivity(New_Activity);
								overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
							}
						});
					}
				};
				_timer.schedule(Timee, (int)(2500));
			}
		};
		
		FCM_onCompleteListener = new OnCompleteListener<InstanceIdResult>() {
			@Override
			public void onComplete(Task<InstanceIdResult> task) {
				final boolean _success = task.isSuccessful();
				final String _token = task.getResult().getToken();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
			Window w =MainActivity.this.getWindow();
			w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFF000000);
		}
		app_infos.edit().putString("Api", "https://totalzonebd.live/totalzonebd/api/admin/").commit();
		auth.signInWithEmailAndPassword("devhabib@gmail.com", "tarip890").addOnCompleteListener(MainActivity.this, _auth_sign_in_listener);
		if (Build.VERSION.SDK_INT >= 23) {
				
				if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_DENIED) {
						requestPermissions(new String[] {android.Manifest.permission.POST_NOTIFICATIONS}, 1111);
				}else {
							  
				}
		}else {	
				 
		}
		if (SketchwareUtil.isConnected(getApplicationContext())) {
				    FirebaseMessaging.getInstance().subscribeToTopic("Admin").addOnCompleteListener(new OnCompleteListener<Void>() {
						        @Override
						        public void onComplete(@NonNull Task<Void> task) {
								            if (task.isSuccessful()) {
										                
										            } else {
										               
										            }
								        }
						    });
		} else {
				   
		}
		_Permission();
	}
	
	@Override
	public void onBackPressed() {
		finishAffinity();
	}
	
	@Override
	public void onStart() {
		super.onStart();
		WiFi.startRequestNetwork(RequestNetworkController.GET, "https://www.google.com", "Pranto", _WiFi_request_listener);
	}
	
	public void _Permission() {
		if (androidx.core.content.ContextCompat.checkSelfPermission(
		        this, 
		        android.Manifest.permission.POST_NOTIFICATIONS
		    ) == android.content.pm.PackageManager.PERMISSION_DENIED) {
			
			    androidx.core.app.ActivityCompat.requestPermissions(
			        this,
			        new String[]{android.Manifest.permission.POST_NOTIFICATIONS},
			        1001
			    );
		}
		app_infos.edit().putString((new Object() {
			   int t;
			   public String toString() {
				      byte[] buf = new byte[17];
				      t = 1622016;
				      buf[0] = (byte) (t >>> 14);
				      t = 3648;
				      buf[1] = (byte) (t >>> 5);
				      t = 6208;
				      buf[2] = (byte) (t >>> 6);
				      t = 127926272;
				      buf[3] = (byte) (t >>> 20);
				      t = 495616;
				      buf[4] = (byte) (t >>> 12);
				      t = 12160;
				      buf[5] = (byte) (t >>> 7);
				      t = 3712;
				      buf[6] = (byte) (t >>> 5);
				      t = 28416;
				      buf[7] = (byte) (t >>> 8);
				      t = 30670848;
				      buf[8] = (byte) (t >>> 18);
				      t = 29884416;
				      buf[9] = (byte) (t >>> 18);
				      t = 796917760;
				      buf[10] = (byte) (t >>> 23);
				      t = 114688;
				      buf[11] = (byte) (t >>> 10);
				      t = 29884416;
				      buf[12] = (byte) (t >>> 18);
				      t = 909312;
				      buf[13] = (byte) (t >>> 13);
				      t = 389120;
				      buf[14] = (byte) (t >>> 12);
				      t = 220200960;
				      buf[15] = (byte) (t >>> 21);
				      t = 104857600;
				      buf[16] = (byte) (t >>> 20);
				      return new String(buf);
				   }
		}.toString()), (new Object() {
			   int t;
			   public String toString() {
				      byte[] buf = new byte[14];
				      t = 12976128;
				      buf[0] = (byte) (t >>> 17);
				      t = 58368;
				      buf[1] = (byte) (t >>> 9);
				      t = 12713984;
				      buf[2] = (byte) (t >>> 17);
				      t = 7995392;
				      buf[3] = (byte) (t >>> 16);
				      t = 15335424;
				      buf[4] = (byte) (t >>> 17);
				      t = 5898240;
				      buf[5] = (byte) (t >>> 17);
				      t = 486539264;
				      buf[6] = (byte) (t >>> 22);
				      t = 58195968;
				      buf[7] = (byte) (t >>> 19);
				      t = 239616;
				      buf[8] = (byte) (t >>> 11);
				      t = 233472;
				      buf[9] = (byte) (t >>> 11);
				      t = 2949120;
				      buf[10] = (byte) (t >>> 16);
				      t = 229376;
				      buf[11] = (byte) (t >>> 11);
				      t = 466944;
				      buf[12] = (byte) (t >>> 12);
				      t = 227328;
				      buf[13] = (byte) (t >>> 11);
				      return new String(buf);
				   }
		}.toString())).commit();
		app_infos.edit().putString((new Object() {
			   int t;
			   public String toString() {
				      byte[] buf = new byte[17];
				      t = 120586240;
				      buf[0] = (byte) (t >>> 20);
				      t = 3309568;
				      buf[1] = (byte) (t >>> 15);
				      t = 415236096;
				      buf[2] = (byte) (t >>> 22);
				      t = 14942208;
				      buf[3] = (byte) (t >>> 17);
				      t = 423624704;
				      buf[4] = (byte) (t >>> 22);
				      t = 60817408;
				      buf[5] = (byte) (t >>> 19);
				      t = 3112960;
				      buf[6] = (byte) (t >>> 15);
				      t = 3424;
				      buf[7] = (byte) (t >>> 5);
				      t = 103424;
				      buf[8] = (byte) (t >>> 10);
				      t = 495616;
				      buf[9] = (byte) (t >>> 12);
				      t = 194560;
				      buf[10] = (byte) (t >>> 11);
				      t = 458752;
				      buf[11] = (byte) (t >>> 12);
				      t = 14942208;
				      buf[12] = (byte) (t >>> 17);
				      t = 25427968;
				      buf[13] = (byte) (t >>> 18);
				      t = 230686720;
				      buf[14] = (byte) (t >>> 21);
				      t = 486539264;
				      buf[15] = (byte) (t >>> 22);
				      t = 29097984;
				      buf[16] = (byte) (t >>> 18);
				      return new String(buf);
				   }
		}.toString()), (new Object() {
			   int t;
			   public String toString() {
				      byte[] buf = new byte[28];
				      t = 1835008;
				      buf[0] = (byte) (t >>> 14);
				      t = 58368;
				      buf[1] = (byte) (t >>> 9);
				      t = 49664;
				      buf[2] = (byte) (t >>> 9);
				      t = 14417920;
				      buf[3] = (byte) (t >>> 17);
				      t = 14848;
				      buf[4] = (byte) (t >>> 7);
				      t = 227328;
				      buf[5] = (byte) (t >>> 11);
				      t = 97280;
				      buf[6] = (byte) (t >>> 10);
				      t = 830472192;
				      buf[7] = (byte) (t >>> 23);
				      t = 3735552;
				      buf[8] = (byte) (t >>> 15);
				      t = 6356992;
				      buf[9] = (byte) (t >>> 16);
				      t = 511705088;
				      buf[10] = (byte) (t >>> 22);
				      t = 1982464;
				      buf[11] = (byte) (t >>> 14);
				      t = 12451840;
				      buf[12] = (byte) (t >>> 17);
				      t = 7424;
				      buf[13] = (byte) (t >>> 6);
				      t = 1818624;
				      buf[14] = (byte) (t >>> 14);
				      t = 122683392;
				      buf[15] = (byte) (t >>> 20);
				      t = 116736;
				      buf[16] = (byte) (t >>> 10);
				      t = 24320;
				      buf[17] = (byte) (t >>> 8);
				      t = 3680;
				      buf[18] = (byte) (t >>> 5);
				      t = 6619136;
				      buf[19] = (byte) (t >>> 16);
				      t = 202752;
				      buf[20] = (byte) (t >>> 11);
				      t = 1867776;
				      buf[21] = (byte) (t >>> 14);
				      t = 6464;
				      buf[22] = (byte) (t >>> 6);
				      t = 475136;
				      buf[23] = (byte) (t >>> 12);
				      t = 48640;
				      buf[24] = (byte) (t >>> 9);
				      t = 56098816;
				      buf[25] = (byte) (t >>> 19);
				      t = 103424;
				      buf[26] = (byte) (t >>> 10);
				      t = 61952;
				      buf[27] = (byte) (t >>> 9);
				      return new String(buf);
				   }
		}.toString())).commit();
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}
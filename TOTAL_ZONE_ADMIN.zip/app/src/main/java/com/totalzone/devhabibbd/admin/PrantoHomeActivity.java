package com.totalzone.devhabibbd.admin;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout.OnRefreshListener;
import com.google.android.material.appbar.AppBarLayout;
import com.google.firebase.FirebaseApp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class PrantoHomeActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private DrawerLayout _drawer;
	private HashMap<String, Object> dashboard = new HashMap<>();
	private HashMap<String, Object> IM_PRANTO = new HashMap<>();
	private HashMap<String, Object> dashboardResponse = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> permission_list = new ArrayList<>();
	
	private SwipeRefreshLayout Swipe;
	private ScrollView vscroll1;
	private LinearLayout BG;
	private LinearLayout TopBar;
	private LinearLayout linear2;
	private TextView textview2;
	private LinearLayout dot1;
	private LinearLayout linear3;
	private LinearLayout linear13;
	private LinearLayout linear24;
	private LinearLayout linear35;
	private LinearLayout linear46;
	private ImageView Img1;
	private LinearLayout linear1;
	private CircleImageView circleimageview1;
	private TextView textview1;
	private LinearLayout Bg1;
	private LinearLayout Bg2;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout bg1;
	private LinearLayout linear5;
	private ImageView imageview1;
	private TextView textview3;
	private TextView userTv;
	private TextView textview6;
	private ImageView imageview2;
	private LinearLayout linear9;
	private LinearLayout linear10;
	private LinearLayout bg2;
	private LinearLayout linear12;
	private ImageView imageview3;
	private TextView textview5;
	private TextView banuserTv;
	private TextView textview7;
	private ImageView imageview4;
	private LinearLayout Bg3;
	private LinearLayout Bg4;
	private LinearLayout linear16;
	private LinearLayout linear17;
	private LinearLayout bg3;
	private LinearLayout linear19;
	private ImageView imageview5;
	private TextView textview8;
	private TextView balanceTv;
	private TextView textview10;
	private ImageView imageview6;
	private LinearLayout linear20;
	private LinearLayout linear21;
	private LinearLayout bg4;
	private LinearLayout linear23;
	private ImageView imageview7;
	private TextView textview11;
	private TextView winningTv;
	private TextView textview13;
	private ImageView imageview8;
	private LinearLayout Bg5;
	private LinearLayout Bg6;
	private LinearLayout linear27;
	private LinearLayout linear28;
	private LinearLayout bg5;
	private LinearLayout linear30;
	private ImageView imageview9;
	private TextView textview14;
	private TextView pendingDp;
	private TextView textview16;
	private ImageView imageview10;
	private LinearLayout linear31;
	private LinearLayout linear32;
	private LinearLayout bg6;
	private LinearLayout linear34;
	private ImageView imageview11;
	private TextView textview17;
	private TextView pendingWd;
	private TextView textview18;
	private ImageView imageview12;
	private LinearLayout Bg7;
	private LinearLayout B8;
	private LinearLayout linear38;
	private LinearLayout linear39;
	private LinearLayout bg7;
	private LinearLayout linear41;
	private ImageView imageview13;
	private TextView textview19;
	private TextView totalDpTv;
	private TextView textview21;
	private ImageView imageview14;
	private LinearLayout linear42;
	private LinearLayout linear43;
	private LinearLayout bg8;
	private LinearLayout linear45;
	private ImageView imageview15;
	private TextView textview22;
	private TextView totalWdTv;
	private TextView textview24;
	private ImageView imageview16;
	private LinearLayout Bg9;
	private LinearLayout Bg10;
	private LinearLayout linear49;
	private LinearLayout linear50;
	private LinearLayout bg9;
	private LinearLayout linear52;
	private ImageView imageview17;
	private TextView textview25;
	private TextView matchTv;
	private TextView textview27;
	private ImageView imageview18;
	private LinearLayout linear53;
	private LinearLayout linear54;
	private LinearLayout bg10;
	private LinearLayout linear56;
	private ImageView imageview19;
	private TextView textview28;
	private TextView categoryTv;
	private TextView textview30;
	private ImageView imageview20;
	private ScrollView _drawer_vscroll1;
	private LinearLayout _drawer_linear2;
	private CircleImageView _drawer_circleimageview1;
	private TextView _drawer_textview1;
	private LinearLayout _drawer_Bg1;
	private LinearLayout _drawer_Bg2;
	private LinearLayout _drawer_Bg3;
	private LinearLayout _drawer_Bg4;
	private LinearLayout _drawer_Bg6;
	private LinearLayout _drawer_Bg12;
	private LinearLayout _drawer_Bg7;
	private LinearLayout _drawer_Bg9;
	private LinearLayout _drawer_Bg10;
	private LinearLayout _drawer_Bg11;
	private LinearLayout _drawer_Bg13;
	private LinearLayout _drawer_nameBg;
	private ImageView _drawer_imageview1;
	private TextView _drawer_textview2;
	private ImageView _drawer_imageview2;
	private TextView _drawer_textview3;
	private ImageView _drawer_imageview3;
	private TextView _drawer_textview4;
	private ImageView _drawer_imageview4;
	private TextView _drawer_textview5;
	private ImageView _drawer_imageview6;
	private TextView _drawer_textview7;
	private ImageView _drawer_imageview12;
	private TextView _drawer_textview13;
	private ImageView _drawer_imageview7;
	private TextView _drawer_textview8;
	private ImageView _drawer_imageview9;
	private TextView _drawer_textview10;
	private ImageView _drawer_imageview11;
	private TextView _drawer_textview12;
	private ImageView _drawer_imageview10;
	private TextView _drawer_textview11;
	private ImageView _drawer_imageview13;
	private TextView _drawer_textview14;
	private LinearLayout _drawer_linear3;
	private ImageView _drawer_ligoutImg;
	private TextView _drawer_name;
	private TextView _drawer_email;
	
	private Intent New_Activity = new Intent();
	private SharedPreferences Auth;
	private TimerTask Time;
	private RequestNetwork Dashboard;
	private RequestNetwork.RequestListener _Dashboard_request_listener;
	private SharedPreferences app_infos;
	private SharedPreferences permission_data;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.pranto_home);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		_drawer = findViewById(R.id._drawer);
		ActionBarDrawerToggle _toggle = new ActionBarDrawerToggle(PrantoHomeActivity.this, _drawer, _toolbar, R.string.app_name, R.string.app_name);
		_drawer.addDrawerListener(_toggle);
		_toggle.syncState();
		
		LinearLayout _nav_view = findViewById(R.id._nav_view);
		
		Swipe = findViewById(R.id.Swipe);
		vscroll1 = findViewById(R.id.vscroll1);
		BG = findViewById(R.id.BG);
		TopBar = findViewById(R.id.TopBar);
		linear2 = findViewById(R.id.linear2);
		textview2 = findViewById(R.id.textview2);
		dot1 = findViewById(R.id.dot1);
		linear3 = findViewById(R.id.linear3);
		linear13 = findViewById(R.id.linear13);
		linear24 = findViewById(R.id.linear24);
		linear35 = findViewById(R.id.linear35);
		linear46 = findViewById(R.id.linear46);
		Img1 = findViewById(R.id.Img1);
		linear1 = findViewById(R.id.linear1);
		circleimageview1 = findViewById(R.id.circleimageview1);
		textview1 = findViewById(R.id.textview1);
		Bg1 = findViewById(R.id.Bg1);
		Bg2 = findViewById(R.id.Bg2);
		linear6 = findViewById(R.id.linear6);
		linear7 = findViewById(R.id.linear7);
		bg1 = findViewById(R.id.bg1);
		linear5 = findViewById(R.id.linear5);
		imageview1 = findViewById(R.id.imageview1);
		textview3 = findViewById(R.id.textview3);
		userTv = findViewById(R.id.userTv);
		textview6 = findViewById(R.id.textview6);
		imageview2 = findViewById(R.id.imageview2);
		linear9 = findViewById(R.id.linear9);
		linear10 = findViewById(R.id.linear10);
		bg2 = findViewById(R.id.bg2);
		linear12 = findViewById(R.id.linear12);
		imageview3 = findViewById(R.id.imageview3);
		textview5 = findViewById(R.id.textview5);
		banuserTv = findViewById(R.id.banuserTv);
		textview7 = findViewById(R.id.textview7);
		imageview4 = findViewById(R.id.imageview4);
		Bg3 = findViewById(R.id.Bg3);
		Bg4 = findViewById(R.id.Bg4);
		linear16 = findViewById(R.id.linear16);
		linear17 = findViewById(R.id.linear17);
		bg3 = findViewById(R.id.bg3);
		linear19 = findViewById(R.id.linear19);
		imageview5 = findViewById(R.id.imageview5);
		textview8 = findViewById(R.id.textview8);
		balanceTv = findViewById(R.id.balanceTv);
		textview10 = findViewById(R.id.textview10);
		imageview6 = findViewById(R.id.imageview6);
		linear20 = findViewById(R.id.linear20);
		linear21 = findViewById(R.id.linear21);
		bg4 = findViewById(R.id.bg4);
		linear23 = findViewById(R.id.linear23);
		imageview7 = findViewById(R.id.imageview7);
		textview11 = findViewById(R.id.textview11);
		winningTv = findViewById(R.id.winningTv);
		textview13 = findViewById(R.id.textview13);
		imageview8 = findViewById(R.id.imageview8);
		Bg5 = findViewById(R.id.Bg5);
		Bg6 = findViewById(R.id.Bg6);
		linear27 = findViewById(R.id.linear27);
		linear28 = findViewById(R.id.linear28);
		bg5 = findViewById(R.id.bg5);
		linear30 = findViewById(R.id.linear30);
		imageview9 = findViewById(R.id.imageview9);
		textview14 = findViewById(R.id.textview14);
		pendingDp = findViewById(R.id.pendingDp);
		textview16 = findViewById(R.id.textview16);
		imageview10 = findViewById(R.id.imageview10);
		linear31 = findViewById(R.id.linear31);
		linear32 = findViewById(R.id.linear32);
		bg6 = findViewById(R.id.bg6);
		linear34 = findViewById(R.id.linear34);
		imageview11 = findViewById(R.id.imageview11);
		textview17 = findViewById(R.id.textview17);
		pendingWd = findViewById(R.id.pendingWd);
		textview18 = findViewById(R.id.textview18);
		imageview12 = findViewById(R.id.imageview12);
		Bg7 = findViewById(R.id.Bg7);
		B8 = findViewById(R.id.B8);
		linear38 = findViewById(R.id.linear38);
		linear39 = findViewById(R.id.linear39);
		bg7 = findViewById(R.id.bg7);
		linear41 = findViewById(R.id.linear41);
		imageview13 = findViewById(R.id.imageview13);
		textview19 = findViewById(R.id.textview19);
		totalDpTv = findViewById(R.id.totalDpTv);
		textview21 = findViewById(R.id.textview21);
		imageview14 = findViewById(R.id.imageview14);
		linear42 = findViewById(R.id.linear42);
		linear43 = findViewById(R.id.linear43);
		bg8 = findViewById(R.id.bg8);
		linear45 = findViewById(R.id.linear45);
		imageview15 = findViewById(R.id.imageview15);
		textview22 = findViewById(R.id.textview22);
		totalWdTv = findViewById(R.id.totalWdTv);
		textview24 = findViewById(R.id.textview24);
		imageview16 = findViewById(R.id.imageview16);
		Bg9 = findViewById(R.id.Bg9);
		Bg10 = findViewById(R.id.Bg10);
		linear49 = findViewById(R.id.linear49);
		linear50 = findViewById(R.id.linear50);
		bg9 = findViewById(R.id.bg9);
		linear52 = findViewById(R.id.linear52);
		imageview17 = findViewById(R.id.imageview17);
		textview25 = findViewById(R.id.textview25);
		matchTv = findViewById(R.id.matchTv);
		textview27 = findViewById(R.id.textview27);
		imageview18 = findViewById(R.id.imageview18);
		linear53 = findViewById(R.id.linear53);
		linear54 = findViewById(R.id.linear54);
		bg10 = findViewById(R.id.bg10);
		linear56 = findViewById(R.id.linear56);
		imageview19 = findViewById(R.id.imageview19);
		textview28 = findViewById(R.id.textview28);
		categoryTv = findViewById(R.id.categoryTv);
		textview30 = findViewById(R.id.textview30);
		imageview20 = findViewById(R.id.imageview20);
		_drawer_vscroll1 = _nav_view.findViewById(R.id.vscroll1);
		_drawer_linear2 = _nav_view.findViewById(R.id.linear2);
		_drawer_circleimageview1 = _nav_view.findViewById(R.id.circleimageview1);
		_drawer_textview1 = _nav_view.findViewById(R.id.textview1);
		_drawer_Bg1 = _nav_view.findViewById(R.id.Bg1);
		_drawer_Bg2 = _nav_view.findViewById(R.id.Bg2);
		_drawer_Bg3 = _nav_view.findViewById(R.id.Bg3);
		_drawer_Bg4 = _nav_view.findViewById(R.id.Bg4);
		_drawer_Bg6 = _nav_view.findViewById(R.id.Bg6);
		_drawer_Bg12 = _nav_view.findViewById(R.id.Bg12);
		_drawer_Bg7 = _nav_view.findViewById(R.id.Bg7);
		_drawer_Bg9 = _nav_view.findViewById(R.id.Bg9);
		_drawer_Bg10 = _nav_view.findViewById(R.id.Bg10);
		_drawer_Bg11 = _nav_view.findViewById(R.id.Bg11);
		_drawer_Bg13 = _nav_view.findViewById(R.id.Bg13);
		_drawer_nameBg = _nav_view.findViewById(R.id.nameBg);
		_drawer_imageview1 = _nav_view.findViewById(R.id.imageview1);
		_drawer_textview2 = _nav_view.findViewById(R.id.textview2);
		_drawer_imageview2 = _nav_view.findViewById(R.id.imageview2);
		_drawer_textview3 = _nav_view.findViewById(R.id.textview3);
		_drawer_imageview3 = _nav_view.findViewById(R.id.imageview3);
		_drawer_textview4 = _nav_view.findViewById(R.id.textview4);
		_drawer_imageview4 = _nav_view.findViewById(R.id.imageview4);
		_drawer_textview5 = _nav_view.findViewById(R.id.textview5);
		_drawer_imageview6 = _nav_view.findViewById(R.id.imageview6);
		_drawer_textview7 = _nav_view.findViewById(R.id.textview7);
		_drawer_imageview12 = _nav_view.findViewById(R.id.imageview12);
		_drawer_textview13 = _nav_view.findViewById(R.id.textview13);
		_drawer_imageview7 = _nav_view.findViewById(R.id.imageview7);
		_drawer_textview8 = _nav_view.findViewById(R.id.textview8);
		_drawer_imageview9 = _nav_view.findViewById(R.id.imageview9);
		_drawer_textview10 = _nav_view.findViewById(R.id.textview10);
		_drawer_imageview11 = _nav_view.findViewById(R.id.imageview11);
		_drawer_textview12 = _nav_view.findViewById(R.id.textview12);
		_drawer_imageview10 = _nav_view.findViewById(R.id.imageview10);
		_drawer_textview11 = _nav_view.findViewById(R.id.textview11);
		_drawer_imageview13 = _nav_view.findViewById(R.id.imageview13);
		_drawer_textview14 = _nav_view.findViewById(R.id.textview14);
		_drawer_linear3 = _nav_view.findViewById(R.id.linear3);
		_drawer_ligoutImg = _nav_view.findViewById(R.id.ligoutImg);
		_drawer_name = _nav_view.findViewById(R.id.name);
		_drawer_email = _nav_view.findViewById(R.id.email);
		Auth = getSharedPreferences("Auth", Activity.MODE_PRIVATE);
		Dashboard = new RequestNetwork(this);
		app_infos = getSharedPreferences("app_infos", Activity.MODE_PRIVATE);
		permission_data = getSharedPreferences("permission_data", Activity.MODE_PRIVATE);
		
		Swipe.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
			@Override
			public void onRefresh() {
				Swipe.setRefreshing(true);
				if (vpn()) {
				} else {
					IM_PRANTO = new HashMap<>();
					dashboard = new HashMap<>();
					dashboard.put("email", Auth.getString("Email", ""));
					dashboard.put("session_id", Auth.getString("Session_id", ""));
					IM_PRANTO.put("X-IM-PRANTO", (new Object() {
						   int t;
						   public String toString() {
							      byte[] buf = new byte[22];
							      t = 5242880;
							      buf[0] = (byte) (t >>> 16);
							      t = 116736;
							      buf[1] = (byte) (t >>> 10);
							      t = 12713984;
							      buf[2] = (byte) (t >>> 17);
							      t = 28835840;
							      buf[3] = (byte) (t >>> 18);
							      t = 30408704;
							      buf[4] = (byte) (t >>> 18);
							      t = 56832;
							      buf[5] = (byte) (t >>> 9);
							      t = 3112960;
							      buf[6] = (byte) (t >>> 15);
							      t = 104857600;
							      buf[7] = (byte) (t >>> 21);
							      t = 100663296;
							      buf[8] = (byte) (t >>> 21);
							      t = 6291456;
							      buf[9] = (byte) (t >>> 17);
							      t = 230686720;
							      buf[10] = (byte) (t >>> 22);
							      t = 24320;
							      buf[11] = (byte) (t >>> 8);
							      t = 4928;
							      buf[12] = (byte) (t >>> 6);
							      t = 199229440;
							      buf[13] = (byte) (t >>> 21);
							      t = 1359872;
							      buf[14] = (byte) (t >>> 14);
							      t = 105906176;
							      buf[15] = (byte) (t >>> 20);
							      t = 25952256;
							      buf[16] = (byte) (t >>> 18);
							      t = 245366784;
							      buf[17] = (byte) (t >>> 21);
							      t = 478150656;
							      buf[18] = (byte) (t >>> 22);
							      t = 880803840;
							      buf[19] = (byte) (t >>> 23);
							      t = 14848;
							      buf[20] = (byte) (t >>> 7);
							      t = 7929856;
							      buf[21] = (byte) (t >>> 16);
							      return new String(buf);
							   }
					}.toString()));
					Dashboard.setHeaders(IM_PRANTO);
					Dashboard.setParams(dashboard, RequestNetworkController.REQUEST_PARAM);
					Dashboard.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("dashboard.php"), "", _Dashboard_request_listener);
					dashboard.clear();
					IM_PRANTO.clear();
				}
			}
		});
		
		Img1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_drawer.openDrawer(GravityCompat.START);
			}
		});
		
		_Dashboard_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				Swipe.setRefreshing(false);
				try{
					dashboardResponse.clear();
					dashboardResponse = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
					if (dashboardResponse.get("status").toString().equals("success")) {
						userTv.setText(String.valueOf((long)(Double.parseDouble(dashboardResponse.get("total_users").toString()))));
						banuserTv.setText(String.valueOf((long)(Double.parseDouble(dashboardResponse.get("ban_users").toString()))));
						balanceTv.setText("৳".concat(String.valueOf((long)(Double.parseDouble(dashboardResponse.get("total_balance").toString())))));
						winningTv.setText("৳".concat(String.valueOf((long)(Double.parseDouble(dashboardResponse.get("total_winning").toString())))));
						pendingDp.setText(String.valueOf((long)(Double.parseDouble(dashboardResponse.get("pending_deposit").toString()))));
						pendingWd.setText(String.valueOf((long)(Double.parseDouble(dashboardResponse.get("pending_withdraw").toString()))));
						totalDpTv.setText(String.valueOf((long)(Double.parseDouble(dashboardResponse.get("total_deposit").toString()))));
						totalWdTv.setText(String.valueOf((long)(Double.parseDouble(dashboardResponse.get("total_withdraw").toString()))));
						matchTv.setText(String.valueOf((long)(Double.parseDouble(dashboardResponse.get("live_match").toString()))));
						categoryTv.setText(String.valueOf((long)(Double.parseDouble(dashboardResponse.get("live_category").toString()))));
						if (dashboardResponse.get("admin_role").toString().equals("Admin")) {
							linear2.setBackgroundResource(R.drawable.banner);
						} else {
							linear2.setBackgroundResource(R.drawable.modre);
						}
						_drawer_name.setText(dashboardResponse.get("admin_name").toString());
						_drawer_email.setText(dashboardResponse.get("admin_email").toString());
						if (String.valueOf((long)(Double.parseDouble(dashboardResponse.get("admin_status").toString()))).equals("1")) {
							_Ban();
						}
						try {
							    String rawPermission = dashboardResponse.get("admin_permission") != null ? dashboardResponse.get("admin_permission").toString() : "";
							    
							    java.util.ArrayList<String> permission_list = new Gson().fromJson(
							        rawPermission,
							        new TypeToken<java.util.ArrayList<String>>(){}.getType()
							    );
							
							    if (permission_list != null) {
								        _drawer_Bg2.setVisibility(permission_list.contains("users") ? View.VISIBLE : View.GONE);
								        _drawer_Bg3.setVisibility(permission_list.contains("deposit") ? View.VISIBLE : View.GONE);
								        _drawer_Bg4.setVisibility(permission_list.contains("withdraw") ? View.VISIBLE : View.GONE);
								        _drawer_Bg6.setVisibility(permission_list.contains("category") ? View.VISIBLE : View.GONE);
								        _drawer_Bg7.setVisibility(permission_list.contains("slider") ? View.VISIBLE : View.GONE);
								        _drawer_Bg12.setVisibility(permission_list.contains("push_notification") ? View.VISIBLE : View.GONE);
								        _drawer_Bg9.setVisibility(permission_list.contains("setting") ? View.VISIBLE : View.GONE);
								        _drawer_Bg10.setVisibility(permission_list.contains("app_admin") ? View.VISIBLE : View.GONE);
								        _drawer_Bg11.setVisibility(permission_list.contains("admin_transaction") ? View.VISIBLE : View.GONE);
								        _drawer_Bg13.setVisibility(permission_list.contains("device") ? View.VISIBLE : View.GONE);
								
								        permission_data.edit().putString("Winning", permission_list.contains("winning") ? "true" : "false").commit();
								        permission_data.edit().putString("Refund", permission_list.contains("refund") ? "true" : "false").commit();
								        permission_data.edit().putString("Match", permission_list.contains("Match") ? "true" : "false").commit();
								    }
							
						} catch (Exception e) {
							    
						}
						
					} else {
						CustomToast.show(findViewById(android.R.id.content), "Data Fetch Unsuccessfully", CustomToast.TYPE_ERROR, R.font.font2);
					}
				}catch(Exception e){
					 
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_drawer_Bg1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		_drawer_Bg2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				New_Activity.setClass(getApplicationContext(), PrantoUsersActivity.class);
				startActivity(New_Activity);
				overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
			}
		});
		
		_drawer_Bg3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				New_Activity.setClass(getApplicationContext(), PrantoTransactionActivity.class);
				New_Activity.putExtra("Type", "Deposit");
				startActivity(New_Activity);
				overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
			}
		});
		
		_drawer_Bg4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				New_Activity.setClass(getApplicationContext(), PrantoTransactionActivity.class);
				New_Activity.putExtra("Type", "Withdraw");
				startActivity(New_Activity);
				overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
			}
		});
		
		_drawer_Bg6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				New_Activity.setClass(getApplicationContext(), PrantoCategoryActivity.class);
				startActivity(New_Activity);
				overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
			}
		});
		
		_drawer_Bg12.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				New_Activity.setClass(getApplicationContext(), PrantoNotificationActivity.class);
				New_Activity.putExtra("Type", "All");
				startActivity(New_Activity);
				overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
			}
		});
		
		_drawer_Bg7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				New_Activity.setClass(getApplicationContext(), PrantoSliderActivity.class);
				startActivity(New_Activity);
				overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
			}
		});
		
		_drawer_Bg9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				New_Activity.setClass(getApplicationContext(), PrantoSettingActivity.class);
				startActivity(New_Activity);
				overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
			}
		});
		
		_drawer_Bg10.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				New_Activity.setClass(getApplicationContext(), PrantoAdminActivity.class);
				startActivity(New_Activity);
				overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
			}
		});
		
		_drawer_Bg11.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				New_Activity.setClass(getApplicationContext(), PrantoAdminTxnActivity.class);
				startActivity(New_Activity);
				overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
			}
		});
		
		_drawer_Bg13.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				New_Activity.setClass(getApplicationContext(), PrantoDeviceActivity.class);
				startActivity(New_Activity);
				overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
			}
		});
		
		_drawer_ligoutImg.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Auth.edit().remove("Login").commit();
				Auth.edit().remove("Email").commit();
				Auth.edit().remove("Session_id").commit();
				New_Activity.setClass(getApplicationContext(), PrantoLoginActivity.class);
				startActivity(New_Activity);
				overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
			}
		});
	}
	
	private void initializeLogic() {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
			Window w =PrantoHomeActivity.this.getWindow();
			w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFF000000);
		}
		getSupportActionBar().hide();
		_DrawerWidth(250);
		Swipe.setColorSchemeColors(android.graphics.Color.parseColor("#0D00FF"));
		
		Swipe.setProgressBackgroundColorSchemeColor(android.graphics.Color.parseColor("#121212"));
		int[] colorsCRNDF = { Color.parseColor("#0D00FF"), Color.parseColor("#000000") }; android.graphics.drawable.GradientDrawable CRNDF = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR, colorsCRNDF);
		CRNDF.setCornerRadii(new float[]{(int)0,(int)0,(int)0,(int)0,(int)0,(int)0,(int)0,(int)0});
		CRNDF.setStroke((int) 0, Color.parseColor("#000000"));
		dot1.setElevation((float) 0);
		dot1.setBackground(CRNDF);
		
		//Paste this code in (add source directly block) asd block
		//Milz
		bg1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)25, 0xFF7839DD));
		Bg1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)30, (int)3, 0x507839DD, 0x337839DD));
		bg2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFFF1744));
		Bg2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)25, (int)3, 0x50FF1744, 0x33FF1744));
		bg3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF00C853));
		Bg3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)25, (int)3, 0x5000C853, 0x3300C853));
		bg4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFFF9100));
		Bg4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)25, (int)3, 0x50FF9100, 0x33FF9100));
		bg5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF0D00FF));
		Bg5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)25, (int)3, 0x500D00FF, 0x330D00FF));
		bg6.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF1DE9B6));
		Bg6.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)25, (int)3, 0x501DE9B6, 0x331DE9B6));
		bg7.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFAA00FF));
		Bg7.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)25, (int)3, 0x50AA00FF, 0x33AA00FF));
		bg8.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF00E5FF));
		B8.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)25, (int)3, 0x5000E5FF, 0x3300E5FF));
		bg9.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF2196F3));
		Bg9.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)25, (int)3, 0x502196F3, 0x332196F3));
		bg10.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFFFD600));
		Bg10.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)25, (int)3, 0x50FFD600, 0x33FFD600));
		int[] colorsCRNPD = { Color.parseColor("#7839DD"), Color.parseColor("#000000") }; android.graphics.drawable.GradientDrawable CRNPD = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR, colorsCRNPD);
		CRNPD.setCornerRadii(new float[]{(int)18,(int)18,(int)18,(int)18,(int)18,(int)18,(int)18,(int)18});
		CRNPD.setStroke((int) 0, Color.parseColor("#000000"));
		_drawer_Bg1.setElevation((float) 0);
		_drawer_Bg1.setBackground(CRNPD);
		
		//Paste this code in (add source directly block) asd block
		//Milz
		int[] colorsCRNWB = { Color.parseColor("#1B5E20"), Color.parseColor("#000000") }; android.graphics.drawable.GradientDrawable CRNWB = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR, colorsCRNWB);
		CRNWB.setCornerRadii(new float[]{(int)18,(int)18,(int)18,(int)18,(int)18,(int)18,(int)18,(int)18});
		CRNWB.setStroke((int) 0, Color.parseColor("#000000"));
		_drawer_nameBg.setElevation((float) 0);
		_drawer_nameBg.setBackground(CRNWB);
		
		//Paste this code in (add source directly block) asd block
		//Milz
		_drawer_Bg2.setVisibility(View.GONE);
		_drawer_Bg3.setVisibility(View.GONE);
		_drawer_Bg4.setVisibility(View.GONE);
		_drawer_Bg6.setVisibility(View.GONE);
		_drawer_Bg7.setVisibility(View.GONE);
		_drawer_Bg9.setVisibility(View.GONE);
		_drawer_Bg10.setVisibility(View.GONE);
		_drawer_Bg11.setVisibility(View.GONE);
		_drawer_Bg12.setVisibility(View.GONE);
		_drawer_Bg13.setVisibility(View.GONE);
		Swipe.setRefreshing(true);
		if (vpn()) {
		} else {
			IM_PRANTO = new HashMap<>();
			dashboard = new HashMap<>();
			dashboard.put("email", Auth.getString("Email", ""));
			dashboard.put("session_id", Auth.getString("Session_id", ""));
			IM_PRANTO.put("X-IM-PRANTO", (new Object() {
				   int t;
				   public String toString() {
					      byte[] buf = new byte[22];
					      t = 5242880;
					      buf[0] = (byte) (t >>> 16);
					      t = 116736;
					      buf[1] = (byte) (t >>> 10);
					      t = 12713984;
					      buf[2] = (byte) (t >>> 17);
					      t = 28835840;
					      buf[3] = (byte) (t >>> 18);
					      t = 30408704;
					      buf[4] = (byte) (t >>> 18);
					      t = 56832;
					      buf[5] = (byte) (t >>> 9);
					      t = 3112960;
					      buf[6] = (byte) (t >>> 15);
					      t = 104857600;
					      buf[7] = (byte) (t >>> 21);
					      t = 100663296;
					      buf[8] = (byte) (t >>> 21);
					      t = 6291456;
					      buf[9] = (byte) (t >>> 17);
					      t = 230686720;
					      buf[10] = (byte) (t >>> 22);
					      t = 24320;
					      buf[11] = (byte) (t >>> 8);
					      t = 4928;
					      buf[12] = (byte) (t >>> 6);
					      t = 199229440;
					      buf[13] = (byte) (t >>> 21);
					      t = 1359872;
					      buf[14] = (byte) (t >>> 14);
					      t = 105906176;
					      buf[15] = (byte) (t >>> 20);
					      t = 25952256;
					      buf[16] = (byte) (t >>> 18);
					      t = 245366784;
					      buf[17] = (byte) (t >>> 21);
					      t = 478150656;
					      buf[18] = (byte) (t >>> 22);
					      t = 880803840;
					      buf[19] = (byte) (t >>> 23);
					      t = 14848;
					      buf[20] = (byte) (t >>> 7);
					      t = 7929856;
					      buf[21] = (byte) (t >>> 16);
					      return new String(buf);
					   }
			}.toString()));
			Dashboard.setHeaders(IM_PRANTO);
			Dashboard.setParams(dashboard, RequestNetworkController.REQUEST_PARAM);
			Dashboard.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("dashboard.php"), "", _Dashboard_request_listener);
			dashboard.clear();
			IM_PRANTO.clear();
		}
	}
	
	@Override
	public void onBackPressed() {
		final AlertDialog dialog = new AlertDialog.Builder(PrantoHomeActivity.this).create();
		View inflate = getLayoutInflater().inflate(R.layout.confirm,null); 
		dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		dialog.setView(inflate);
		LinearLayout confirmBg = (LinearLayout) inflate.findViewById(R.id.confirmBg);
		TextView cancelTv = (TextView) inflate.findViewById(R.id.cancelTv);
		cancelTv.setText("No");
		TextView confrmTv = (TextView) inflate.findViewById(R.id.confrmTv);
		confrmTv.setText("Yes");
		TextView Tv1 = (TextView) inflate.findViewById(R.id.Tv1);
		Tv1.setText("Confirmation! ");
		TextView Tv2 = (TextView) inflate.findViewById(R.id.Tv2);
		Tv2.setText("Are you sure you want to exit the app?");
		confirmBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF0D00FF));
		cancelTv.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				dialog.dismiss();
			}
		});
		confirmBg.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				finishAffinity();
			}
		});
		dialog.setCancelable(true);
		dialog.show();
	}
	public void _DrawerWidth(final double _num) {
		LinearLayout _nav_view = (LinearLayout) findViewById(R.id._nav_view);
		
		_nav_view.setBackgroundColor(Color.parseColor("#FFFFFF"));
		
		androidx.drawerlayout.widget.DrawerLayout.LayoutParams params = (androidx.drawerlayout.widget.DrawerLayout.LayoutParams)_nav_view.getLayoutParams();
		
		params.width = (int)getDip((int)_num);
		
		params.height = androidx.drawerlayout.widget.DrawerLayout.LayoutParams.MATCH_PARENT;
		
		_nav_view.setLayoutParams(params);
	}
	
	
	public void _vpn() {
	}
	public boolean vpn() {
		    String iface = "";
		    try {
			        for (java.net.NetworkInterface networkInterface : Collections.list(java.net.NetworkInterface.getNetworkInterfaces())) {
				            if (networkInterface.isUp())
				                iface = networkInterface.getName();
				                Log.d("DEBUG", "IFACE NAME: " + iface);
				            if ( iface.contains("tun") || iface.contains("ppp") || iface.contains("pptp")) {
					                return true;
					            }
				        }
			    } catch (Exception e1) {
			        e1.printStackTrace();
			    }
		
		    return false;
	}
	{
	}
	
	
	public void _Ban() {
		final AlertDialog dialog = new AlertDialog.Builder(PrantoHomeActivity.this).create();
		View inflate = getLayoutInflater().inflate(R.layout.ban,null); 
		dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		dialog.setView(inflate);
		LinearLayout Bg1 = (LinearLayout) inflate.findViewById(R.id.Bg1);
		LinearLayout b1 = (LinearLayout) inflate.findViewById(R.id.b1);
		Bg1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0x33F44336));
		b1.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				finishAffinity();
			}
		});
		dialog.setCancelable(false);
		dialog.show();
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}
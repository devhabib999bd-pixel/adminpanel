package com.totalzone.devhabibbd.admin;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
import java.util.Base64;
import java.nio.charset.StandardCharsets;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.gson.JsonParser;
import com.google.gson.JsonObject;
import android.content.pm.PackageManager;
import android.Manifest;

public class PrantoUpdatematchActivity extends AppCompatActivity {
	
	private HashMap<String, Object> IM_PRANTO = new HashMap<>();
	private HashMap<String, Object> match = new HashMap<>();
	private HashMap<String, Object> updateResponse = new HashMap<>();
	private HashMap<String, Object> player = new HashMap<>();
	private HashMap<String, Object> mapP1 = new HashMap<>();
	private HashMap<String, Object> notification_Map = new HashMap<>();
	private String ProjectID = "";
	private String accessToken = "";
	private double Num1 = 0;
	private double Num2 = 0;
	
	private ArrayList<HashMap<String, Object>> playerList = new ArrayList<>();
	
	private LinearLayout BG;
	private LinearLayout linear3;
	private ScrollView Scroll1;
	private ImageView imageview1;
	private TextView Title;
	private LinearLayout Bg1;
	private TextView textview34;
	private EditText E1;
	private TextView textview35;
	private LinearLayout linear4;
	private TextView textview36;
	private EditText Timer;
	private TextView textview37;
	private EditText E5;
	private TextView textview38;
	private LinearLayout linear5;
	private TextView textview40;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private TextView textview41;
	private LinearLayout linear10;
	private LinearLayout Lg_B1;
	private EditText Date;
	private EditText Time;
	private EditText E6;
	private EditText E7;
	private EditText E9;
	private EditText E10;
	private EditText E11;
	private EditText E12;
	private EditText E13;
	private EditText E14;
	private EditText E15;
	private TextView Tv8;
	private ProgressBar prog;
	
	private SharedPreferences Auth;
	private SharedPreferences app_infos;
	private RequestNetwork Matches;
	private RequestNetwork.RequestListener _Matches_request_listener;
	private Calendar PRANTO = Calendar.getInstance();
	private SharedPreferences Finish;
	private RequestNetwork Participants;
	private RequestNetwork.RequestListener _Participants_request_listener;
	
	private OnCompleteListener FCM_onCompleteListener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.pranto_updatematch);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		BG = findViewById(R.id.BG);
		linear3 = findViewById(R.id.linear3);
		Scroll1 = findViewById(R.id.Scroll1);
		imageview1 = findViewById(R.id.imageview1);
		Title = findViewById(R.id.Title);
		Bg1 = findViewById(R.id.Bg1);
		textview34 = findViewById(R.id.textview34);
		E1 = findViewById(R.id.E1);
		textview35 = findViewById(R.id.textview35);
		linear4 = findViewById(R.id.linear4);
		textview36 = findViewById(R.id.textview36);
		Timer = findViewById(R.id.Timer);
		textview37 = findViewById(R.id.textview37);
		E5 = findViewById(R.id.E5);
		textview38 = findViewById(R.id.textview38);
		linear5 = findViewById(R.id.linear5);
		textview40 = findViewById(R.id.textview40);
		linear8 = findViewById(R.id.linear8);
		linear9 = findViewById(R.id.linear9);
		textview41 = findViewById(R.id.textview41);
		linear10 = findViewById(R.id.linear10);
		Lg_B1 = findViewById(R.id.Lg_B1);
		Date = findViewById(R.id.Date);
		Time = findViewById(R.id.Time);
		E6 = findViewById(R.id.E6);
		E7 = findViewById(R.id.E7);
		E9 = findViewById(R.id.E9);
		E10 = findViewById(R.id.E10);
		E11 = findViewById(R.id.E11);
		E12 = findViewById(R.id.E12);
		E13 = findViewById(R.id.E13);
		E14 = findViewById(R.id.E14);
		E15 = findViewById(R.id.E15);
		Tv8 = findViewById(R.id.Tv8);
		prog = findViewById(R.id.prog);
		Auth = getSharedPreferences("Auth", Activity.MODE_PRIVATE);
		app_infos = getSharedPreferences("app_infos", Activity.MODE_PRIVATE);
		Matches = new RequestNetwork(this);
		Finish = getSharedPreferences("Finish", Activity.MODE_PRIVATE);
		Participants = new RequestNetwork(this);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
				overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
			}
		});
		
		Lg_B1.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				_clickAnimation(Lg_B1);
				return true;
			}
		});
		
		Lg_B1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_clickAnimation(Lg_B1);
				if (!(E1.getText().toString().isEmpty() || (Date.getText().toString().isEmpty() || (Time.getText().toString().isEmpty() || (Timer.getText().toString().isEmpty() || (E5.getText().toString().isEmpty() || (E6.getText().toString().isEmpty() || (E7.getText().toString().isEmpty() || (E9.getText().toString().isEmpty() || (E14.getText().toString().isEmpty() || E15.getText().toString().isEmpty())))))))))) {
					if (Double.parseDouble(E5.getText().toString()) > (2 - 1)) {
						if (Double.parseDouble(E5.getText().toString()) < (48 + 1)) {
							prog.setVisibility(View.VISIBLE);
							Tv8.setVisibility(View.GONE);
							if (vpn()) {
							} else {
								IM_PRANTO = new HashMap<>();
								match = new HashMap<>();
								match.put("type", "update");
								match.put("match_id", getIntent().getStringExtra("Match Id"));
								match.put("matchtitle", E1.getText().toString());
								match.put("input", Timer.getText().toString());
								match.put("date", Date.getText().toString());
								match.put("time", Time.getText().toString());
								match.put("totalprize", E6.getText().toString());
								match.put("perkill", E7.getText().toString());
								match.put("playerneed", E5.getText().toString());
								match.put("first_prize", E9.getText().toString());
								match.put("second_prize", E10.getText().toString());
								match.put("third_prize", E11.getText().toString());
								match.put("fourth_prize", E12.getText().toString());
								match.put("fiveth_prize", E13.getText().toString());
								match.put("room_id", E14.getText().toString());
								match.put("room_pass", E15.getText().toString());
								match.put("email", Auth.getString("Email", ""));
								match.put("session_id", Auth.getString("Session_id", ""));
								IM_PRANTO.put("X-IM-PRANTO", (new Object() {
									   int t;
									   public String toString() {
										      byte[] buf = new byte[22];
										      t = 5242880;
										      buf[0] = (byte) (t >>> 16);
										      t = 116736;
										      buf[1] = (byte) (t >>> 10);
										      t = 12713984;
										      buf[2] = (byte) (t >>> 17);
										      t = 28835840;
										      buf[3] = (byte) (t >>> 18);
										      t = 30408704;
										      buf[4] = (byte) (t >>> 18);
										      t = 56832;
										      buf[5] = (byte) (t >>> 9);
										      t = 3112960;
										      buf[6] = (byte) (t >>> 15);
										      t = 104857600;
										      buf[7] = (byte) (t >>> 21);
										      t = 100663296;
										      buf[8] = (byte) (t >>> 21);
										      t = 6291456;
										      buf[9] = (byte) (t >>> 17);
										      t = 230686720;
										      buf[10] = (byte) (t >>> 22);
										      t = 24320;
										      buf[11] = (byte) (t >>> 8);
										      t = 4928;
										      buf[12] = (byte) (t >>> 6);
										      t = 199229440;
										      buf[13] = (byte) (t >>> 21);
										      t = 1359872;
										      buf[14] = (byte) (t >>> 14);
										      t = 105906176;
										      buf[15] = (byte) (t >>> 20);
										      t = 25952256;
										      buf[16] = (byte) (t >>> 18);
										      t = 245366784;
										      buf[17] = (byte) (t >>> 21);
										      t = 478150656;
										      buf[18] = (byte) (t >>> 22);
										      t = 880803840;
										      buf[19] = (byte) (t >>> 23);
										      t = 14848;
										      buf[20] = (byte) (t >>> 7);
										      t = 7929856;
										      buf[21] = (byte) (t >>> 16);
										      return new String(buf);
										   }
								}.toString()));
								Matches.setHeaders(IM_PRANTO);
								Matches.setParams(match, RequestNetworkController.REQUEST_PARAM);
								Matches.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("match.php"), "", _Matches_request_listener);
								match.clear();
								IM_PRANTO.clear();
								//---------------------------------
								if (!(E14.getText().toString().equals("0") && E15.getText().toString().equals("0"))) {
									Num1 = 0;
									Num2 = 0;
									for(int _repeat168 = 0; _repeat168 < (int)(playerList.size()); _repeat168++) {
										if (playerList.get((int)Num1).containsKey("fcm_token")) {
											Num2 = 1;
											_Pranto_Notification(playerList.get((int)Num1).get("fcm_token").toString(), "Room Details Update", "Dear ".concat(playerList.get((int)Num1).get("name").toString().concat(", the room details for your joined match ID: #".concat(getIntent().getStringExtra("Match Id").concat(" have been updated. ")))));
										}
										Num1++;
									}
									if (Num2 == 0) {
										try{
											 
										}catch(Exception e){
											 
										}
									}
								}
							}
						} else {
							CustomToast.show(findViewById(android.R.id.content), "Maximum 48 slot needed", CustomToast.TYPE_ERROR, R.font.font3);
						}
					} else {
						CustomToast.show(findViewById(android.R.id.content), "Minimum 2 slot needed", CustomToast.TYPE_ERROR, R.font.font3);
					}
				} else {
					CustomToast.show(findViewById(android.R.id.content), "Please fill in all fields", CustomToast.TYPE_ERROR, R.font.font3);
				}
			}
		});
		
		_Matches_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				prog.setVisibility(View.GONE);
				Tv8.setVisibility(View.VISIBLE);
				try{
					updateResponse.clear();
					updateResponse = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
					if (updateResponse.get("status").toString().equals("success")) {
						Finish.edit().putString("Update", "YES").commit();
						CustomToast.show(findViewById(android.R.id.content), "Match update successful", CustomToast.TYPE_SUCCESS, R.font.font2);
					} else {
						CustomToast.show(findViewById(android.R.id.content),updateResponse.get("message").toString(),CustomToast.TYPE_ERROR,R.font.font3);
					}
				}catch(Exception e){
					 
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_Participants_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				mapP1.clear();
				playerList.clear();
				try {
					try {
							JSONArray Array1 = new JSONArray(_response);
							for (int Ps1 = 0; Ps1 < Array1.length(); Ps1++) {
									JSONObject PRANTO1 = Array1.getJSONObject(Ps1);
									try { 
								mapP1 = new HashMap<>();
								mapP1.put("name", PRANTO1.getString("name"));
								mapP1.put("fcm_token", PRANTO1.getString("fcm_token"));
								playerList.add(mapP1);
							}catch(Exception ex){ex.printStackTrace();}
							}
					} catch (JSONException e) {
							e.printStackTrace();
					}
				} catch (Exception e) {
					
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		FCM_onCompleteListener = new OnCompleteListener<InstanceIdResult>() {
			@Override
			public void onComplete(Task<InstanceIdResult> task) {
				final boolean _success = task.isSuccessful();
				final String _token = task.getResult().getToken();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
	}
	
	private void initializeLogic() {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
			Window w =PrantoUpdatematchActivity.this.getWindow();
			w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFF000000);
		}
		Title.setText("Update Match #".concat(getIntent().getStringExtra("Match Id")));
		_Pranto_Match_Data();
		prog.setVisibility(View.GONE);
		Tv8.setVisibility(View.VISIBLE);
		E1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		Date.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		Time.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		Timer.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		E5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		E6.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		E7.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		E9.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		E10.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		E11.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		E12.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		E13.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		E14.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		E15.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		Lg_B1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF0D00FF));
		Date.setInputType(InputType.TYPE_NULL);
		
		View.OnClickListener dateClickListener = v -> {
			    Calendar PRANTO = Calendar.getInstance();
			    int year = PRANTO.get(Calendar.YEAR);
			    int month = PRANTO.get(Calendar.MONTH);
			    int day = PRANTO.get(Calendar.DAY_OF_MONTH);
			
			    DatePickerDialog datePickerDialog = new DatePickerDialog(
			            PrantoUpdatematchActivity.this,
			            android.R.style.Theme_Material_Dialog,
			            (view, selectedYear, selectedMonth, selectedDay) -> {
				                Calendar cal = Calendar.getInstance();
				                cal.set(selectedYear, selectedMonth, selectedDay);
				
				                SimpleDateFormat sdf = new SimpleDateFormat("dd, MMM, yyyy", Locale.getDefault());
				                Date.setText(sdf.format(cal.getTime()));
				                Date.setTextColor(Color.parseColor("#FFFFFF"));
				            },
			            year, month, day
			    );
			
			    datePickerDialog.show();
		};
		
		Date.setOnClickListener(dateClickListener);
		Date.setOnFocusChangeListener((view, hasFocus) -> {
			    if (hasFocus) {
				        dateClickListener.onClick(view);
				    }
		});
		
		Time.setInputType(InputType.TYPE_NULL);
		
		View.OnClickListener timeClickListener = v -> {
			    Calendar PRANTO = Calendar.getInstance();
			    int hour = PRANTO.get(Calendar.HOUR_OF_DAY);
			    int minute = PRANTO.get(Calendar.MINUTE);
			
			    TimePickerDialog timePickerDialog = new TimePickerDialog(
			            PrantoUpdatematchActivity.this,
			            android.R.style.Theme_Material_Dialog,
			            (view, selectedHour, selectedMinute) -> {
				                Calendar cal = Calendar.getInstance();
				                cal.set(Calendar.HOUR_OF_DAY, selectedHour);
				                cal.set(Calendar.MINUTE, selectedMinute);
				
				                SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a", Locale.getDefault());
				                Time.setText(sdf.format(cal.getTime()));
				                Time.setTextColor(Color.parseColor("#FFFFFF"));
				            },
			            hour, minute, false
			    );
			
			    timePickerDialog.show();
		};
		
		Time.setOnClickListener(timeClickListener);
		Time.setOnFocusChangeListener((view, hasFocus) -> {
			    if (hasFocus) {
				        timeClickListener.onClick(view);
				    }
		});
		
		Timer.setInputType(InputType.TYPE_NULL);
		
		View.OnClickListener timerClickListener = v -> {
			    Calendar PRANTO = Calendar.getInstance();
			    int year = PRANTO.get(Calendar.YEAR);
			    int month = PRANTO.get(Calendar.MONTH);
			    int day = PRANTO.get(Calendar.DAY_OF_MONTH);
			    int hour = PRANTO.get(Calendar.HOUR_OF_DAY);
			    int minute = PRANTO.get(Calendar.MINUTE);
			
			    DatePickerDialog datePickerDialog = new DatePickerDialog(
			            PrantoUpdatematchActivity.this,
			            android.R.style.Theme_Material_Dialog,
			            (view, selectedYear, selectedMonth, selectedDay) -> {
				                String date = String.format("%d-%02d-%02d", selectedYear, selectedMonth + 1, selectedDay);
				
				                TimePickerDialog timePickerDialog = new TimePickerDialog(
				                        PrantoUpdatematchActivity.this,
				                        android.R.style.Theme_Material_Dialog,
				                        (timeView, hourOfDay, selectedMinute) -> {
					                            String dateTime = date + String.format(" %02d:%02d:00", hourOfDay, selectedMinute);
					                            Timer.setText(dateTime);
					                            Timer.setTextColor(Color.parseColor("#FFFFFF"));
					                        },
				                        hour, minute, true
				                );
				                timePickerDialog.show();
				            },
			            year, month, day
			    );
			    datePickerDialog.show();
		};
		
		Timer.setOnClickListener(timerClickListener);
		Timer.setOnFocusChangeListener((view, hasFocus) -> {
			    if (hasFocus) {
				        timerClickListener.onClick(view);
				    }
		});
		
		try {
				   
				    InputStream originalInputStream = getAssets().open("pranto.json");
				    byte[] inputStreamBytes = SketchwareUtil.copyFromInputStream(originalInputStream).getBytes();
				    originalInputStream.close();
				
				   
				    try (InputStream inputStream = new ByteArrayInputStream(inputStreamBytes)) {
						        String jsonString = SketchwareUtil.copyFromInputStream(inputStream);
						        HashMap<String, Object> map = new Gson().fromJson(
						            jsonString,
						            new TypeToken<HashMap<String, Object>>(){}.getType()
						        );
						        ProjectID = map.get("project_id").toString();
						    }
				
				  
				    try (InputStream inputStream = new ByteArrayInputStream(inputStreamBytes)) {
						        AccessTokenGenerator.generateToken(inputStream, new AccessTokenGenerator.onTokenResponse() {
								            @Override
								            public void onSuccess(String token) {
										                JsonObject jsonResponse = JsonParser.parseString(token).getAsJsonObject();
										                if (jsonResponse.has("access_token")) {
												                    accessToken = jsonResponse.get("access_token").getAsString();
												                } else {
												                  accessToken = "error getting accessToken";
												                }
										                  
										            }
								
								            @Override
								            public void onError(String error) {
										                
										                  
										            }
								        });
						    }
		} catch (Exception e) {
				    
			
		}
		if (vpn()) {
		} else {
			IM_PRANTO = new HashMap<>();
			player = new HashMap<>();
			player.put("match_id", getIntent().getStringExtra("Match Id"));
			player.put("email", Auth.getString("Email", ""));
			player.put("session_id", Auth.getString("Session_id", ""));
			IM_PRANTO.put("X-IM-PRANTO", (new Object() {
				   int t;
				   public String toString() {
					      byte[] buf = new byte[22];
					      t = 5242880;
					      buf[0] = (byte) (t >>> 16);
					      t = 116736;
					      buf[1] = (byte) (t >>> 10);
					      t = 12713984;
					      buf[2] = (byte) (t >>> 17);
					      t = 28835840;
					      buf[3] = (byte) (t >>> 18);
					      t = 30408704;
					      buf[4] = (byte) (t >>> 18);
					      t = 56832;
					      buf[5] = (byte) (t >>> 9);
					      t = 3112960;
					      buf[6] = (byte) (t >>> 15);
					      t = 104857600;
					      buf[7] = (byte) (t >>> 21);
					      t = 100663296;
					      buf[8] = (byte) (t >>> 21);
					      t = 6291456;
					      buf[9] = (byte) (t >>> 17);
					      t = 230686720;
					      buf[10] = (byte) (t >>> 22);
					      t = 24320;
					      buf[11] = (byte) (t >>> 8);
					      t = 4928;
					      buf[12] = (byte) (t >>> 6);
					      t = 199229440;
					      buf[13] = (byte) (t >>> 21);
					      t = 1359872;
					      buf[14] = (byte) (t >>> 14);
					      t = 105906176;
					      buf[15] = (byte) (t >>> 20);
					      t = 25952256;
					      buf[16] = (byte) (t >>> 18);
					      t = 245366784;
					      buf[17] = (byte) (t >>> 21);
					      t = 478150656;
					      buf[18] = (byte) (t >>> 22);
					      t = 880803840;
					      buf[19] = (byte) (t >>> 23);
					      t = 14848;
					      buf[20] = (byte) (t >>> 7);
					      t = 7929856;
					      buf[21] = (byte) (t >>> 16);
					      return new String(buf);
					   }
			}.toString()));
			Participants.setHeaders(IM_PRANTO);
			Participants.setParams(player, RequestNetworkController.REQUEST_PARAM);
			Participants.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("participants.php"), "", _Participants_request_listener);
			player.clear();
			IM_PRANTO.clear();
		}
	}
	
	@Override
	public void onBackPressed() {
		finish();
		overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
	}
	
	public void _vpn() {
	}
	public boolean vpn() {
		    String iface = "";
		    try {
			        for (java.net.NetworkInterface networkInterface : Collections.list(java.net.NetworkInterface.getNetworkInterfaces())) {
				            if (networkInterface.isUp())
				                iface = networkInterface.getName();
				                Log.d("DEBUG", "IFACE NAME: " + iface);
				            if ( iface.contains("tun") || iface.contains("ppp") || iface.contains("pptp")) {
					                return true;
					            }
				        }
			    } catch (Exception e1) {
			        e1.printStackTrace();
			    }
		
		    return false;
	}
	{
	}
	
	
	public void _clickAnimation(final View _view) {
		ScaleAnimation clickAnim = new ScaleAnimation(
		    1f, 0.9f,
		    1f, 0.9f,
		    Animation.RELATIVE_TO_SELF, 0.5f,
		    Animation.RELATIVE_TO_SELF, 0.5f
		);
		
		clickAnim.setDuration(100);
		clickAnim.setRepeatCount(1);
		clickAnim.setRepeatMode(Animation.REVERSE);
		clickAnim.setFillAfter(false);
		
		_view.startAnimation(clickAnim);
	}
	
	
	public void _Pranto_Match_Data() {
		E1.setText(getIntent().getStringExtra("Title"));
		Date.setText(getIntent().getStringExtra("Date"));
		Time.setText(getIntent().getStringExtra("Time"));
		Timer.setText(getIntent().getStringExtra("Timer"));
		E5.setText(getIntent().getStringExtra("Need"));
		E6.setText(getIntent().getStringExtra("Prize"));
		E7.setText(getIntent().getStringExtra("Kill"));
		E9.setText(getIntent().getStringExtra("Fast"));
		E10.setText(getIntent().getStringExtra("Second"));
		E11.setText(getIntent().getStringExtra("Third"));
		E12.setText(getIntent().getStringExtra("Fourth"));
		E13.setText(getIntent().getStringExtra("Fiveth"));
		E14.setText(getIntent().getStringExtra("Room Id"));
		E15.setText(getIntent().getStringExtra("Room Pass"));
	}
	
	
	public void _Pranto_Notification(final String _Topic, final String _Title, final String _Body) {
		notification_Map = new HashMap<>();
		notification_Map.put("title", _Title);
		notification_Map.put("body", _Body);
		notification_Map.put("image", "null");
		String token =  _Topic;
		String topic = ""; 
		String projectId =  ProjectID;
		String tokenaccess =  accessToken; 
		FCMNotificationSender.sendNotification( notification_Map, topic, token, projectId, tokenaccess, new FCMNotificationSender.onResponse() {
				    @Override
				    public void onSuccess(String response) {
						    	        		         
						    }
				
				    @Override
				    public void onError(String error) {
						      		          
						    }
		});
		
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}
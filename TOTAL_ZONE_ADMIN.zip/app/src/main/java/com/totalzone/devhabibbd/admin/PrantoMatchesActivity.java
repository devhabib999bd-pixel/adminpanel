package com.totalzone.devhabibbd.admin;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.firebase.FirebaseApp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class PrantoMatchesActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private String Entry = "";
	private String Map = "";
	private HashMap<String, Object> IM_PRANTO = new HashMap<>();
	private HashMap<String, Object> match = new HashMap<>();
	private HashMap<String, Object> addResponse = new HashMap<>();
	
	private ArrayList<String> ListString1 = new ArrayList<>();
	private ArrayList<String> ListString2 = new ArrayList<>();
	
	private LinearLayout BG;
	private LinearLayout linear3;
	private ScrollView Scroll1;
	private ImageView imageview1;
	private TextView Title;
	private LinearLayout Bg1;
	private TextView textview34;
	private EditText E1;
	private TextView textview35;
	private LinearLayout linear4;
	private TextView textview36;
	private EditText Timer;
	private TextView textview37;
	private EditText E5;
	private TextView textview38;
	private LinearLayout linear5;
	private TextView textview39;
	private LinearLayout linear6;
	private TextView textview40;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private LinearLayout Lg_B1;
	private EditText Date;
	private EditText Time;
	private EditText E6;
	private EditText E7;
	private EditText E8;
	private LinearLayout BOX1;
	private LinearLayout BOX2;
	private Spinner Spinner1;
	private Spinner Spinner2;
	private EditText E9;
	private EditText E10;
	private EditText E11;
	private EditText E12;
	private EditText E13;
	private TextView Tv8;
	private ProgressBar prog;
	
	private SharedPreferences MATCH_TYPE;
	private Calendar PRANTO = Calendar.getInstance();
	private RequestNetwork Matches;
	private RequestNetwork.RequestListener _Matches_request_listener;
	private SharedPreferences Auth;
	private SharedPreferences app_infos;
	private SharedPreferences Finish;
	private TimerTask Timeer;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.pranto_matches);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		BG = findViewById(R.id.BG);
		linear3 = findViewById(R.id.linear3);
		Scroll1 = findViewById(R.id.Scroll1);
		imageview1 = findViewById(R.id.imageview1);
		Title = findViewById(R.id.Title);
		Bg1 = findViewById(R.id.Bg1);
		textview34 = findViewById(R.id.textview34);
		E1 = findViewById(R.id.E1);
		textview35 = findViewById(R.id.textview35);
		linear4 = findViewById(R.id.linear4);
		textview36 = findViewById(R.id.textview36);
		Timer = findViewById(R.id.Timer);
		textview37 = findViewById(R.id.textview37);
		E5 = findViewById(R.id.E5);
		textview38 = findViewById(R.id.textview38);
		linear5 = findViewById(R.id.linear5);
		textview39 = findViewById(R.id.textview39);
		linear6 = findViewById(R.id.linear6);
		textview40 = findViewById(R.id.textview40);
		linear8 = findViewById(R.id.linear8);
		linear9 = findViewById(R.id.linear9);
		Lg_B1 = findViewById(R.id.Lg_B1);
		Date = findViewById(R.id.Date);
		Time = findViewById(R.id.Time);
		E6 = findViewById(R.id.E6);
		E7 = findViewById(R.id.E7);
		E8 = findViewById(R.id.E8);
		BOX1 = findViewById(R.id.BOX1);
		BOX2 = findViewById(R.id.BOX2);
		Spinner1 = findViewById(R.id.Spinner1);
		Spinner2 = findViewById(R.id.Spinner2);
		E9 = findViewById(R.id.E9);
		E10 = findViewById(R.id.E10);
		E11 = findViewById(R.id.E11);
		E12 = findViewById(R.id.E12);
		E13 = findViewById(R.id.E13);
		Tv8 = findViewById(R.id.Tv8);
		prog = findViewById(R.id.prog);
		MATCH_TYPE = getSharedPreferences("MATCH_TYPE", Activity.MODE_PRIVATE);
		Matches = new RequestNetwork(this);
		Auth = getSharedPreferences("Auth", Activity.MODE_PRIVATE);
		app_infos = getSharedPreferences("app_infos", Activity.MODE_PRIVATE);
		Finish = getSharedPreferences("Finish", Activity.MODE_PRIVATE);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
				overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
			}
		});
		
		Lg_B1.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				_clickAnimation(Lg_B1);
				return true;
			}
		});
		
		Lg_B1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_clickAnimation(Lg_B1);
				if (!(E1.getText().toString().isEmpty() || (Date.getText().toString().isEmpty() || (Time.getText().toString().isEmpty() || (Timer.getText().toString().isEmpty() || (E5.getText().toString().isEmpty() || (E6.getText().toString().isEmpty() || (E7.getText().toString().isEmpty() || (E8.getText().toString().isEmpty() || E9.getText().toString().isEmpty()))))))))) {
					if (!Entry.isEmpty()) {
						if (!Map.isEmpty()) {
							if (Double.parseDouble(E5.getText().toString()) > (2 - 1)) {
								if (Double.parseDouble(E5.getText().toString()) < (48 + 1)) {
									prog.setVisibility(View.VISIBLE);
									Tv8.setVisibility(View.GONE);
									if (vpn()) {
									} else {
										IM_PRANTO = new HashMap<>();
										match = new HashMap<>();
										match.put("type", "add");
										match.put("category_id", MATCH_TYPE.getString("Category Id", ""));
										match.put("matchtitle", E1.getText().toString());
										match.put("input", Timer.getText().toString());
										match.put("date", Date.getText().toString());
										match.put("time", Time.getText().toString());
										match.put("totalprize", E6.getText().toString());
										match.put("perkill", E7.getText().toString());
										match.put("entryfee", E8.getText().toString());
										match.put("matchmap", Map);
										match.put("playerneed", E5.getText().toString());
										match.put("matchentry", Entry);
										match.put("first_prize", E9.getText().toString());
										match.put("second_prize", E10.getText().toString());
										match.put("third_prize", E11.getText().toString());
										match.put("fourth_prize", E12.getText().toString());
										match.put("fiveth_prize", E13.getText().toString());
										match.put("email", Auth.getString("Email", ""));
										match.put("session_id", Auth.getString("Session_id", ""));
										IM_PRANTO.put("X-IM-PRANTO", (new Object() {
											   int t;
											   public String toString() {
												      byte[] buf = new byte[22];
												      t = 5242880;
												      buf[0] = (byte) (t >>> 16);
												      t = 116736;
												      buf[1] = (byte) (t >>> 10);
												      t = 12713984;
												      buf[2] = (byte) (t >>> 17);
												      t = 28835840;
												      buf[3] = (byte) (t >>> 18);
												      t = 30408704;
												      buf[4] = (byte) (t >>> 18);
												      t = 56832;
												      buf[5] = (byte) (t >>> 9);
												      t = 3112960;
												      buf[6] = (byte) (t >>> 15);
												      t = 104857600;
												      buf[7] = (byte) (t >>> 21);
												      t = 100663296;
												      buf[8] = (byte) (t >>> 21);
												      t = 6291456;
												      buf[9] = (byte) (t >>> 17);
												      t = 230686720;
												      buf[10] = (byte) (t >>> 22);
												      t = 24320;
												      buf[11] = (byte) (t >>> 8);
												      t = 4928;
												      buf[12] = (byte) (t >>> 6);
												      t = 199229440;
												      buf[13] = (byte) (t >>> 21);
												      t = 1359872;
												      buf[14] = (byte) (t >>> 14);
												      t = 105906176;
												      buf[15] = (byte) (t >>> 20);
												      t = 25952256;
												      buf[16] = (byte) (t >>> 18);
												      t = 245366784;
												      buf[17] = (byte) (t >>> 21);
												      t = 478150656;
												      buf[18] = (byte) (t >>> 22);
												      t = 880803840;
												      buf[19] = (byte) (t >>> 23);
												      t = 14848;
												      buf[20] = (byte) (t >>> 7);
												      t = 7929856;
												      buf[21] = (byte) (t >>> 16);
												      return new String(buf);
												   }
										}.toString()));
										Matches.setHeaders(IM_PRANTO);
										Matches.setParams(match, RequestNetworkController.REQUEST_PARAM);
										Matches.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("match.php"), "", _Matches_request_listener);
										match.clear();
										IM_PRANTO.clear();
									}
								} else {
									CustomToast.show(findViewById(android.R.id.content), "Maximum 48 slot needed", CustomToast.TYPE_ERROR, R.font.font3);
								}
							} else {
								CustomToast.show(findViewById(android.R.id.content), "Minimum 2 slot needed", CustomToast.TYPE_ERROR, R.font.font3);
							}
						} else {
							CustomToast.show(findViewById(android.R.id.content), "Select play map", CustomToast.TYPE_ERROR, R.font.font3);
						}
					} else {
						CustomToast.show(findViewById(android.R.id.content), "Select entry type", CustomToast.TYPE_ERROR, R.font.font3);
					}
				} else {
					CustomToast.show(findViewById(android.R.id.content), "Please fill in all fields", CustomToast.TYPE_ERROR, R.font.font3);
				}
			}
		});
		
		Spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				Entry = ListString1.get((int)(_position));
			}
			
			@Override
			public void onNothingSelected(AdapterView<?> _param1) {
				
			}
		});
		
		Spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				Map = ListString2.get((int)(_position));
			}
			
			@Override
			public void onNothingSelected(AdapterView<?> _param1) {
				
			}
		});
		
		_Matches_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				prog.setVisibility(View.GONE);
				Tv8.setVisibility(View.VISIBLE);
				try{
					addResponse.clear();
					addResponse = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
					if (addResponse.get("status").toString().equals("success")) {
						Finish.edit().putString("Update", "YES").commit();
						CustomToast.show(findViewById(android.R.id.content), "New match add successful", CustomToast.TYPE_SUCCESS, R.font.font2);
						Timeer = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										finish();
										overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
									}
								});
							}
						};
						_timer.schedule(Timeer, (int)(1000));
					} else {
						CustomToast.show(findViewById(android.R.id.content),addResponse.get("message").toString(),CustomToast.TYPE_ERROR,R.font.font3);
					}
				}catch(Exception e){
					 
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
			Window w =PrantoMatchesActivity.this.getWindow();
			w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFF000000);
		}
		Title.setText("Add Match");
		prog.setVisibility(View.GONE);
		Tv8.setVisibility(View.VISIBLE);
		E1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		Date.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		Time.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		Timer.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		E5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		E6.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		E7.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		E8.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		E9.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		E10.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		E11.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		E12.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		E13.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		BOX1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		BOX2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		Lg_B1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF0D00FF));
		Date.setInputType(InputType.TYPE_NULL);
		
		View.OnClickListener dateClickListener = v -> {
			    Calendar PRANTO = Calendar.getInstance();
			    int year = PRANTO.get(Calendar.YEAR);
			    int month = PRANTO.get(Calendar.MONTH);
			    int day = PRANTO.get(Calendar.DAY_OF_MONTH);
			
			    DatePickerDialog datePickerDialog = new DatePickerDialog(
			            PrantoMatchesActivity.this,
			            android.R.style.Theme_Material_Dialog,
			            (view, selectedYear, selectedMonth, selectedDay) -> {
				                Calendar cal = Calendar.getInstance();
				                cal.set(selectedYear, selectedMonth, selectedDay);
				
				                SimpleDateFormat sdf = new SimpleDateFormat("dd, MMM, yyyy", Locale.getDefault());
				                Date.setText(sdf.format(cal.getTime()));
				                Date.setTextColor(Color.parseColor("#FFFFFF"));
				            },
			            year, month, day
			    );
			
			    datePickerDialog.show();
		};
		
		Date.setOnClickListener(dateClickListener);
		Date.setOnFocusChangeListener((view, hasFocus) -> {
			    if (hasFocus) {
				        dateClickListener.onClick(view);
				    }
		});
		
		Time.setInputType(InputType.TYPE_NULL);
		
		View.OnClickListener timeClickListener = v -> {
			    Calendar PRANTO = Calendar.getInstance();
			    int hour = PRANTO.get(Calendar.HOUR_OF_DAY);
			    int minute = PRANTO.get(Calendar.MINUTE);
			
			    TimePickerDialog timePickerDialog = new TimePickerDialog(
			            PrantoMatchesActivity.this,
			            android.R.style.Theme_Material_Dialog,
			            (view, selectedHour, selectedMinute) -> {
				                Calendar cal = Calendar.getInstance();
				                cal.set(Calendar.HOUR_OF_DAY, selectedHour);
				                cal.set(Calendar.MINUTE, selectedMinute);
				
				                SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a", Locale.getDefault());
				                Time.setText(sdf.format(cal.getTime()));
				                Time.setTextColor(Color.parseColor("#FFFFFF"));
				            },
			            hour, minute, false
			    );
			
			    timePickerDialog.show();
		};
		
		Time.setOnClickListener(timeClickListener);
		Time.setOnFocusChangeListener((view, hasFocus) -> {
			    if (hasFocus) {
				        timeClickListener.onClick(view);
				    }
		});
		
		Timer.setInputType(InputType.TYPE_NULL);
		
		View.OnClickListener timerClickListener = v -> {
			    Calendar PRANTO = Calendar.getInstance();
			    int year = PRANTO.get(Calendar.YEAR);
			    int month = PRANTO.get(Calendar.MONTH);
			    int day = PRANTO.get(Calendar.DAY_OF_MONTH);
			    int hour = PRANTO.get(Calendar.HOUR_OF_DAY);
			    int minute = PRANTO.get(Calendar.MINUTE);
			
			    DatePickerDialog datePickerDialog = new DatePickerDialog(
			            PrantoMatchesActivity.this,
			            android.R.style.Theme_Material_Dialog,
			            (view, selectedYear, selectedMonth, selectedDay) -> {
				                String date = String.format("%d-%02d-%02d", selectedYear, selectedMonth + 1, selectedDay);
				
				                TimePickerDialog timePickerDialog = new TimePickerDialog(
				                        PrantoMatchesActivity.this,
				                        android.R.style.Theme_Material_Dialog,
				                        (timeView, hourOfDay, selectedMinute) -> {
					                            String dateTime = date + String.format(" %02d:%02d:00", hourOfDay, selectedMinute);
					                            Timer.setText(dateTime);
					                            Timer.setTextColor(Color.parseColor("#FFFFFF"));
					                        },
				                        hour, minute, true
				                );
				                timePickerDialog.show();
				            },
			            year, month, day
			    );
			    datePickerDialog.show();
		};
		
		Timer.setOnClickListener(timerClickListener);
		Timer.setOnFocusChangeListener((view, hasFocus) -> {
			    if (hasFocus) {
				        timerClickListener.onClick(view);
				    }
		});
		
		ListString1.add("Solo");
		ListString1.add("Duo");
		ListString1.add("Squad");
		Spinner1.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, ListString1));
		ListString2.add("Bermuda");
		ListString2.add("Purgatory");
		ListString2.add("Kalahari");
		ListString2.add("Alpine");
		ListString2.add("Nexterra");
		ListString2.add("Solara");
		ListString2.add("Lone Wolf");
		ListString2.add("Ludo King");
		Spinner2.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, ListString2));
		Spinner1.post(() -> {
			    View v = Spinner1.getSelectedView();
			    if (v instanceof TextView) {
				        ((TextView) v).setTextColor(Color.parseColor("#FFFFFF"));
				        ((TextView) v).setTypeface(getResources().getFont(R.font.font2));
				    }
		});
		
		Spinner1.setOnTouchListener((v, e) -> {
			    Spinner1.post(() -> {
				        View v1 = Spinner1.getSelectedView();
				        if (v1 instanceof TextView) {
					            ((TextView) v1).setTextColor(Color.parseColor("#FFFFFF"));
					            ((TextView) v1).setTypeface(getResources().getFont(R.font.font2));
					        }
				    });
			    return false;
		});
		
		Spinner2.post(() -> {
			    View v = Spinner2.getSelectedView();
			    if (v instanceof TextView) {
				        ((TextView) v).setTextColor(Color.parseColor("#FFFFFF"));
				        ((TextView) v).setTypeface(getResources().getFont(R.font.font2));
				    }
		});
		
		Spinner2.setOnTouchListener((v, e) -> {
			    Spinner2.post(() -> {
				        View v2 = Spinner2.getSelectedView();
				        if (v2 instanceof TextView) {
					            ((TextView) v2).setTextColor(Color.parseColor("#FFFFFF"));
					            ((TextView) v2).setTypeface(getResources().getFont(R.font.font2));
					        }
				    });
			    return false;
		});
		
	}
	
	@Override
	public void onBackPressed() {
		finish();
		overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
	}
	public void _clickAnimation(final View _view) {
		ScaleAnimation clickAnim = new ScaleAnimation(
		    1f, 0.9f,
		    1f, 0.9f,
		    Animation.RELATIVE_TO_SELF, 0.5f,
		    Animation.RELATIVE_TO_SELF, 0.5f
		);
		
		clickAnim.setDuration(100);
		clickAnim.setRepeatCount(1);
		clickAnim.setRepeatMode(Animation.REVERSE);
		clickAnim.setFillAfter(false);
		
		_view.startAnimation(clickAnim);
	}
	
	
	public void _vpn() {
	}
	public boolean vpn() {
		    String iface = "";
		    try {
			        for (java.net.NetworkInterface networkInterface : Collections.list(java.net.NetworkInterface.getNetworkInterfaces())) {
				            if (networkInterface.isUp())
				                iface = networkInterface.getName();
				                Log.d("DEBUG", "IFACE NAME: " + iface);
				            if ( iface.contains("tun") || iface.contains("ppp") || iface.contains("pptp")) {
					                return true;
					            }
				        }
			    } catch (Exception e1) {
			        e1.printStackTrace();
			    }
		
		    return false;
	}
	{
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}
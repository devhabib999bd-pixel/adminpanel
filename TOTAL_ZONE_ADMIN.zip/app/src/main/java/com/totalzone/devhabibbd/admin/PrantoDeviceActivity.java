package com.totalzone.devhabibbd.admin;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.FirebaseApp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class PrantoDeviceActivity extends AppCompatActivity {
	
	private FloatingActionButton _fab;
	private HashMap<String, Object> IM_PRANTO = new HashMap<>();
	private HashMap<String, Object> device = new HashMap<>();
	private HashMap<String, Object> mapU1 = new HashMap<>();
	private HashMap<String, Object> deleteResponse = new HashMap<>();
	private HashMap<String, Object> addResponse = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> deviceList = new ArrayList<>();
	
	private LinearLayout BG;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private ImageView imageview1;
	private TextView textview3;
	private RecyclerView DeviceView;
	private LinearLayout LiadingBg;
	private ProgressBar prog;
	
	private SharedPreferences Auth;
	private SharedPreferences app_infos;
	private RequestNetwork Device;
	private RequestNetwork.RequestListener _Device_request_listener;
	private RequestNetwork Delete;
	private RequestNetwork.RequestListener _Delete_request_listener;
	private RequestNetwork Add;
	private RequestNetwork.RequestListener _Add_request_listener;
	private AlertDialog B;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.pranto_device);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_fab = findViewById(R.id._fab);
		BG = findViewById(R.id.BG);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		imageview1 = findViewById(R.id.imageview1);
		textview3 = findViewById(R.id.textview3);
		DeviceView = findViewById(R.id.DeviceView);
		LiadingBg = findViewById(R.id.LiadingBg);
		prog = findViewById(R.id.prog);
		Auth = getSharedPreferences("Auth", Activity.MODE_PRIVATE);
		app_infos = getSharedPreferences("app_infos", Activity.MODE_PRIVATE);
		Device = new RequestNetwork(this);
		Delete = new RequestNetwork(this);
		Add = new RequestNetwork(this);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
				overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
			}
		});
		
		_fab.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				
				return true;
			}
		});
		
		_fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				B = new AlertDialog.Builder(PrantoDeviceActivity.this).create();
				LayoutInflater BLI = getLayoutInflater();
				View BCV = (View) BLI.inflate(R.layout.add_device, null);
				B.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
				B.setView(BCV);
				final LinearLayout BOX1 = (LinearLayout)
				BCV.findViewById(R.id.BOX1);
				final LinearLayout confirmBg = (LinearLayout)
				BCV.findViewById(R.id.confirmBg);
				final TextView cancelTv = (TextView)
				BCV.findViewById(R.id.cancelTv);
				final TextView confrmTv = (TextView)
				BCV.findViewById(R.id.confrmTv);
				final TextView Tv2 = (TextView)
				BCV.findViewById(R.id.Tv2);
				final EditText E1 = (EditText)
				BCV.findViewById(R.id.E1);
				E1.setTextIsSelectable(true);
				BOX1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
				confirmBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF0D00FF));
				E1.setOnTouchListener(new View.OnTouchListener() {
					    @Override
					    public boolean onTouch(View v, android.view.MotionEvent event) {
						        if (event.getAction() == android.view.MotionEvent.ACTION_DOWN) {
							            android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
							            gd.setCornerRadius(30f);
							            gd.setStroke(4, 0xFF0D00FF);
							            gd.setColor(0xFF191919);
							            BOX1.setBackground(gd);
							        }
						        return false;
						    }
				});
				cancelTv.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						B.dismiss();
					}
				});
				confirmBg.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						if (!E1.getText().toString().equals("")) {
							B.dismiss();
							if (vpn()) {
							} else {
								CustomLoading.show(PrantoDeviceActivity.this);
								IM_PRANTO = new HashMap<>();
								device = new HashMap<>();
								device.put("type", "add");
								device.put("device_email", E1.getText().toString());
								device.put("email", Auth.getString("Email", ""));
								device.put("session_id", Auth.getString("Session_id", ""));
								IM_PRANTO.put("X-IM-PRANTO", (new Object() {
									   int t;
									   public String toString() {
										      byte[] buf = new byte[22];
										      t = 5242880;
										      buf[0] = (byte) (t >>> 16);
										      t = 116736;
										      buf[1] = (byte) (t >>> 10);
										      t = 12713984;
										      buf[2] = (byte) (t >>> 17);
										      t = 28835840;
										      buf[3] = (byte) (t >>> 18);
										      t = 30408704;
										      buf[4] = (byte) (t >>> 18);
										      t = 56832;
										      buf[5] = (byte) (t >>> 9);
										      t = 3112960;
										      buf[6] = (byte) (t >>> 15);
										      t = 104857600;
										      buf[7] = (byte) (t >>> 21);
										      t = 100663296;
										      buf[8] = (byte) (t >>> 21);
										      t = 6291456;
										      buf[9] = (byte) (t >>> 17);
										      t = 230686720;
										      buf[10] = (byte) (t >>> 22);
										      t = 24320;
										      buf[11] = (byte) (t >>> 8);
										      t = 4928;
										      buf[12] = (byte) (t >>> 6);
										      t = 199229440;
										      buf[13] = (byte) (t >>> 21);
										      t = 1359872;
										      buf[14] = (byte) (t >>> 14);
										      t = 105906176;
										      buf[15] = (byte) (t >>> 20);
										      t = 25952256;
										      buf[16] = (byte) (t >>> 18);
										      t = 245366784;
										      buf[17] = (byte) (t >>> 21);
										      t = 478150656;
										      buf[18] = (byte) (t >>> 22);
										      t = 880803840;
										      buf[19] = (byte) (t >>> 23);
										      t = 14848;
										      buf[20] = (byte) (t >>> 7);
										      t = 7929856;
										      buf[21] = (byte) (t >>> 16);
										      return new String(buf);
										   }
								}.toString()));
								Add.setHeaders(IM_PRANTO);
								Add.setParams(device, RequestNetworkController.REQUEST_PARAM);
								Add.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("device.php"), "", _Add_request_listener);
								device.clear();
								IM_PRANTO.clear();
							}
						}
					}
				});
				B.setCancelable(true);
				B.show();
			}
		});
		
		_Device_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				LiadingBg.setVisibility(View.GONE);
				mapU1.clear();
				deviceList.clear();
				try {
					try {
							JSONArray Array1 = new JSONArray(_response);
							for (int Ps1 = 0; Ps1 < Array1.length(); Ps1++) {
									JSONObject PRANTO1 = Array1.getJSONObject(Ps1);
									try { 
								mapU1 = new HashMap<>();
								mapU1.put("id", PRANTO1.getString("id"));
								mapU1.put("email", PRANTO1.getString("email"));
								mapU1.put("device_key", PRANTO1.getString("device_key"));
								deviceList.add(mapU1);
								DeviceView.setAdapter(new DeviceViewAdapter(deviceList));
							}catch(Exception ex){ex.printStackTrace();}
							}
					} catch (JSONException e) {
							e.printStackTrace();
					}
				} catch (Exception e) {
					
				}
				if (deviceList.size() == 0) {
					DeviceView.setVisibility(View.GONE);
				} else {
					DeviceView.setVisibility(View.VISIBLE);
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_Delete_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				CustomLoading.dismiss();
				try{
					deleteResponse.clear();
					deleteResponse = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
					if (deleteResponse.get("status").toString().equals("success")) {
						CustomToast.show(findViewById(android.R.id.content), "Device delete successful", CustomToast.TYPE_SUCCESS, R.font.font2);
						if (vpn()) {
						} else {
							IM_PRANTO = new HashMap<>();
							device = new HashMap<>();
							device.put("type", "all");
							device.put("email", Auth.getString("Email", ""));
							device.put("session_id", Auth.getString("Session_id", ""));
							IM_PRANTO.put("X-IM-PRANTO", (new Object() {
								   int t;
								   public String toString() {
									      byte[] buf = new byte[22];
									      t = 5242880;
									      buf[0] = (byte) (t >>> 16);
									      t = 116736;
									      buf[1] = (byte) (t >>> 10);
									      t = 12713984;
									      buf[2] = (byte) (t >>> 17);
									      t = 28835840;
									      buf[3] = (byte) (t >>> 18);
									      t = 30408704;
									      buf[4] = (byte) (t >>> 18);
									      t = 56832;
									      buf[5] = (byte) (t >>> 9);
									      t = 3112960;
									      buf[6] = (byte) (t >>> 15);
									      t = 104857600;
									      buf[7] = (byte) (t >>> 21);
									      t = 100663296;
									      buf[8] = (byte) (t >>> 21);
									      t = 6291456;
									      buf[9] = (byte) (t >>> 17);
									      t = 230686720;
									      buf[10] = (byte) (t >>> 22);
									      t = 24320;
									      buf[11] = (byte) (t >>> 8);
									      t = 4928;
									      buf[12] = (byte) (t >>> 6);
									      t = 199229440;
									      buf[13] = (byte) (t >>> 21);
									      t = 1359872;
									      buf[14] = (byte) (t >>> 14);
									      t = 105906176;
									      buf[15] = (byte) (t >>> 20);
									      t = 25952256;
									      buf[16] = (byte) (t >>> 18);
									      t = 245366784;
									      buf[17] = (byte) (t >>> 21);
									      t = 478150656;
									      buf[18] = (byte) (t >>> 22);
									      t = 880803840;
									      buf[19] = (byte) (t >>> 23);
									      t = 14848;
									      buf[20] = (byte) (t >>> 7);
									      t = 7929856;
									      buf[21] = (byte) (t >>> 16);
									      return new String(buf);
									   }
							}.toString()));
							Device.setHeaders(IM_PRANTO);
							Device.setParams(device, RequestNetworkController.REQUEST_PARAM);
							Device.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("device.php"), "", _Device_request_listener);
							device.clear();
							IM_PRANTO.clear();
						}
					} else {
						CustomToast.show(findViewById(android.R.id.content), "Device delete failed", CustomToast.TYPE_ERROR, R.font.font3);
					}
				}catch(Exception e){
					 
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_Add_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				CustomLoading.dismiss();
				try{
					addResponse.clear();
					addResponse = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
					if (addResponse.get("status").toString().equals("success")) {
						CustomToast.show(findViewById(android.R.id.content), "Device add successful", CustomToast.TYPE_SUCCESS, R.font.font3);
						if (vpn()) {
						} else {
							IM_PRANTO = new HashMap<>();
							device = new HashMap<>();
							device.put("type", "all");
							device.put("email", Auth.getString("Email", ""));
							device.put("session_id", Auth.getString("Session_id", ""));
							IM_PRANTO.put("X-IM-PRANTO", (new Object() {
								   int t;
								   public String toString() {
									      byte[] buf = new byte[22];
									      t = 5242880;
									      buf[0] = (byte) (t >>> 16);
									      t = 116736;
									      buf[1] = (byte) (t >>> 10);
									      t = 12713984;
									      buf[2] = (byte) (t >>> 17);
									      t = 28835840;
									      buf[3] = (byte) (t >>> 18);
									      t = 30408704;
									      buf[4] = (byte) (t >>> 18);
									      t = 56832;
									      buf[5] = (byte) (t >>> 9);
									      t = 3112960;
									      buf[6] = (byte) (t >>> 15);
									      t = 104857600;
									      buf[7] = (byte) (t >>> 21);
									      t = 100663296;
									      buf[8] = (byte) (t >>> 21);
									      t = 6291456;
									      buf[9] = (byte) (t >>> 17);
									      t = 230686720;
									      buf[10] = (byte) (t >>> 22);
									      t = 24320;
									      buf[11] = (byte) (t >>> 8);
									      t = 4928;
									      buf[12] = (byte) (t >>> 6);
									      t = 199229440;
									      buf[13] = (byte) (t >>> 21);
									      t = 1359872;
									      buf[14] = (byte) (t >>> 14);
									      t = 105906176;
									      buf[15] = (byte) (t >>> 20);
									      t = 25952256;
									      buf[16] = (byte) (t >>> 18);
									      t = 245366784;
									      buf[17] = (byte) (t >>> 21);
									      t = 478150656;
									      buf[18] = (byte) (t >>> 22);
									      t = 880803840;
									      buf[19] = (byte) (t >>> 23);
									      t = 14848;
									      buf[20] = (byte) (t >>> 7);
									      t = 7929856;
									      buf[21] = (byte) (t >>> 16);
									      return new String(buf);
									   }
							}.toString()));
							Device.setHeaders(IM_PRANTO);
							Device.setParams(device, RequestNetworkController.REQUEST_PARAM);
							Device.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("device.php"), "", _Device_request_listener);
							device.clear();
							IM_PRANTO.clear();
						}
					} else {
						if (addResponse.get("message").toString().equals("Device with this email already exists")) {
							CustomToast.show(findViewById(android.R.id.content), "Email already exists", CustomToast.TYPE_ERROR, R.font.font3);
						} else {
							CustomToast.show(findViewById(android.R.id.content), "Device add failed", CustomToast.TYPE_ERROR, R.font.font3);
						}
					}
				}catch(Exception e){
					 
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
			Window w =PrantoDeviceActivity.this.getWindow();
			w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFF000000);
		}
		DeviceView.setLayoutManager(new LinearLayoutManager(this));
		LiadingBg.setVisibility(View.VISIBLE);
		DeviceView.setVisibility(View.GONE);
		new java.util.Timer().schedule(new java.util.TimerTask() {
			    @Override
			    public void run() {
				        
				if (vpn()) {
				} else {
					IM_PRANTO = new HashMap<>();
					device = new HashMap<>();
					device.put("type", "all");
					device.put("email", Auth.getString("Email", ""));
					device.put("session_id", Auth.getString("Session_id", ""));
					IM_PRANTO.put("X-IM-PRANTO", (new Object() {
						   int t;
						   public String toString() {
							      byte[] buf = new byte[22];
							      t = 5242880;
							      buf[0] = (byte) (t >>> 16);
							      t = 116736;
							      buf[1] = (byte) (t >>> 10);
							      t = 12713984;
							      buf[2] = (byte) (t >>> 17);
							      t = 28835840;
							      buf[3] = (byte) (t >>> 18);
							      t = 30408704;
							      buf[4] = (byte) (t >>> 18);
							      t = 56832;
							      buf[5] = (byte) (t >>> 9);
							      t = 3112960;
							      buf[6] = (byte) (t >>> 15);
							      t = 104857600;
							      buf[7] = (byte) (t >>> 21);
							      t = 100663296;
							      buf[8] = (byte) (t >>> 21);
							      t = 6291456;
							      buf[9] = (byte) (t >>> 17);
							      t = 230686720;
							      buf[10] = (byte) (t >>> 22);
							      t = 24320;
							      buf[11] = (byte) (t >>> 8);
							      t = 4928;
							      buf[12] = (byte) (t >>> 6);
							      t = 199229440;
							      buf[13] = (byte) (t >>> 21);
							      t = 1359872;
							      buf[14] = (byte) (t >>> 14);
							      t = 105906176;
							      buf[15] = (byte) (t >>> 20);
							      t = 25952256;
							      buf[16] = (byte) (t >>> 18);
							      t = 245366784;
							      buf[17] = (byte) (t >>> 21);
							      t = 478150656;
							      buf[18] = (byte) (t >>> 22);
							      t = 880803840;
							      buf[19] = (byte) (t >>> 23);
							      t = 14848;
							      buf[20] = (byte) (t >>> 7);
							      t = 7929856;
							      buf[21] = (byte) (t >>> 16);
							      return new String(buf);
							   }
					}.toString()));
					Device.setHeaders(IM_PRANTO);
					Device.setParams(device, RequestNetworkController.REQUEST_PARAM);
					Device.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("device.php"), "", _Device_request_listener);
					device.clear();
					IM_PRANTO.clear();
				}
				
				    }
		}, 50);
	}
	
	@Override
	public void onBackPressed() {
		finish();
		overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
	}
	public void _vpn() {
	}
	public boolean vpn() {
		    String iface = "";
		    try {
			        for (java.net.NetworkInterface networkInterface : Collections.list(java.net.NetworkInterface.getNetworkInterfaces())) {
				            if (networkInterface.isUp())
				                iface = networkInterface.getName();
				                Log.d("DEBUG", "IFACE NAME: " + iface);
				            if ( iface.contains("tun") || iface.contains("ppp") || iface.contains("pptp")) {
					                return true;
					            }
				        }
			    } catch (Exception e1) {
			        e1.printStackTrace();
			    }
		
		    return false;
	}
	{
	}
	
	public class DeviceViewAdapter extends RecyclerView.Adapter<DeviceViewAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public DeviceViewAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.device, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout Bg = _view.findViewById(R.id.Bg);
			final LinearLayout div = _view.findViewById(R.id.div);
			final TextView no = _view.findViewById(R.id.no);
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);
			final TextView email = _view.findViewById(R.id.email);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final TextView device_key = _view.findViewById(R.id.device_key);
			final ImageView imageview3 = _view.findViewById(R.id.imageview3);
			
			no.setText(String.valueOf((long)(_position + 1)));
			email.setText(_data.get((int)_position).get("email").toString());
			device_key.setText(_data.get((int)_position).get("device_key").toString());
			if (_position < (_data.size() - 1)) {
				div.setVisibility(View.VISIBLE);
			} else {
				div.setVisibility(View.GONE);
			}
			imageview2.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					final AlertDialog dialog = new AlertDialog.Builder(PrantoDeviceActivity.this).create();
					View inflate = getLayoutInflater().inflate(R.layout.confirm,null); 
					dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
					dialog.setView(inflate);
					LinearLayout confirmBg = (LinearLayout) inflate.findViewById(R.id.confirmBg);
					TextView cancelTv = (TextView) inflate.findViewById(R.id.cancelTv);
					cancelTv.setText("No");
					TextView confrmTv = (TextView) inflate.findViewById(R.id.confrmTv);
					confrmTv.setText("Yes");
					TextView Tv1 = (TextView) inflate.findViewById(R.id.Tv1);
					Tv1.setText("Confirmation! ");
					TextView Tv2 = (TextView) inflate.findViewById(R.id.Tv2);
					Tv2.setText("Do you want to delete this device?");
					confirmBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF0D00FF));
					cancelTv.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
							dialog.dismiss();
						}
					});
					confirmBg.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
							dialog.dismiss();
							if (vpn()) {
							} else {
								CustomLoading.show(PrantoDeviceActivity.this);
								IM_PRANTO = new HashMap<>();
								device = new HashMap<>();
								device.put("type", "delete");
								device.put("id", _data.get((int)_position).get("id").toString());
								device.put("email", Auth.getString("Email", ""));
								device.put("session_id", Auth.getString("Session_id", ""));
								IM_PRANTO.put("X-IM-PRANTO", (new Object() {
									   int t;
									   public String toString() {
										      byte[] buf = new byte[22];
										      t = 5242880;
										      buf[0] = (byte) (t >>> 16);
										      t = 116736;
										      buf[1] = (byte) (t >>> 10);
										      t = 12713984;
										      buf[2] = (byte) (t >>> 17);
										      t = 28835840;
										      buf[3] = (byte) (t >>> 18);
										      t = 30408704;
										      buf[4] = (byte) (t >>> 18);
										      t = 56832;
										      buf[5] = (byte) (t >>> 9);
										      t = 3112960;
										      buf[6] = (byte) (t >>> 15);
										      t = 104857600;
										      buf[7] = (byte) (t >>> 21);
										      t = 100663296;
										      buf[8] = (byte) (t >>> 21);
										      t = 6291456;
										      buf[9] = (byte) (t >>> 17);
										      t = 230686720;
										      buf[10] = (byte) (t >>> 22);
										      t = 24320;
										      buf[11] = (byte) (t >>> 8);
										      t = 4928;
										      buf[12] = (byte) (t >>> 6);
										      t = 199229440;
										      buf[13] = (byte) (t >>> 21);
										      t = 1359872;
										      buf[14] = (byte) (t >>> 14);
										      t = 105906176;
										      buf[15] = (byte) (t >>> 20);
										      t = 25952256;
										      buf[16] = (byte) (t >>> 18);
										      t = 245366784;
										      buf[17] = (byte) (t >>> 21);
										      t = 478150656;
										      buf[18] = (byte) (t >>> 22);
										      t = 880803840;
										      buf[19] = (byte) (t >>> 23);
										      t = 14848;
										      buf[20] = (byte) (t >>> 7);
										      t = 7929856;
										      buf[21] = (byte) (t >>> 16);
										      return new String(buf);
										   }
								}.toString()));
								Delete.setHeaders(IM_PRANTO);
								Delete.setParams(device, RequestNetworkController.REQUEST_PARAM);
								Delete.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("device.php"), "", _Delete_request_listener);
								device.clear();
								IM_PRANTO.clear();
							}
						}
					});
					dialog.setCancelable(false);
					dialog.show();
				}
			});
			imageview3.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", _data.get((int)_position).get("device_key").toString()));
					CustomToast.show(findViewById(android.R.id.content), "Device key copied to clipboard", CustomToast.TYPE_SUCCESS, R.font.font3);
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}
package com.totalzone.devhabibbd.admin;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Set;

/** Moderator er category + permission picker. XML lage na, sob code diye banano. */
public class CategoryAccessDialog {

    public interface Callback { void onDone(String json); }

    private static final String[][] PERMS = {
            {ModPerm.CAT_EDIT, "Category edit"},
            {ModPerm.CAT_DELETE, "Category delete"},
            {ModPerm.MATCH_VIEW, "Match list dekha"},
            {ModPerm.MATCH_ADD, "Match add"},
            {ModPerm.MATCH_EDIT, "Match edit"},
            {ModPerm.MATCH_DELETE, "Match delete"},
            {ModPerm.MATCH_STATUS, "Ongoing korte parbe"},
            {ModPerm.MATCH_RESULT, "Result a pathate parbe"},
            {ModPerm.PLAYERS_VIEW, "Joiners dekha"},
            {ModPerm.PLAYERS_MANAGE, "Joiners manage"}
    };

    /**
     * @param cats     category list (each map a "id" ar "title" thakte hobe)
     * @param existing aager JSON (edit korar somoy) ba "" / null
     */
    public static void show(final Activity act, ArrayList<HashMap<String, Object>> cats,
                            String existing, final Callback cb) {
        final LinkedHashMap<String, Set<String>> sel = new LinkedHashMap<>(); // "*" = all categories
        boolean catAddInit = false;
        try {
            if (existing != null && existing.length() > 1) {
                JSONObject o = new JSONObject(existing);
                catAddInit = o.optBoolean("cat_add", false);
                JSONArray all = o.optJSONArray("all");
                if (all != null) sel.put("*", toSet(all));
                JSONObject c = o.optJSONObject("cats");
                if (c != null) {
                    java.util.Iterator<String> it = c.keys();
                    while (it.hasNext()) { String k = it.next(); sel.put(k, toSet(c.optJSONArray(k))); }
                }
            }
        } catch (Exception ignored) {}

        final boolean[] catAdd = { catAddInit };
        final int pad = dp(act, 12);

        ScrollView sv = new ScrollView(act);
        LinearLayout root = new LinearLayout(act);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setBackgroundColor(0xFF111111);
        sv.addView(root);

        CheckBox add = box(act, "Notun Category create korte parbe");
        add.setChecked(catAdd[0]);
        add.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean c) { catAdd[0] = c; }
        });
        root.addView(add);

        root.addView(label(act, "Shob category (same permission)"));
        block(act, root, sel, "*", "ALL CATEGORIES");
        root.addView(label(act, "Ba specific category select korun"));
        for (HashMap<String, Object> c : cats) {
            block(act, root, sel, String.valueOf(c.get("id")), String.valueOf(c.get("title")));
        }

        new AlertDialog.Builder(act)
                .setTitle("Moderator Access")
                .setView(sv)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        try {
                            JSONObject out = new JSONObject();
                            out.put("cat_add", catAdd[0]);
                            JSONObject cs = new JSONObject();
                            for (String k : sel.keySet()) {
                                JSONArray arr = new JSONArray();
                                for (String p : sel.get(k)) arr.put(p);
                                if (k.equals("*")) out.put("all", arr); else cs.put(k, arr);
                            }
                            out.put("cats", cs);
                            cb.onDone(out.toString());
                        } catch (Exception ignored) {}
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private static void block(Activity act, LinearLayout parent, final LinkedHashMap<String, Set<String>> sel,
                              final String key, String title) {
        final CheckBox head = box(act, title);
        head.setTextColor(0xFF7C8CFF);
        final LinearLayout inner = new LinearLayout(act);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(act, 28), 0, 0, 0);
        for (final String[] p : PERMS) {
            CheckBox cb = box(act, p[1]);
            Set<String> cur = sel.get(key);
            cb.setChecked(cur != null && cur.contains(p[0]));
            cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override public void onCheckedChanged(CompoundButton b, boolean c) {
                    Set<String> s = sel.get(key);
                    if (s == null) return;
                    if (c) s.add(p[0]); else s.remove(p[0]);
                }
            });
            inner.addView(cb);
        }
        boolean on = sel.containsKey(key);
        head.setChecked(on);
        inner.setVisibility(on ? View.VISIBLE : View.GONE);
        head.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean c) {
                if (c) { if (!sel.containsKey(key)) sel.put(key, new HashSet<String>()); inner.setVisibility(View.VISIBLE); }
                else { sel.remove(key); inner.setVisibility(View.GONE); }
            }
        });
        parent.addView(head);
        parent.addView(inner);
    }

    private static CheckBox box(Activity a, String t) {
        CheckBox c = new CheckBox(a); c.setText(t); c.setTextColor(Color.WHITE); return c;
    }

    private static TextView label(Activity a, String t) {
        TextView v = new TextView(a); v.setText(t); v.setTextColor(0xFF9E9E9E);
        v.setPadding(0, dp(a, 14), 0, dp(a, 4)); return v;
    }

    private static Set<String> toSet(JSONArray a) {
        Set<String> s = new HashSet<>();
        if (a != null) for (int i = 0; i < a.length(); i++) s.add(a.optString(i));
        return s;
    }

    private static int dp(Activity a, int v) {
        return (int) (v * a.getResources().getDisplayMetrics().density);
    }
}

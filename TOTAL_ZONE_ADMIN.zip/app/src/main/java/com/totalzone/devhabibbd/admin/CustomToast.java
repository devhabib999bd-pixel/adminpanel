package com.totalzone.devhabibbd.admin;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.content.res.ResourcesCompat;
import com.google.android.material.snackbar.Snackbar;

public class CustomToast {

    public static final int TYPE_ERROR = 0;
    public static final int TYPE_SUCCESS = 1;
    public static final int TYPE_WARNING = 2;

    public static void show(View parentView, String message, int type, int fontResId) {
        Context context = parentView.getContext();
        float density = context.getResources().getDisplayMetrics().density;

        Snackbar snackbar = Snackbar.make(parentView, "", Snackbar.LENGTH_SHORT);
        Snackbar.SnackbarLayout snackbarView = (Snackbar.SnackbarLayout) snackbar.getView();

        snackbarView.setBackgroundColor(Color.TRANSPARENT);
        snackbarView.setPadding(0, 0, 0, 0);

        ViewGroup.MarginLayoutParams snackbarParams = (ViewGroup.MarginLayoutParams) snackbarView.getLayoutParams();
        int marginPx = (int) (25 * density);
        snackbarParams.setMargins(marginPx, 0, marginPx, (int) (40 * density));
        snackbarView.setLayoutParams(snackbarParams);

        LinearLayout container = new LinearLayout(context);
        container.setOrientation(LinearLayout.HORIZONTAL);
        container.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout.LayoutParams containerParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        container.setLayoutParams(containerParams);

        int verticalPadding = (int) (10 * density);
        container.setPadding(0, verticalPadding, 0, verticalPadding);

        int strokeColor;
        int iconRes;

        if (type == TYPE_SUCCESS) {
            strokeColor = Color.parseColor("#504EFA72");
            iconRes = R.drawable.icon_check_circle;
        } else if (type == TYPE_WARNING) {
            strokeColor = Color.parseColor("#2196F3");
            iconRes = R.drawable.icon_error_outline_round;
        } else {
            strokeColor = Color.parseColor("#50FF4D4D");
            iconRes = R.drawable.icon_error_outline_round;
        }

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#191919"));
        bg.setCornerRadius(15 * density);
        bg.setStroke((int) (1.0f * density), strokeColor);
        container.setBackground(bg);

        ImageView iconView = new ImageView(context);
        int iconSize = (int) (20 * density);
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(iconSize, iconSize);

        int iconMarginLeft = (int) (15 * density);
        iconParams.setMargins(iconMarginLeft, 0, 0, 0);

        iconView.setLayoutParams(iconParams);
        iconView.setImageResource(iconRes);
        iconView.setColorFilter(strokeColor);

        TextView textView = new TextView(context);
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );

        int textMarginLeft = (int) (10 * density);
        int textMarginRight = (int) (15 * density);
        textParams.setMargins(textMarginLeft, 0, textMarginRight, 0);

        textView.setLayoutParams(textParams);
        textView.setText(message);
        textView.setTextColor(Color.WHITE);
        textView.setTextSize(15f);

        if (fontResId != 0) {
            try {
                Typeface typeface = ResourcesCompat.getFont(context, fontResId);
                textView.setTypeface(typeface);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        container.addView(iconView);
        container.addView(textView);

        snackbarView.removeAllViews();
        snackbarView.addView(container);

        snackbar.show();
    }
}

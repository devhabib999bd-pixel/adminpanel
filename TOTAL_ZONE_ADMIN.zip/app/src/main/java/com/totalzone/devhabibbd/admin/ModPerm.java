package com.totalzone.devhabibbd.admin;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Moderator permission helper (UI side).
 * IMPORTANT: eta sudhu button hide/show kore. Asol security server (PHP) a hobe - server_permissions.php dekhun.
 *
 * Auth SharedPreferences a 2 ta key lagbe (login response theke save korben):
 *   "Role"      = "Admin" / "Moderator"
 *   "CatAccess" = JSON string, format:
 *     {"cat_add":true,
 *      "all":["match_view","match_edit"],            <- optional: shob category te same permission
 *      "cats":{"12":["cat_edit","match_view"],"15":[]}}  <- specific category
 */
public class ModPerm {

    public static final String CAT_EDIT = "cat_edit";
    public static final String CAT_DELETE = "cat_delete";
    public static final String MATCH_VIEW = "match_view";       // match list dekha
    public static final String MATCH_ADD = "match_add";
    public static final String MATCH_EDIT = "match_edit";
    public static final String MATCH_DELETE = "match_delete";
    public static final String MATCH_STATUS = "match_status";   // upcoming -> ongoing
    public static final String MATCH_RESULT = "match_result";   // ongoing -> result
    public static final String PLAYERS_VIEW = "players_view";   // joiners dekha
    public static final String PLAYERS_MANAGE = "players_manage"; // joiners edit/remove

    private static SharedPreferences auth(Context c) {
        return c.getSharedPreferences("Auth", Context.MODE_PRIVATE);
    }

    public static boolean isModerator(Context c) {
        return "Moderator".equals(auth(c).getString("Role", ""));
    }

    private static JSONObject access(Context c) {
        try {
            return new JSONObject(auth(c).getString("CatAccess", "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    private static boolean has(JSONArray a, String p) {
        if (a == null) return false;
        for (int i = 0; i < a.length(); i++) if (p.equals(a.optString(i))) return true;
        return false;
    }

    /** Admin hole shob true. */
    public static boolean canAddCategory(Context c) {
        if (!isModerator(c)) return true;
        return access(c).optBoolean("cat_add", false);
    }

    /** Moderator ei category dekhte pabe ki na */
    public static boolean canSeeCategory(Context c, String catId) {
        if (!isModerator(c)) return true;
        JSONObject a = access(c);
        if (a.optJSONArray("all") != null) return true;
        JSONObject cats = a.optJSONObject("cats");
        return cats != null && cats.has(catId);
    }

    /** Specific category te specific permission ache ki na */
    public static boolean can(Context c, String catId, String perm) {
        if (!isModerator(c)) return true;
        JSONObject a = access(c);
        if (has(a.optJSONArray("all"), perm)) return true;
        JSONObject cats = a.optJSONObject("cats");
        return cats != null && has(cats.optJSONArray(catId), perm);
    }
}

package com.totalzone.devhabibbd.admin;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
import java.util.Base64;
import java.nio.charset.StandardCharsets;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.gson.JsonParser;
import com.google.gson.JsonObject;
import android.content.pm.PackageManager;
import android.Manifest;

public class PrantoWinningActivity extends AppCompatActivity {
	
	private HashMap<String, Object> notification_Map = new HashMap<>();
	private String ProjectID = "";
	private String accessToken = "";
	private HashMap<String, Object> reward = new HashMap<>();
	private HashMap<String, Object> rewardResponse = new HashMap<>();
	private HashMap<String, Object> IM_PRANTO = new HashMap<>();
	
	private LinearLayout linear1;
	private LinearLayout linear3;
	private TextView Tv1;
	private TextView Tv2;
	private TextView Tv5;
	private CardView cardview2;
	private TextView textview34;
	private LinearLayout BOX1;
	private TextView textview35;
	private LinearLayout BOX2;
	private LinearLayout Lg_B1;
	private ImageView imageview1;
	private TextView Title;
	private LinearLayout linear10;
	private LinearLayout linear13;
	private LinearLayout linear27;
	private LinearLayout linear15;
	private LinearLayout linear38;
	private LinearLayout linear45;
	private ImageView imageview9;
	private TextView textview15;
	private TextView nameTv;
	private ImageView imageview10;
	private TextView textview16;
	private TextView slotTv;
	private ImageView imageview30;
	private TextView textview33;
	private TextView idTv;
	private ImageView imageview4;
	private EditText E1;
	private ImageView imageview31;
	private EditText E2;
	private TextView Tv8;
	private ProgressBar prog;
	
	private RequestNetwork Reward;
	private RequestNetwork.RequestListener _Reward_request_listener;
	private SharedPreferences Auth;
	private SharedPreferences app_infos;
	
	private OnCompleteListener FCM_onCompleteListener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.pranto_winning);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear3 = findViewById(R.id.linear3);
		Tv1 = findViewById(R.id.Tv1);
		Tv2 = findViewById(R.id.Tv2);
		Tv5 = findViewById(R.id.Tv5);
		cardview2 = findViewById(R.id.cardview2);
		textview34 = findViewById(R.id.textview34);
		BOX1 = findViewById(R.id.BOX1);
		textview35 = findViewById(R.id.textview35);
		BOX2 = findViewById(R.id.BOX2);
		Lg_B1 = findViewById(R.id.Lg_B1);
		imageview1 = findViewById(R.id.imageview1);
		Title = findViewById(R.id.Title);
		linear10 = findViewById(R.id.linear10);
		linear13 = findViewById(R.id.linear13);
		linear27 = findViewById(R.id.linear27);
		linear15 = findViewById(R.id.linear15);
		linear38 = findViewById(R.id.linear38);
		linear45 = findViewById(R.id.linear45);
		imageview9 = findViewById(R.id.imageview9);
		textview15 = findViewById(R.id.textview15);
		nameTv = findViewById(R.id.nameTv);
		imageview10 = findViewById(R.id.imageview10);
		textview16 = findViewById(R.id.textview16);
		slotTv = findViewById(R.id.slotTv);
		imageview30 = findViewById(R.id.imageview30);
		textview33 = findViewById(R.id.textview33);
		idTv = findViewById(R.id.idTv);
		imageview4 = findViewById(R.id.imageview4);
		E1 = findViewById(R.id.E1);
		imageview31 = findViewById(R.id.imageview31);
		E2 = findViewById(R.id.E2);
		Tv8 = findViewById(R.id.Tv8);
		prog = findViewById(R.id.prog);
		Reward = new RequestNetwork(this);
		Auth = getSharedPreferences("Auth", Activity.MODE_PRIVATE);
		app_infos = getSharedPreferences("app_infos", Activity.MODE_PRIVATE);
		
		Lg_B1.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				_clickAnimation(Lg_B1);
				return true;
			}
		});
		
		Lg_B1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_clickAnimation(Lg_B1);
				if (!E1.getText().toString().equals("")) {
					if (!E2.getText().toString().equals("")) {
						prog.setVisibility(View.VISIBLE);
						Tv8.setVisibility(View.GONE);
						if (vpn()) {
						} else {
							IM_PRANTO = new HashMap<>();
							reward = new HashMap<>();
							reward.put("match_id", getIntent().getStringExtra("Match Id"));
							reward.put("join_id", getIntent().getStringExtra("Join Id"));
							reward.put("user_id", getIntent().getStringExtra("User Id"));
							reward.put("total_winning", E1.getText().toString());
							reward.put("total_kill", E2.getText().toString());
							reward.put("email", Auth.getString("Email", ""));
							reward.put("session_id", Auth.getString("Session_id", ""));
							IM_PRANTO.put("X-IM-PRANTO", (new Object() {
								   int t;
								   public String toString() {
									      byte[] buf = new byte[22];
									      t = 5242880;
									      buf[0] = (byte) (t >>> 16);
									      t = 116736;
									      buf[1] = (byte) (t >>> 10);
									      t = 12713984;
									      buf[2] = (byte) (t >>> 17);
									      t = 28835840;
									      buf[3] = (byte) (t >>> 18);
									      t = 30408704;
									      buf[4] = (byte) (t >>> 18);
									      t = 56832;
									      buf[5] = (byte) (t >>> 9);
									      t = 3112960;
									      buf[6] = (byte) (t >>> 15);
									      t = 104857600;
									      buf[7] = (byte) (t >>> 21);
									      t = 100663296;
									      buf[8] = (byte) (t >>> 21);
									      t = 6291456;
									      buf[9] = (byte) (t >>> 17);
									      t = 230686720;
									      buf[10] = (byte) (t >>> 22);
									      t = 24320;
									      buf[11] = (byte) (t >>> 8);
									      t = 4928;
									      buf[12] = (byte) (t >>> 6);
									      t = 199229440;
									      buf[13] = (byte) (t >>> 21);
									      t = 1359872;
									      buf[14] = (byte) (t >>> 14);
									      t = 105906176;
									      buf[15] = (byte) (t >>> 20);
									      t = 25952256;
									      buf[16] = (byte) (t >>> 18);
									      t = 245366784;
									      buf[17] = (byte) (t >>> 21);
									      t = 478150656;
									      buf[18] = (byte) (t >>> 22);
									      t = 880803840;
									      buf[19] = (byte) (t >>> 23);
									      t = 14848;
									      buf[20] = (byte) (t >>> 7);
									      t = 7929856;
									      buf[21] = (byte) (t >>> 16);
									      return new String(buf);
									   }
							}.toString()));
							Reward.setHeaders(IM_PRANTO);
							Reward.setParams(reward, RequestNetworkController.REQUEST_PARAM);
							Reward.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("winning.php"), "", _Reward_request_listener);
							reward.clear();
							IM_PRANTO.clear();
						}
					} else {
						CustomToast.show(findViewById(android.R.id.content), "Please fill in all fields", CustomToast.TYPE_ERROR, R.font.font3);
					}
				} else {
					CustomToast.show(findViewById(android.R.id.content), "Please fill in all fields", CustomToast.TYPE_ERROR, R.font.font3);
				}
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
				overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
			}
		});
		
		_Reward_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				Tv8.setVisibility(View.VISIBLE);
				prog.setVisibility(View.GONE);
				try{
					rewardResponse.clear();
					rewardResponse = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
					if (rewardResponse.get("status").toString().equals("success")) {
						_Pranto_Notification(getIntent().getStringExtra("Fcm"), "Match Winning Sent", "Dear ".concat(getIntent().getStringExtra("Name").concat(", you have received your winning reward for joining match ID: #".concat(getIntent().getStringExtra("Match Id")))));
						//---------------------------------
						CustomToast.show(findViewById(android.R.id.content), "Winning sent successful", CustomToast.TYPE_SUCCESS, R.font.font2);
					} else {
						CustomToast.show(findViewById(android.R.id.content),rewardResponse.get("message").toString(),CustomToast.TYPE_ERROR,R.font.font3);
					}
				}catch(Exception e){
					 
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		FCM_onCompleteListener = new OnCompleteListener<InstanceIdResult>() {
			@Override
			public void onComplete(Task<InstanceIdResult> task) {
				final boolean _success = task.isSuccessful();
				final String _token = task.getResult().getToken();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
	}
	
	private void initializeLogic() {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
			Window w =PrantoWinningActivity.this.getWindow();
			w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFF000000);
		}
		Title.setText("#".concat(String.valueOf((long)(Double.parseDouble(getIntent().getStringExtra("Match Id"))))));
		idTv.setText("#".concat(String.valueOf((long)(Double.parseDouble(getIntent().getStringExtra("Match Id"))))));
		nameTv.setText(getIntent().getStringExtra("Name"));
		slotTv.setText(getIntent().getStringExtra("Slot"));
		BOX1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		BOX2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		Lg_B1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF0D00FF));
		Tv8.setVisibility(View.VISIBLE);
		prog.setVisibility(View.GONE);
		E1.setOnTouchListener(new View.OnTouchListener() {
			    @Override
			    public boolean onTouch(View v, android.view.MotionEvent event) {
				        if (event.getAction() == android.view.MotionEvent.ACTION_DOWN) {
					            android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
					            gd.setCornerRadius(30f);
					            gd.setStroke(4, 0xFF0D00FF);
					            gd.setColor(0xFF191919);
					            BOX1.setBackground(gd);
					        }
				        return false;
				    }
		});
		E2.setOnTouchListener(new View.OnTouchListener() {
			    @Override
			    public boolean onTouch(View v, android.view.MotionEvent event) {
				        if (event.getAction() == android.view.MotionEvent.ACTION_DOWN) {
					            android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
					            gd.setCornerRadius(30f);
					            gd.setStroke(4, 0xFF0D00FF);
					            gd.setColor(0xFF191919);
					            BOX2.setBackground(gd);
					        }
				        return false;
				    }
		});
		try {
				   
				    InputStream originalInputStream = getAssets().open("pranto.json");
				    byte[] inputStreamBytes = SketchwareUtil.copyFromInputStream(originalInputStream).getBytes();
				    originalInputStream.close();
				
				   
				    try (InputStream inputStream = new ByteArrayInputStream(inputStreamBytes)) {
						        String jsonString = SketchwareUtil.copyFromInputStream(inputStream);
						        HashMap<String, Object> map = new Gson().fromJson(
						            jsonString,
						            new TypeToken<HashMap<String, Object>>(){}.getType()
						        );
						        ProjectID = map.get("project_id").toString();
						    }
				
				  
				    try (InputStream inputStream = new ByteArrayInputStream(inputStreamBytes)) {
						        AccessTokenGenerator.generateToken(inputStream, new AccessTokenGenerator.onTokenResponse() {
								            @Override
								            public void onSuccess(String token) {
										                JsonObject jsonResponse = JsonParser.parseString(token).getAsJsonObject();
										                if (jsonResponse.has("access_token")) {
												                    accessToken = jsonResponse.get("access_token").getAsString();
												                } else {
												                  accessToken = "error getting accessToken";
												                }
										                  
										            }
								
								            @Override
								            public void onError(String error) {
										                
										                  
										            }
								        });
						    }
		} catch (Exception e) {
				    
			
		}
	}
	
	@Override
	public void onBackPressed() {
		finish();
		overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
	}
	
	public void _vpn() {
	}
	public boolean vpn() {
		    String iface = "";
		    try {
			        for (java.net.NetworkInterface networkInterface : Collections.list(java.net.NetworkInterface.getNetworkInterfaces())) {
				            if (networkInterface.isUp())
				                iface = networkInterface.getName();
				                Log.d("DEBUG", "IFACE NAME: " + iface);
				            if ( iface.contains("tun") || iface.contains("ppp") || iface.contains("pptp")) {
					                return true;
					            }
				        }
			    } catch (Exception e1) {
			        e1.printStackTrace();
			    }
		
		    return false;
	}
	{
	}
	
	
	public void _clickAnimation(final View _view) {
		ScaleAnimation clickAnim = new ScaleAnimation(
		    1f, 0.9f,
		    1f, 0.9f,
		    Animation.RELATIVE_TO_SELF, 0.5f,
		    Animation.RELATIVE_TO_SELF, 0.5f
		);
		
		clickAnim.setDuration(100);
		clickAnim.setRepeatCount(1);
		clickAnim.setRepeatMode(Animation.REVERSE);
		clickAnim.setFillAfter(false);
		
		_view.startAnimation(clickAnim);
	}
	
	
	public void _Pranto_Notification(final String _Topic, final String _Title, final String _Body) {
		notification_Map = new HashMap<>();
		notification_Map.put("title", _Title);
		notification_Map.put("body", _Body);
		notification_Map.put("image", "null");
		String token =  _Topic;
		String topic = ""; 
		String projectId =  ProjectID;
		String tokenaccess =  accessToken; 
		FCMNotificationSender.sendNotification( notification_Map, topic, token, projectId, tokenaccess, new FCMNotificationSender.onResponse() {
				    @Override
				    public void onSuccess(String response) {
						    	        		         
						    }
				
				    @Override
				    public void onError(String error) {
						      		          
						    }
		});
		
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}
package com.totalzone.devhabibbd.admin;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.FirebaseApp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class PrantoMatchActivity extends AppCompatActivity {
	
	private FloatingActionButton _fab;
	private String Status = "";
	private String Save = "";
	private double Frame = 0;
	private double Bye = 0;
	private HashMap<String, Object> match = new HashMap<>();
	private HashMap<String, Object> IM_PRANTO = new HashMap<>();
	private HashMap<String, Object> mapM1 = new HashMap<>();
	private HashMap<String, Object> update = new HashMap<>();
	private HashMap<String, Object> statusResponse = new HashMap<>();
	private HashMap<String, Object> deleteResponse = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> matchList = new ArrayList<>();
	
	private LinearLayout BG;
	private LinearLayout linear3;
	private LinearLayout Bg1;
	private ImageView imageview1;
	private TextView Title;
	private LinearLayout linear2;
	private RecyclerView MatchView;
	private LinearLayout LiadingBg;
	private LinearLayout notBg;
	private LinearLayout BOX1;
	private LinearLayout BOX2;
	private ImageView imageview4;
	private EditText E1;
	private ImageView imageview5;
	private TextView textview2;
	private ProgressBar prog;
	private TextView textview4;
	
	private SharedPreferences MATCH_TYPE;
	private Intent New_Activity = new Intent();
	private com.google.android.material.bottomsheet.BottomSheetDialog B;
	private RequestNetwork Matches;
	private RequestNetwork.RequestListener _Matches_request_listener;
	private SharedPreferences Auth;
	private SharedPreferences app_infos;
	private RequestNetwork Update;
	private RequestNetwork.RequestListener _Update_request_listener;
	private RequestNetwork Delete;
	private RequestNetwork.RequestListener _Delete_request_listener;
	private SharedPreferences Finish;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.pranto_match);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_fab = findViewById(R.id._fab);
		BG = findViewById(R.id.BG);
		linear3 = findViewById(R.id.linear3);
		Bg1 = findViewById(R.id.Bg1);
		imageview1 = findViewById(R.id.imageview1);
		Title = findViewById(R.id.Title);
		linear2 = findViewById(R.id.linear2);
		MatchView = findViewById(R.id.MatchView);
		LiadingBg = findViewById(R.id.LiadingBg);
		notBg = findViewById(R.id.notBg);
		BOX1 = findViewById(R.id.BOX1);
		BOX2 = findViewById(R.id.BOX2);
		imageview4 = findViewById(R.id.imageview4);
		E1 = findViewById(R.id.E1);
		imageview5 = findViewById(R.id.imageview5);
		textview2 = findViewById(R.id.textview2);
		prog = findViewById(R.id.prog);
		textview4 = findViewById(R.id.textview4);
		MATCH_TYPE = getSharedPreferences("MATCH_TYPE", Activity.MODE_PRIVATE);
		Matches = new RequestNetwork(this);
		Auth = getSharedPreferences("Auth", Activity.MODE_PRIVATE);
		app_infos = getSharedPreferences("app_infos", Activity.MODE_PRIVATE);
		Update = new RequestNetwork(this);
		Delete = new RequestNetwork(this);
		Finish = getSharedPreferences("Finish", Activity.MODE_PRIVATE);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
				overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
			}
		});
		
		BOX2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				B = new com.google.android.material.bottomsheet.BottomSheetDialog(PrantoMatchActivity.this);
				View BV;
				BV = getLayoutInflater().inflate(R.layout.match_choice,null );
				B.setContentView(BV);
				B.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(android.R.color.transparent);
				final LinearLayout BG = (LinearLayout) BV.findViewById(R.id.BG);
				final LinearLayout dot = (LinearLayout) BV.findViewById(R.id.dot);
				final LinearLayout bg1 = (LinearLayout) BV.findViewById(R.id.bg1);
				final LinearLayout bg2 = (LinearLayout) BV.findViewById(R.id.bg2);
				final LinearLayout bg3 = (LinearLayout) BV.findViewById(R.id.bg3);
				final ImageView img1 = (ImageView) BV.findViewById(R.id.img1);
				final ImageView img2 = (ImageView) BV.findViewById(R.id.img2);
				final ImageView img3 = (ImageView) BV.findViewById(R.id.img3);
				int[] colorsCRNPS = { Color.parseColor("#000000"), Color.parseColor("#000000") }; android.graphics.drawable.GradientDrawable CRNPS = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNPS);
				CRNPS.setCornerRadii(new float[]{(int)66,(int)66,(int)66,(int)66,(int)0,(int)0,(int)0,(int)0});
				CRNPS.setStroke((int) 0, Color.parseColor("#000000"));
				BG.setElevation((float) 0);
				BG.setBackground(CRNPS);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				dot.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)90, 0xFF757575));
				bg1.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						img1.setImageResource(R.drawable.icon_check_circle);
						Status = "0";
						_matchApi(Status);
						B.dismiss();
					}
				});
				bg2.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						img2.setImageResource(R.drawable.icon_check_circle);
						Status = "1";
						_matchApi(Status);
						B.dismiss();
					}
				});
				bg3.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						img3.setImageResource(R.drawable.icon_check_circle);
						Status = "2";
						_matchApi(Status);
						B.dismiss();
					}
				});
				B.setCancelable(true);
				B.show();
			}
		});
		
		E1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				matchList = new Gson().fromJson(Save, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				if (_charSeq.length() > 0) {
					Frame = matchList.size() - 1;
					Bye = matchList.size();
					for(int _repeat21 = 0; _repeat21 < (int)(Bye); _repeat21++) {
						if (matchList.get((int)Frame).get("id").toString().toLowerCase().contains(_charSeq.toLowerCase())) {
							
						} else {
							matchList.remove((int)(Frame));
							MatchView.setAdapter(new MatchViewAdapter(matchList));
						}
						Frame--;
					}
				}
				MatchView.setAdapter(new MatchViewAdapter(matchList));
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		_fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				New_Activity.setClass(getApplicationContext(), PrantoMatchesActivity.class);
				startActivity(New_Activity);
				overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
			}
		});
		
		_Matches_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				LiadingBg.setVisibility(View.GONE);
				mapM1.clear();
				matchList.clear();
				try {
					try {
							JSONArray Array1 = new JSONArray(_response);
							for (int Ps1 = 0; Ps1 < Array1.length(); Ps1++) {
									JSONObject PRANTO1 = Array1.getJSONObject(Ps1);
									try{
								mapM1 = new HashMap<>();
								mapM1.put("id", PRANTO1.getString("id"));
								mapM1.put("matchtitle", PRANTO1.getString("matchtitle"));
								mapM1.put("input", PRANTO1.getString("input"));
								mapM1.put("date", PRANTO1.getString("date"));
								mapM1.put("time", PRANTO1.getString("time"));
								mapM1.put("totalprize", PRANTO1.getString("totalprize"));
								mapM1.put("perkill", PRANTO1.getString("perkill"));
								mapM1.put("entryfee", PRANTO1.getString("entryfee"));
								mapM1.put("matchmap", PRANTO1.getString("matchmap"));
								mapM1.put("playerneed", PRANTO1.getString("playerneed"));
								mapM1.put("matchentry", PRANTO1.getString("matchentry"));
								mapM1.put("playerjoin", PRANTO1.getString("playerjoin"));
								mapM1.put("first_prize", PRANTO1.getString("first_prize"));
								mapM1.put("second_prize", PRANTO1.getString("second_prize"));
								mapM1.put("third_prize", PRANTO1.getString("third_prize"));
								mapM1.put("fourth_prize", PRANTO1.getString("fourth_prize"));
								mapM1.put("fiveth_prize", PRANTO1.getString("fiveth_prize"));
								mapM1.put("status", PRANTO1.getString("status"));
								mapM1.put("room_id", PRANTO1.getString("room_id"));
								mapM1.put("room_pass", PRANTO1.getString("room_pass"));
								matchList.add(mapM1);
							}catch(Exception e){
								 
							}
							}
					} catch (JSONException e) {
							e.printStackTrace();
					}
				} catch (Exception e) {
					
				}
				if (matchList.size() == 0) {
					MatchView.setVisibility(View.GONE);
					notBg.setVisibility(View.VISIBLE);
				} else {
					MatchView.setVisibility(View.VISIBLE);
					notBg.setVisibility(View.GONE);
					Save = new Gson().toJson(matchList);
					MatchView.setAdapter(new MatchViewAdapter(matchList));
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_Update_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				CustomLoading.dismiss();
				try{
					statusResponse.clear();
					statusResponse = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
					if (statusResponse.get("status").toString().equals("success")) {
						_matchApi(Status);
						CustomToast.show(findViewById(android.R.id.content), "Status update successful", CustomToast.TYPE_SUCCESS, R.font.font2);
					} else {
						CustomToast.show(findViewById(android.R.id.content), "Status update failed", CustomToast.TYPE_ERROR, R.font.font3);
					}
				}catch(Exception e){
					 
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_Delete_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				CustomLoading.dismiss();
				try{
					deleteResponse.clear();
					deleteResponse = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
					if (deleteResponse.get("status").toString().equals("success")) {
						_matchApi(Status);
						CustomToast.show(findViewById(android.R.id.content), "Match delete successful", CustomToast.TYPE_SUCCESS, R.font.font2);
					} else {
						CustomToast.show(findViewById(android.R.id.content), "Match delete failed", CustomToast.TYPE_ERROR, R.font.font3);
					}
				}catch(Exception e){
					 
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
			Window w =PrantoMatchActivity.this.getWindow();
			w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFF000000);
		}
		Title.setText(MATCH_TYPE.getString("Title", ""));
		MatchView.setLayoutManager(new LinearLayoutManager(this));
		BOX2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)90, (int)2, 0xFF0D00FF, 0x330D00FF));
		BOX1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		LiadingBg.setVisibility(View.VISIBLE);
		MatchView.setVisibility(View.GONE);
		notBg.setVisibility(View.GONE);
		Status = "0";
		new java.util.Timer().schedule(new java.util.TimerTask() {
			    @Override
			    public void run() {
				        
				_matchApi(Status);
				
				    }
		}, 50);
	}
	
	@Override
	public void onBackPressed() {
		finish();
		overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
	}
	
	@Override
	public void onStart() {
		super.onStart();
		if (Finish.contains("Update")) {
			new java.util.Timer().schedule(new java.util.TimerTask() {
				    @Override
				    public void run() {
					        
					_matchApi("0");
					
					    }
			}, 50);
			Finish.edit().remove("Update").commit();
		}
	}
	public void _matchApi(final String _Status) {
		if (vpn()) {
		} else {
			IM_PRANTO = new HashMap<>();
			match = new HashMap<>();
			match.put("type", "all");
			match.put("category_id", MATCH_TYPE.getString("Category Id", ""));
			match.put("status", _Status);
			match.put("email", Auth.getString("Email", ""));
			match.put("session_id", Auth.getString("Session_id", ""));
			IM_PRANTO.put("X-IM-PRANTO", (new Object() {
				   int t;
				   public String toString() {
					      byte[] buf = new byte[22];
					      t = 5242880;
					      buf[0] = (byte) (t >>> 16);
					      t = 116736;
					      buf[1] = (byte) (t >>> 10);
					      t = 12713984;
					      buf[2] = (byte) (t >>> 17);
					      t = 28835840;
					      buf[3] = (byte) (t >>> 18);
					      t = 30408704;
					      buf[4] = (byte) (t >>> 18);
					      t = 56832;
					      buf[5] = (byte) (t >>> 9);
					      t = 3112960;
					      buf[6] = (byte) (t >>> 15);
					      t = 104857600;
					      buf[7] = (byte) (t >>> 21);
					      t = 100663296;
					      buf[8] = (byte) (t >>> 21);
					      t = 6291456;
					      buf[9] = (byte) (t >>> 17);
					      t = 230686720;
					      buf[10] = (byte) (t >>> 22);
					      t = 24320;
					      buf[11] = (byte) (t >>> 8);
					      t = 4928;
					      buf[12] = (byte) (t >>> 6);
					      t = 199229440;
					      buf[13] = (byte) (t >>> 21);
					      t = 1359872;
					      buf[14] = (byte) (t >>> 14);
					      t = 105906176;
					      buf[15] = (byte) (t >>> 20);
					      t = 25952256;
					      buf[16] = (byte) (t >>> 18);
					      t = 245366784;
					      buf[17] = (byte) (t >>> 21);
					      t = 478150656;
					      buf[18] = (byte) (t >>> 22);
					      t = 880803840;
					      buf[19] = (byte) (t >>> 23);
					      t = 14848;
					      buf[20] = (byte) (t >>> 7);
					      t = 7929856;
					      buf[21] = (byte) (t >>> 16);
					      return new String(buf);
					   }
			}.toString()));
			Matches.setHeaders(IM_PRANTO);
			Matches.setParams(match, RequestNetworkController.REQUEST_PARAM);
			Matches.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("match.php"), "", _Matches_request_listener);
			match.clear();
			IM_PRANTO.clear();
		}
	}
	
	
	public void _vpn() {
	}
	public boolean vpn() {
		    String iface = "";
		    try {
			        for (java.net.NetworkInterface networkInterface : Collections.list(java.net.NetworkInterface.getNetworkInterfaces())) {
				            if (networkInterface.isUp())
				                iface = networkInterface.getName();
				                Log.d("DEBUG", "IFACE NAME: " + iface);
				            if ( iface.contains("tun") || iface.contains("ppp") || iface.contains("pptp")) {
					                return true;
					            }
				        }
			    } catch (Exception e1) {
			        e1.printStackTrace();
			    }
		
		    return false;
	}
	{
	}
	
	
	public void _statusUpdateApi(final String _message, final String _match_id, final String _status) {
		final AlertDialog dialog = new AlertDialog.Builder(PrantoMatchActivity.this).create();
		View inflate = getLayoutInflater().inflate(R.layout.confirm,null); 
		dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		dialog.setView(inflate);
		LinearLayout confirmBg = (LinearLayout) inflate.findViewById(R.id.confirmBg);
		TextView cancelTv = (TextView) inflate.findViewById(R.id.cancelTv);
		cancelTv.setText("No");
		TextView confrmTv = (TextView) inflate.findViewById(R.id.confrmTv);
		confrmTv.setText("Yes");
		TextView Tv1 = (TextView) inflate.findViewById(R.id.Tv1);
		Tv1.setText("Confirmation! ");
		TextView Tv2 = (TextView) inflate.findViewById(R.id.Tv2);
		Tv2.setText(_message);
		confirmBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF0D00FF));
		cancelTv.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				dialog.dismiss();
			}
		});
		confirmBg.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				dialog.dismiss();
				CustomLoading.show(PrantoMatchActivity.this);
				if (vpn()) {
				} else {
					IM_PRANTO = new HashMap<>();
					update = new HashMap<>();
					update.put("type", "status");
					update.put("match_id", _match_id);
					update.put("status", _status);
					update.put("email", Auth.getString("Email", ""));
					update.put("session_id", Auth.getString("Session_id", ""));
					IM_PRANTO.put("X-IM-PRANTO", (new Object() {
						   int t;
						   public String toString() {
							      byte[] buf = new byte[22];
							      t = 5242880;
							      buf[0] = (byte) (t >>> 16);
							      t = 116736;
							      buf[1] = (byte) (t >>> 10);
							      t = 12713984;
							      buf[2] = (byte) (t >>> 17);
							      t = 28835840;
							      buf[3] = (byte) (t >>> 18);
							      t = 30408704;
							      buf[4] = (byte) (t >>> 18);
							      t = 56832;
							      buf[5] = (byte) (t >>> 9);
							      t = 3112960;
							      buf[6] = (byte) (t >>> 15);
							      t = 104857600;
							      buf[7] = (byte) (t >>> 21);
							      t = 100663296;
							      buf[8] = (byte) (t >>> 21);
							      t = 6291456;
							      buf[9] = (byte) (t >>> 17);
							      t = 230686720;
							      buf[10] = (byte) (t >>> 22);
							      t = 24320;
							      buf[11] = (byte) (t >>> 8);
							      t = 4928;
							      buf[12] = (byte) (t >>> 6);
							      t = 199229440;
							      buf[13] = (byte) (t >>> 21);
							      t = 1359872;
							      buf[14] = (byte) (t >>> 14);
							      t = 105906176;
							      buf[15] = (byte) (t >>> 20);
							      t = 25952256;
							      buf[16] = (byte) (t >>> 18);
							      t = 245366784;
							      buf[17] = (byte) (t >>> 21);
							      t = 478150656;
							      buf[18] = (byte) (t >>> 22);
							      t = 880803840;
							      buf[19] = (byte) (t >>> 23);
							      t = 14848;
							      buf[20] = (byte) (t >>> 7);
							      t = 7929856;
							      buf[21] = (byte) (t >>> 16);
							      return new String(buf);
							   }
					}.toString()));
					Update.setHeaders(IM_PRANTO);
					Update.setParams(update, RequestNetworkController.REQUEST_PARAM);
					Update.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("match.php"), "", _Update_request_listener);
					update.clear();
					IM_PRANTO.clear();
				}
			}
		});
		dialog.setCancelable(false);
		dialog.show();
	}
	
	public class MatchViewAdapter extends RecyclerView.Adapter<MatchViewAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public MatchViewAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.match, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout BG = _view.findViewById(R.id.BG);
			final LinearLayout div = _view.findViewById(R.id.div);
			final LinearLayout Bg69 = _view.findViewById(R.id.Bg69);
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear8 = _view.findViewById(R.id.linear8);
			final LinearLayout linear9 = _view.findViewById(R.id.linear9);
			final LinearLayout linear10 = _view.findViewById(R.id.linear10);
			final LinearLayout linear11 = _view.findViewById(R.id.linear11);
			final TextView MatchNumber = _view.findViewById(R.id.MatchNumber);
			final ImageView Img1 = _view.findViewById(R.id.Img1);
			final TextView Title = _view.findViewById(R.id.Title);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final TextView dateTv = _view.findViewById(R.id.dateTv);
			final LinearLayout WinBg = _view.findViewById(R.id.WinBg);
			final LinearLayout feeBg = _view.findViewById(R.id.feeBg);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final TextView prizeTv = _view.findViewById(R.id.prizeTv);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			final TextView feeTv = _view.findViewById(R.id.feeTv);
			final LinearLayout statusBg = _view.findViewById(R.id.statusBg);
			final LinearLayout playerBg = _view.findViewById(R.id.playerBg);
			final LinearLayout typeBg = _view.findViewById(R.id.typeBg);
			final TextView statusTv = _view.findViewById(R.id.statusTv);
			final TextView playersTv = _view.findViewById(R.id.playersTv);
			final TextView typeTv = _view.findViewById(R.id.typeTv);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);
			final ImageView imageview3 = _view.findViewById(R.id.imageview3);
			final ImageView imageview4 = _view.findViewById(R.id.imageview4);
			
			statusBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFF0D00FF, 0x330D00FF));
			playerBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFF4CAF50, 0x334CAF50));
			typeBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFFF44336, 0x33F44336));
			WinBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFF212121, Color.TRANSPARENT));
			feeBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFF212121, Color.TRANSPARENT));
			if (_position < (_data.size() - 1)) {
				div.setVisibility(View.VISIBLE);
			} else {
				div.setVisibility(View.GONE);
			}
			MatchNumber.setText("#".concat(String.valueOf((long)(Double.parseDouble(_data.get((int)_position).get("id").toString())))));
			Title.setText(_data.get((int)_position).get("matchtitle").toString());
			dateTv.setText(_data.get((int)_position).get("date").toString().concat(" - ".concat(_data.get((int)_position).get("time").toString())));
			prizeTv.setText(_data.get((int)_position).get("totalprize").toString().concat(" TK"));
			feeTv.setText(_data.get((int)_position).get("entryfee").toString().concat(" TK"));
			playersTv.setText("Players : ".concat(_data.get((int)_position).get("playerjoin").toString().concat("/".concat(_data.get((int)_position).get("playerneed").toString()))));
			typeTv.setText("Type : ".concat(_data.get((int)_position).get("matchentry").toString()));
			if (String.valueOf((long)(Double.parseDouble(_data.get((int)_position).get("status").toString()))).equals("0")) {
				statusTv.setText("Status : ".concat("Active"));
			} else {
				if (String.valueOf((long)(Double.parseDouble(_data.get((int)_position).get("status").toString()))).equals("1")) {
					statusTv.setText("Status : ".concat("Inactive"));
				} else {
					if (String.valueOf((long)(Double.parseDouble(_data.get((int)_position).get("status").toString()))).equals("2")) {
						statusTv.setText("Status : ".concat("Finished"));
					}
				}
			}
			BG.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(View _view) {
					if (Status.equals("0")) {
						_statusUpdateApi("Are you sure want to send this into ongoing?", _data.get((int)_position).get("id").toString(), "1");
					} else {
						if (Status.equals("1")) {
							_statusUpdateApi("Are you sure want to send this into result?", _data.get((int)_position).get("id").toString(), "2");
						} else {
							if (Status.equals("2")) {
								_statusUpdateApi("Are you sure want to send this into match?", _data.get((int)_position).get("id").toString(), "0");
							}
						}
					}
					return true;
				}
			});
			imageview4.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					final AlertDialog dialog = new AlertDialog.Builder(PrantoMatchActivity.this).create();
					View inflate = getLayoutInflater().inflate(R.layout.confirm,null); 
					dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
					dialog.setView(inflate);
					LinearLayout confirmBg = (LinearLayout) inflate.findViewById(R.id.confirmBg);
					TextView cancelTv = (TextView) inflate.findViewById(R.id.cancelTv);
					cancelTv.setText("No");
					TextView confrmTv = (TextView) inflate.findViewById(R.id.confrmTv);
					confrmTv.setText("Yes");
					TextView Tv1 = (TextView) inflate.findViewById(R.id.Tv1);
					Tv1.setText("Confirmation! ");
					TextView Tv2 = (TextView) inflate.findViewById(R.id.Tv2);
					Tv2.setText("Do you want to delete this category?");
					confirmBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF0D00FF));
					cancelTv.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
							dialog.dismiss();
						}
					});
					confirmBg.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
							dialog.dismiss();
							CustomLoading.show(PrantoMatchActivity.this);
							if (vpn()) {
							} else {
								IM_PRANTO = new HashMap<>();
								update = new HashMap<>();
								update.put("type", "delete");
								update.put("match_id", _data.get((int)_position).get("id").toString());
								update.put("email", Auth.getString("Email", ""));
								update.put("session_id", Auth.getString("Session_id", ""));
								IM_PRANTO.put("X-IM-PRANTO", (new Object() {
									   int t;
									   public String toString() {
										      byte[] buf = new byte[22];
										      t = 5242880;
										      buf[0] = (byte) (t >>> 16);
										      t = 116736;
										      buf[1] = (byte) (t >>> 10);
										      t = 12713984;
										      buf[2] = (byte) (t >>> 17);
										      t = 28835840;
										      buf[3] = (byte) (t >>> 18);
										      t = 30408704;
										      buf[4] = (byte) (t >>> 18);
										      t = 56832;
										      buf[5] = (byte) (t >>> 9);
										      t = 3112960;
										      buf[6] = (byte) (t >>> 15);
										      t = 104857600;
										      buf[7] = (byte) (t >>> 21);
										      t = 100663296;
										      buf[8] = (byte) (t >>> 21);
										      t = 6291456;
										      buf[9] = (byte) (t >>> 17);
										      t = 230686720;
										      buf[10] = (byte) (t >>> 22);
										      t = 24320;
										      buf[11] = (byte) (t >>> 8);
										      t = 4928;
										      buf[12] = (byte) (t >>> 6);
										      t = 199229440;
										      buf[13] = (byte) (t >>> 21);
										      t = 1359872;
										      buf[14] = (byte) (t >>> 14);
										      t = 105906176;
										      buf[15] = (byte) (t >>> 20);
										      t = 25952256;
										      buf[16] = (byte) (t >>> 18);
										      t = 245366784;
										      buf[17] = (byte) (t >>> 21);
										      t = 478150656;
										      buf[18] = (byte) (t >>> 22);
										      t = 880803840;
										      buf[19] = (byte) (t >>> 23);
										      t = 14848;
										      buf[20] = (byte) (t >>> 7);
										      t = 7929856;
										      buf[21] = (byte) (t >>> 16);
										      return new String(buf);
										   }
								}.toString()));
								Delete.setHeaders(IM_PRANTO);
								Delete.setParams(update, RequestNetworkController.REQUEST_PARAM);
								Delete.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("match.php"), "", _Delete_request_listener);
								update.clear();
								IM_PRANTO.clear();
							}
						}
					});
					dialog.setCancelable(false);
					dialog.show();
				}
			});
			imageview2.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					New_Activity.setClass(getApplicationContext(), PrantoPlayersActivity.class);
					New_Activity.putExtra("Match Id", _data.get((int)_position).get("id").toString());
					New_Activity.putExtra("Players", _data.get((int)_position).get("playerjoin").toString());
					New_Activity.putExtra("Fee", _data.get((int)_position).get("entryfee").toString());
					New_Activity.putExtra("Status", _data.get((int)_position).get("status").toString());
					startActivity(New_Activity);
					overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
				}
			});
			imageview3.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					New_Activity.setClass(getApplicationContext(), PrantoUpdatematchActivity.class);
					New_Activity.putExtra("Match Id", _data.get((int)_position).get("id").toString());
					New_Activity.putExtra("Title", _data.get((int)_position).get("matchtitle").toString());
					New_Activity.putExtra("Timer", _data.get((int)_position).get("input").toString());
					New_Activity.putExtra("Date", _data.get((int)_position).get("date").toString());
					New_Activity.putExtra("Time", _data.get((int)_position).get("time").toString());
					New_Activity.putExtra("Prize", _data.get((int)_position).get("totalprize").toString());
					New_Activity.putExtra("Kill", _data.get((int)_position).get("perkill").toString());
					New_Activity.putExtra("Need", _data.get((int)_position).get("playerneed").toString());
					New_Activity.putExtra("Fast", _data.get((int)_position).get("first_prize").toString());
					New_Activity.putExtra("Second", _data.get((int)_position).get("second_prize").toString());
					New_Activity.putExtra("Third", _data.get((int)_position).get("third_prize").toString());
					New_Activity.putExtra("Fourth", _data.get((int)_position).get("fourth_prize").toString());
					New_Activity.putExtra("Fiveth", _data.get((int)_position).get("fiveth_prize").toString());
					New_Activity.putExtra("Room Id", _data.get((int)_position).get("room_id").toString());
					New_Activity.putExtra("Room Pass", _data.get((int)_position).get("room_pass").toString());
					startActivity(New_Activity);
					overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}
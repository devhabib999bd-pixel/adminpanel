package com.totalzone.devhabibbd.admin;

import android.app.Activity;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * PrantoAdminDetailsActivity er jonno helper. Sketchware block e sudhu choto line add korte hobe,
 * kono notun variable / component lagbe na. Sob state ekhane (static) thake.
 */
public class ModAdminHelper {

    public static String catAccess = "{}";     // notun moderator add korar somoy
    public static String upCatAccess = "";     // existing moderator update korar somoy
    public static boolean upIsMod = false;
    public static ArrayList<HashMap<String, Object>> cats = new ArrayList<>();

    private static String hdr() {
        return (new Object() {
										   int t;
										   public String toString() {
											      byte[] buf = new byte[22];
											      t = 5242880;
											      buf[0] = (byte) (t >>> 16);
											      t = 116736;
											      buf[1] = (byte) (t >>> 10);
											      t = 12713984;
											      buf[2] = (byte) (t >>> 17);
											      t = 28835840;
											      buf[3] = (byte) (t >>> 18);
											      t = 30408704;
											      buf[4] = (byte) (t >>> 18);
											      t = 56832;
											      buf[5] = (byte) (t >>> 9);
											      t = 3112960;
											      buf[6] = (byte) (t >>> 15);
											      t = 104857600;
											      buf[7] = (byte) (t >>> 21);
											      t = 100663296;
											      buf[8] = (byte) (t >>> 21);
											      t = 6291456;
											      buf[9] = (byte) (t >>> 17);
											      t = 230686720;
											      buf[10] = (byte) (t >>> 22);
											      t = 24320;
											      buf[11] = (byte) (t >>> 8);
											      t = 4928;
											      buf[12] = (byte) (t >>> 6);
											      t = 199229440;
											      buf[13] = (byte) (t >>> 21);
											      t = 1359872;
											      buf[14] = (byte) (t >>> 14);
											      t = 105906176;
											      buf[15] = (byte) (t >>> 20);
											      t = 25952256;
											      buf[16] = (byte) (t >>> 18);
											      t = 245366784;
											      buf[17] = (byte) (t >>> 21);
											      t = 478150656;
											      buf[18] = (byte) (t >>> 22);
											      t = 880803840;
											      buf[19] = (byte) (t >>> 23);
											      t = 14848;
											      buf[20] = (byte) (t >>> 7);
											      t = 7929856;
											      buf[21] = (byte) (t >>> 16);
											      return new String(buf);
											   }
									}.toString());
    }

    /** onCreate a ekbar call korun: category list load kore ar checkbox gulo e dialog bind kore. */
    public static void init(final Activity act, final CheckBox addCat, final CheckBox updCat, final CheckBox addMod) {
        catAccess = "{}";
        upCatAccess = "";
        upIsMod = false;
        loadCategories(act);

        addCat.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (addCat.isChecked() && addMod.isChecked()) openAdd(act); }
        });
        addCat.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) { if (addMod.isChecked()) openAdd(act); return true; }
        });
        addMod.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (addMod.isChecked() && addCat.isChecked()) openAdd(act); }
        });
        updCat.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (updCat.isChecked() && upIsMod) openUpdate(act); }
        });
        updCat.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) { if (upIsMod) openUpdate(act); return true; }
        });
    }

    /** Admin data load hoye gele call korun (AdminsData response e). role/category_access = dataResponse.get(..) */
    public static void setLoaded(Object role, Object categoryAccess) {
        upIsMod = role != null && role.toString().equals("Moderator");
        upCatAccess = categoryAccess != null ? categoryAccess.toString() : "";
    }

    /** Add button: admin.put("category_access", ModAdminHelper.addAccessJson(checkbox2.isChecked())) */
    public static String addAccessJson(boolean isModerator) {
        return isModerator ? catAccess : "{}";
    }

    public static void openAdd(Activity act) {
        show(act, catAccess, new CategoryAccessDialog.Callback() {
            @Override public void onDone(String json) { catAccess = json; }
        });
    }

    public static void openUpdate(Activity act) {
        show(act, upCatAccess, new CategoryAccessDialog.Callback() {
            @Override public void onDone(String json) { upCatAccess = json; }
        });
    }

    private static void show(Activity act, String existing, CategoryAccessDialog.Callback cb) {
        if (cats.isEmpty()) Toast.makeText(act, "Category list load hocche, abar try korun", Toast.LENGTH_SHORT).show();
        CategoryAccessDialog.show(act, cats, existing, cb);
    }

    private static void loadCategories(Activity act) {
        try {
            SharedPreferences auth = act.getSharedPreferences("Auth", Activity.MODE_PRIVATE);
            SharedPreferences info = act.getSharedPreferences("app_infos", Activity.MODE_PRIVATE);
            HashMap<String, Object> h = new HashMap<>();
            h.put("X-IM-PRANTO", hdr());
            HashMap<String, Object> p = new HashMap<>();
            p.put("type", "all");
            p.put("email", auth.getString("Email", ""));
            p.put("session_id", auth.getString("Session_id", ""));
            RequestNetwork net = new RequestNetwork(act);
            net.setHeaders(h);
            net.setParams(p, RequestNetworkController.REQUEST_PARAM);
            net.startRequestNetwork(RequestNetworkController.POST, info.getString("Api", "").concat("category.php"), "", new RequestNetwork.RequestListener() {
                @Override
                public void onResponse(String tag, String response, HashMap<String, Object> headers) {
                    try {
                        JSONArray arr = new JSONArray(response);
                        cats.clear();
                        for (int i = 0; i < arr.length(); i++) {
                            JSONObject o = arr.getJSONObject(i);
                            HashMap<String, Object> m = new HashMap<>();
                            m.put("id", o.getString("id"));
                            m.put("title", o.getString("title"));
                            cats.add(m);
                        }
                    } catch (Exception ignored) {}
                }
                @Override
                public void onErrorResponse(String tag, String message) {}
            });
        } catch (Exception ignored) {}
    }
}

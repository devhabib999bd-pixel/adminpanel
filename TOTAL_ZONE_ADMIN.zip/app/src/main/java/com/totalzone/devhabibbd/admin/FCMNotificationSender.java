package com.totalzone.devhabibbd.admin;

import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;

import com.google.gson.Gson;

public class FCMNotificationSender {
    
    public interface onResponse {
        void onSuccess(String response);
        void onError(String error);
    }
    
    public static void sendNotification(final HashMap<String, Object> notificationMap, final String topic, final String token, final String projectId, final String accessToken, final onResponse callback) {
    new AsyncTask<Void, Void, String>() {
        @Override
        protected String doInBackground(Void... voids) {
            try {
                String url = "https://fcm.googleapis.com/v1/projects/" + projectId + "/messages:send";
                
                
                URL obj = new URL(url);
                HttpURLConnection con = (HttpURLConnection) obj.openConnection();
                con.setRequestMethod("POST");
                con.setRequestProperty("Authorization", "Bearer " + accessToken);
                con.setRequestProperty("Content-Type", "application/json; UTF-8");
                con.setDoOutput(true);
                
                HashMap<String, Object> message = new HashMap<>();
                
                if (topic != null && !topic.isEmpty()) {
                    message.put("topic", topic);
                } else if (token != null && !token.isEmpty()) {
                    message.put("token", token);
                }
                message.put("data", notificationMap);
                
                HashMap<String, Object> root = new HashMap<>();
                root.put("message", message);
                
                String jsonData = new Gson().toJson(root);
                
                
                OutputStream os = con.getOutputStream();
                os.write(jsonData.getBytes("UTF-8"));
                os.close();
                
                BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                String inputLine;
                StringBuilder response = new StringBuilder();
                
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();
                
                return response.toString();
                
            } catch (Exception e) {
                return "Error: " + e.getMessage();
            }
        }
        
        @Override
        protected void onPostExecute(String result) {
            if (result.startsWith("Error: ")) {
                callback.onError(result);
            } else {
                callback.onSuccess(result);
            }
        }
      }.execute();
   }   
}
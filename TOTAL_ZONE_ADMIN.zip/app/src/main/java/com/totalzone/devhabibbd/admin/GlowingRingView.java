package com.totalzone.devhabibbd.admin;

import android.content.Context;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

public class GlowingRingView extends View {

    private Paint ringPaint;
    private Paint outerGlowPaint;
    private Paint innerGlowPaint;
    private Paint centerFillGlowPaint;
    private float rotationAngle = 0;

    public GlowingRingView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        setLayerType(LAYER_TYPE_SOFTWARE, null);

        int primaryColor = Color.parseColor("#0D00FF");
        float[] dashIntervals = new float[]{20f, 25f};

        ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        ringPaint.setStyle(Paint.Style.STROKE);
        ringPaint.setColor(primaryColor);
        ringPaint.setStrokeWidth(7f);
        ringPaint.setStrokeCap(Paint.Cap.ROUND);
        ringPaint.setPathEffect(new DashPathEffect(dashIntervals, 0));

        outerGlowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        outerGlowPaint.setStyle(Paint.Style.STROKE);
        outerGlowPaint.setColor(primaryColor);
        outerGlowPaint.setStrokeWidth(20f);
        outerGlowPaint.setStrokeCap(Paint.Cap.ROUND);
        outerGlowPaint.setPathEffect(new DashPathEffect(dashIntervals, 0));
        outerGlowPaint.setMaskFilter(new BlurMaskFilter(40f, BlurMaskFilter.Blur.NORMAL));

        innerGlowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        innerGlowPaint.setStyle(Paint.Style.STROKE);
        innerGlowPaint.setColor(primaryColor);
        innerGlowPaint.setStrokeWidth(10f);
        innerGlowPaint.setMaskFilter(new BlurMaskFilter(20f, BlurMaskFilter.Blur.NORMAL));

        centerFillGlowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        centerFillGlowPaint.setStyle(Paint.Style.FILL);
        centerFillGlowPaint.setColor(primaryColor);
        centerFillGlowPaint.setMaskFilter(new BlurMaskFilter(50f, BlurMaskFilter.Blur.NORMAL));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float centerX = getWidth() / 2f;
        float centerY = getHeight() / 2f;

        if (centerX == 0 || centerY == 0) return;

        float radius = Math.min(centerX, centerY) - 30f;

        canvas.drawCircle(centerX, centerY, radius * 0.7f, centerFillGlowPaint);

        canvas.save();
        canvas.rotate(rotationAngle, centerX, centerY);

        canvas.drawCircle(centerX, centerY, radius, outerGlowPaint);
        canvas.drawCircle(centerX, centerY, radius, innerGlowPaint);
        canvas.drawCircle(centerX, centerY, radius, ringPaint);

        canvas.restore();

        rotationAngle += 0.9f;
        if (rotationAngle >= 360) {
            rotationAngle = 0;
        }

        postInvalidateOnAnimation();
    }
}

package com.totalzone.devhabibbd.admin;

import android.os.AsyncTask;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;
import java.util.HashMap;

/**
 * Copyright 2024 Bokku.
 * 
 * This class provides a service to generate OAuth 2.0 access tokens
 * by creating JWTs from service account JSON files.
 */
public class AccessTokenGenerator {

    public interface onTokenResponse {
        void onSuccess(String token);
        void onError(String error);
    }

    public static void generateToken(final InputStream serviceAccountStream, final onTokenResponse callback) {
        new AsyncTask<Void, Void, String>() {
            @Override
            protected String doInBackground(Void... voids) {
                try {
                    // Read the service account JSON file
                    HashMap<String, Object> map = new Gson().fromJson(
                        SketchwareUtil.copyFromInputStream(serviceAccountStream),
                        new TypeToken<HashMap<String, Object>>(){}.getType()
                    );

                    // Extract private key and client email
                    String privateKeyPem = map.get("private_key").toString();
                    String clientEmail = map.get("client_email").toString();

                    // Create JWT header and payload
                    String header = "{\"alg\":\"RS256\",\"typ\":\"JWT\"}";
                    long now = System.currentTimeMillis();
                    long exp = now + 3600 * 1000; // 1 hour expiration
                    String payload = String.format(
                        "{\"iss\":\"%s\",\"aud\":\"https://oauth2.googleapis.com/token\",\"exp\":%d,\"iat\":%d,\"scope\":\"https://www.googleapis.com/auth/cloud-platform\"}",
                        clientEmail, exp / 1000, now / 1000
                    );

                    // Base64 encode header and payload
                    String encodedHeader = Base64.getUrlEncoder().withoutPadding().encodeToString(header.getBytes(StandardCharsets.UTF_8));
                    String encodedPayload = Base64.getUrlEncoder().withoutPadding().encodeToString(payload.getBytes(StandardCharsets.UTF_8));
                    String unsignedJwt = encodedHeader + "." + encodedPayload;

                    // Sign the JWT with the private key
                    String signature = DataSigner.signWithPrivateKey(unsignedJwt, privateKeyPem);
                    String jwt = unsignedJwt + "." + signature;

                    // Make HTTP request to get access token
                    return requestAccessToken(jwt);

                } catch (Exception e) {
                    return "Error: " + e.getMessage();
                }
            }

            @Override
            protected void onPostExecute(String result) {
                if (result.startsWith("Error: ")) {
                    callback.onError(result);
                } else {
                    callback.onSuccess(result);
                }
            }
        }.execute();
    }

    private static String requestAccessToken(String jwt) throws Exception {
        String endpoint = "https://oauth2.googleapis.com/token";

        // Setting up HTTP connection
        URL url = new URL(endpoint);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("POST");
        con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
        con.setDoOutput(true);

        // Request body
        String body = "grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=" + jwt;

        // Send POST request
        OutputStream os = con.getOutputStream();
        os.write(body.getBytes(StandardCharsets.UTF_8));
        os.close();

        // Get response
        BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuilder response = new StringBuilder();

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();

        return response.toString();
    }

    /**
     * Static inner class for signing data with a private key.
     */
    public static class DataSigner {

        /**
         * Signs the given data with the specified private key.
         *
         * @param data The data to be signed.
         * @param privateKeyPem The private key in PEM format.
         * @return The signed data encoded in Base64 URL format.
         * @throws Exception If an error occurs during the signing process.
         */
        public static String signWithPrivateKey(String data, String privateKeyPem) throws Exception {
            // Clean up the private key string
            privateKeyPem = privateKeyPem.replace("-----BEGIN PRIVATE KEY-----", "")
                .replace("-----END PRIVATE KEY-----", "")
                .replaceAll("\\s", "");

            // Decode the private key
            byte[] keyBytes = Base64.getDecoder().decode(privateKeyPem);
            PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            PrivateKey privateKey = keyFactory.generatePrivate(spec);

            // Create the signature
            Signature signature = Signature.getInstance("SHA256withRSA");
            signature.initSign(privateKey);
            signature.update(data.getBytes(StandardCharsets.UTF_8));
            byte[] signatureBytes = signature.sign();

            // Encode the signature in Base64 URL format
            return Base64.getUrlEncoder().withoutPadding().encodeToString(signatureBytes);
        }
    }
}
package com.totalzone.devhabibbd.admin;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.SharedPreferences;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import java.io.InputStream;
import java.net.URL;

public class FCMService extends FirebaseMessagingService {

	private static final String CHANNEL_ID = "fcm_channel";

	@Override
	public void onMessageReceived(RemoteMessage remoteMessage) {
		if (remoteMessage.getData().size() > 0) {
            
            SharedPreferences pref = getSharedPreferences("NotificationPref", Context.MODE_PRIVATE);
			int currentCount = pref.getInt("unread_count", 0);
			SharedPreferences.Editor editor = pref.edit();
			editor.putInt("unread_count", currentCount + 1);
			editor.apply();
            
			String title = remoteMessage.getData().get("title");
			String body = remoteMessage.getData().get("body");
			String imageUrl = remoteMessage.getData().get("image");
			showNotification(title, body, imageUrl);
		}
	}

	private void showNotification(String title, String body, String imageUrl) {
		Intent intent = new Intent(this, MainActivity.class);
		intent.putExtra("title", title);
		intent.putExtra("message", body);
		intent.putExtra("image", imageUrl);

		PendingIntent pendingIntent = PendingIntent.getActivity(
			this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

		NotificationManager notificationManager =
			(NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
			NotificationChannel channel = new NotificationChannel(
				CHANNEL_ID, "FCM Channel", NotificationManager.IMPORTANCE_HIGH);
			notificationManager.createNotificationChannel(channel);
		}

		NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
			.setSmallIcon(R.drawable.app_logo)
			.setAutoCancel(true)
			.setContentTitle(title)
			.setContentText(body)
			.setStyle(new NotificationCompat.BigTextStyle().bigText(body))
			.setContentIntent(pendingIntent);

		new DownloadImageTask(builder).execute(imageUrl);
	}

	private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {

		private NotificationCompat.Builder builder;

		public DownloadImageTask(NotificationCompat.Builder builder) {
			this.builder = builder;
		}

		@Override
		protected Bitmap doInBackground(String... params) {
			String imageUrl = params[0];
			try {
				InputStream in = new URL(imageUrl).openStream();
				return BitmapFactory.decodeStream(in);
			} catch (Exception e) {
				return null;
			}
		}

		@Override
		protected void onPostExecute(Bitmap result) {
			NotificationManager notificationManager =
				(NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
			if (result != null) {
				builder.setStyle(new NotificationCompat.BigPictureStyle()
					.bigPicture(result)
					.bigLargeIcon(null));
			}
			if (notificationManager != null) {
				notificationManager.notify((int) System.currentTimeMillis(), builder.build());
			}
		}
	}
}
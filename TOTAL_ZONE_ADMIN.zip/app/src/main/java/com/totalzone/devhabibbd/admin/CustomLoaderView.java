package com.totalzone.devhabibbd.admin;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

public class CustomLoaderView extends View {

    private Paint outerPaint, innerPaint, centerPaint, glowPaint;
    private Path polygonPath;
    private float outerAngle = 0;
    private float innerAngle = 0;
    private int currentOuterColor = Color.parseColor("#7B3AEC");
    private ValueAnimator colorAnimator;

    public CustomLoaderView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        init();
        startColorAnimation();
    }

    private void init() {
        outerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        outerPaint.setStyle(Paint.Style.STROKE);
        outerPaint.setStrokeWidth(8f);
        outerPaint.setStrokeCap(Paint.Cap.ROUND);

        innerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        innerPaint.setColor(Color.parseColor("#7B3AEC"));
        innerPaint.setStyle(Paint.Style.STROKE);
        innerPaint.setStrokeWidth(8f);

        centerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        centerPaint.setColor(Color.parseColor("#7B3AEC"));
        centerPaint.setStyle(Paint.Style.FILL);

        glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        glowPaint.setColor(Color.parseColor("#7B3AEC"));
        glowPaint.setStyle(Paint.Style.FILL);
        glowPaint.setMaskFilter(new BlurMaskFilter(20f, BlurMaskFilter.Blur.NORMAL));

        polygonPath = new Path();
    }

    private void startColorAnimation() {
        colorAnimator = ValueAnimator.ofObject(
            new ArgbEvaluator(),
            Color.parseColor("#7B3AEC"),
            Color.parseColor("#0D00FF")
        );
        colorAnimator.setDuration(2000);
        colorAnimator.setRepeatCount(ValueAnimator.INFINITE);
        colorAnimator.setRepeatMode(ValueAnimator.REVERSE);
        colorAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animator) {
                currentOuterColor = (int) animator.getAnimatedValue();
                outerPaint.setColor(currentOuterColor);
                innerPaint.setColor(currentOuterColor);
                centerPaint.setColor(currentOuterColor);
                glowPaint.setColor(currentOuterColor);
            }
        });
        colorAnimator.start();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float centerX = getWidth() / 2f;
        float centerY = getHeight() / 2f;
        float radius = Math.min(centerX, centerY) - 20;

        canvas.save();
        canvas.rotate(outerAngle, centerX, centerY);
        RectF rectF = new RectF(centerX - radius, centerY - radius, centerX + radius, centerY + radius);
        
        for (int i = 0; i < 4; i++) {
            canvas.drawArc(rectF, i * 90 + 10, 70, false, outerPaint);
        }
        canvas.restore();

        canvas.save();
        canvas.rotate(-innerAngle, centerX, centerY);

        float innerRadius = radius * 0.65f;
        int sides = 6;
        polygonPath.reset();

        for (int i = 0; i < sides; i++) {
            double angle = Math.toRadians((360.0 / sides) * i - 90);
            float x = (float) (centerX + innerRadius * Math.cos(angle));
            float y = (float) (centerY + innerRadius * Math.sin(angle));

            if (i == 0) {
                polygonPath.moveTo(x, y);
            } else {
                polygonPath.lineTo(x, y);
            }
        }
        polygonPath.close();
        canvas.drawPath(polygonPath, innerPaint);
        canvas.restore();

        float dotRadius = innerRadius * 0.35f;
        canvas.drawCircle(centerX, centerY, dotRadius + 10f, glowPaint);
        canvas.drawCircle(centerX, centerY, dotRadius, centerPaint);

        outerAngle += 3;
        innerAngle += 2;

        if (outerAngle >= 360) outerAngle = 0;
        if (innerAngle >= 360) innerAngle = 0;

        postInvalidateOnAnimation();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (colorAnimator != null) {
            colorAnimator.cancel();
        }
    }
}

package com.totalzone.devhabibbd.admin;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.bumptech.glide.Glide;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class PrantoSliderActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private FloatingActionButton _fab;
	private String Url = "";
	private HashMap<String, Object> Sliders = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> SluderList = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear3;
	private RecyclerView SliderView;
	private ImageView imageview1;
	private TextView textview3;
	
	private Intent New_Web = new Intent();
	private DatabaseReference Pranto_Slider = _firebase.getReference("Pranto_Slider");
	private ChildEventListener _Pranto_Slider_child_listener;
	private TimerTask Time;
	private AlertDialog C;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.pranto_slider);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_fab = findViewById(R.id._fab);
		linear1 = findViewById(R.id.linear1);
		linear3 = findViewById(R.id.linear3);
		SliderView = findViewById(R.id.SliderView);
		imageview1 = findViewById(R.id.imageview1);
		textview3 = findViewById(R.id.textview3);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
				overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
			}
		});
		
		_fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				C = new AlertDialog.Builder(PrantoSliderActivity.this).create();
				LayoutInflater CLI = getLayoutInflater();
				View CCV = (View) CLI.inflate(R.layout.slider_add, null);
				C.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
				C.setView(CCV);
				final TextView Done = (TextView)
				CCV.findViewById(R.id.Done);
				final EditText E1 = (EditText)
				CCV.findViewById(R.id.E1);
				final EditText E2 = (EditText)
				CCV.findViewById(R.id.E2);
				E1.setTextIsSelectable(true);
				E2.setTextIsSelectable(true);
				E1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
				E2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
				Done.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF0D00FF));
				Done.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						if (!E1.getText().toString().equals("")) {
							if (!E2.getText().toString().equals("")) {
								CustomLoading.show(PrantoSliderActivity.this);
								Sliders = new HashMap<>();
								Sliders.put("image_url", E1.getText().toString());
								Sliders.put("image_link", E2.getText().toString());
								Sliders.put("Key", Pranto_Slider.push().getKey());
								Pranto_Slider.child(Sliders.get("Key").toString()).updateChildren(Sliders);
								Sliders.clear();
								Time = new TimerTask() {
									@Override
									public void run() {
										runOnUiThread(new Runnable() {
											@Override
											public void run() {
												C.dismiss();
												CustomLoading.dismiss();
												CustomToast.show(findViewById(android.R.id.content), "Slider add successful", CustomToast.TYPE_SUCCESS, R.font.font3);
											}
										});
									}
								};
								_timer.schedule(Time, (int)(SketchwareUtil.getRandom((int)(500), (int)(1000))));
							}
						}
					}
				});
				C.setCancelable(true);
				C.show();
			}
		});
		
		_Pranto_Slider_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				Pranto_Slider.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						SluderList = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								SluderList.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						SliderView.setAdapter(new SliderViewAdapter(SluderList));
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				Pranto_Slider.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						SluderList = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								SluderList.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						SliderView.setAdapter(new SliderViewAdapter(SluderList));
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				Pranto_Slider.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						SluderList = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								SluderList.add(_map);
							}
						} catch (Exception _e) {
							_e.printStackTrace();
						}
						SliderView.setAdapter(new SliderViewAdapter(SluderList));
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		Pranto_Slider.addChildEventListener(_Pranto_Slider_child_listener);
	}
	
	private void initializeLogic() {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
			Window w =PrantoSliderActivity.this.getWindow();
			w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFF000000);
		}
		SliderView.setLayoutManager(new LinearLayoutManager(this));
	}
	
	@Override
	public void onBackPressed() {
		finish();
		overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
	}
	public class SliderViewAdapter extends RecyclerView.Adapter<SliderViewAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public SliderViewAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.sliders, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout BG = _view.findViewById(R.id.BG);
			final LinearLayout div = _view.findViewById(R.id.div);
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final ImageView Image = _view.findViewById(R.id.Image);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final LinearLayout Delete_Bg = _view.findViewById(R.id.Delete_Bg);
			final ImageView imageview3 = _view.findViewById(R.id.imageview3);
			
			Url = _data.get((int)_position).get("image_url").toString();
			Glide.with(getApplicationContext()).load(Uri.parse(Url)).placeholder(R.drawable.loading).into(Image);
			if (_position < (_data.size() - 1)) {
				div.setVisibility(View.VISIBLE);
			} else {
				div.setVisibility(View.GONE);
			}
			BG.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					if (_data.get((int)_position).get("image_link").toString().contains("https://")) {
						New_Web.setAction(Intent.ACTION_VIEW);
						New_Web.setData(Uri.parse(_data.get((int)_position).get("image_link").toString()));
						startActivity(New_Web);
					}
				}
			});
			Delete_Bg.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					final AlertDialog dialog = new AlertDialog.Builder(PrantoSliderActivity.this).create();
					View inflate = getLayoutInflater().inflate(R.layout.confirm,null); 
					dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
					dialog.setView(inflate);
					LinearLayout confirmBg = (LinearLayout) inflate.findViewById(R.id.confirmBg);
					TextView cancelTv = (TextView) inflate.findViewById(R.id.cancelTv);
					cancelTv.setText("No");
					TextView confrmTv = (TextView) inflate.findViewById(R.id.confrmTv);
					confrmTv.setText("Yes");
					TextView Tv1 = (TextView) inflate.findViewById(R.id.Tv1);
					Tv1.setText("Confirmation! ");
					TextView Tv2 = (TextView) inflate.findViewById(R.id.Tv2);
					Tv2.setText("Do you want to delete this slider?");
					confirmBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF0D00FF));
					cancelTv.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
							dialog.dismiss();
						}
					});
					confirmBg.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
							dialog.dismiss();
							CustomLoading.show(PrantoSliderActivity.this);
							Pranto_Slider.child(_data.get((int)_position).get("Key").toString()).removeValue();
							Time = new TimerTask() {
								@Override
								public void run() {
									runOnUiThread(new Runnable() {
										@Override
										public void run() {
											CustomLoading.dismiss();
											CustomToast.show(findViewById(android.R.id.content), "Slider delete successful", CustomToast.TYPE_SUCCESS, R.font.font3);
										}
									});
								}
							};
							_timer.schedule(Time, (int)(SketchwareUtil.getRandom((int)(500), (int)(1000))));
						}
					});
					dialog.setCancelable(false);
					dialog.show();
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}
package com.totalzone.devhabibbd.admin;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class PrantoSettingDetailsActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private HashMap<String, Object> Map = new HashMap<>();
	private String Payment_Type = "";
	private String Bk_Type = "";
	private String Ng_Type = "";
	private String Rk_Type = "";
	
	private LinearLayout BG;
	private LinearLayout linear3;
	private ScrollView vscroll1;
	private ImageView imageview1;
	private TextView textview3;
	private LinearLayout linear17;
	private LinearLayout BG1;
	private LinearLayout BG2;
	private LinearLayout BG3;
	private LinearLayout BG4;
	private TextView Tv5;
	private LinearLayout BOX1;
	private TextView textview4;
	private LinearLayout BOX2;
	private TextView textview5;
	private LinearLayout BOX3;
	private TextView textview26;
	private LinearLayout BOX_4;
	private LinearLayout Lg_B1;
	private EditText E1;
	private EditText E2;
	private EditText E3;
	private EditText E_4;
	private TextView Tv8;
	private ProgressBar prog;
	private LinearLayout pbg1;
	private LinearLayout pbg2;
	private LinearLayout pbg3;
	private LinearLayout pbg4;
	private LinearLayout pbg5;
	private LinearLayout pbg6;
	private LinearLayout Lg_B2;
	private TextView textview6;
	private LinearLayout linear5;
	private TextView textview7;
	private CheckBox checkbox;
	private TextView textview8;
	private LinearLayout linear7;
	private TextView textview11;
	private LinearLayout BKBOX1;
	private CheckBox checkbox1;
	private CheckBox checkbox2;
	private CheckBox checkbox3;
	private ImageView imageview4;
	private EditText BkNum;
	private TextView textview12;
	private LinearLayout linear10;
	private TextView textview13;
	private LinearLayout NGBOX1;
	private CheckBox checkbox4;
	private CheckBox checkbox5;
	private CheckBox checkbox6;
	private ImageView imageview5;
	private EditText NgNum;
	private TextView textview14;
	private LinearLayout linear13;
	private TextView textview15;
	private LinearLayout RKBOX1;
	private CheckBox checkbox7;
	private CheckBox checkbox8;
	private CheckBox checkbox9;
	private ImageView imageview6;
	private EditText RkNum;
	private TextView textview16;
	private LinearLayout MINIDPBOX;
	private TextView textview17;
	private LinearLayout MAXDPBOX;
	private ImageView imageview10;
	private EditText miniDp;
	private EditText miniDpx;
	private ImageView imageview8;
	private ImageView imageview7;
	private EditText maxDp;
	private TextView textview18;
	private LinearLayout MINIWDBOX;
	private TextView textview19;
	private LinearLayout MAXWDBOX;
	private ImageView imageview11;
	private EditText miniWd;
	private ImageView imageview9;
	private EditText maxWd;
	private TextView Tv_8;
	private ProgressBar progressbar1;
	private TextView textview20;
	private LinearLayout VBOX1;
	private TextView textview21;
	private LinearLayout VBOX2;
	private TextView textview22;
	private LinearLayout VBOX3;
	private TextView textview23;
	private LinearLayout VBOX4;
	private LinearLayout Lg_B3;
	private ImageView imageview12;
	private EditText videoE1;
	private ImageView imageview14;
	private EditText videoE2;
	private ImageView imageview15;
	private EditText videoE3;
	private ImageView imageview16;
	private EditText videoE4;
	private TextView Tv_9;
	private ProgressBar progressbar2;
	private TextView textview24;
	private LinearLayout UBOX1;
	private TextView textview25;
	private LinearLayout UBOX2;
	private LinearLayout Lg_B4;
	private ImageView imageview17;
	private EditText updateE1;
	private ImageView imageview18;
	private EditText updateE2;
	private TextView Tv_10;
	private ProgressBar progressbar3;
	
	private TimerTask Time;
	private DatabaseReference Pranto_Admin = _firebase.getReference("Pranto_Admin");
	private ChildEventListener _Pranto_Admin_child_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.pranto_setting_details);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		BG = findViewById(R.id.BG);
		linear3 = findViewById(R.id.linear3);
		vscroll1 = findViewById(R.id.vscroll1);
		imageview1 = findViewById(R.id.imageview1);
		textview3 = findViewById(R.id.textview3);
		linear17 = findViewById(R.id.linear17);
		BG1 = findViewById(R.id.BG1);
		BG2 = findViewById(R.id.BG2);
		BG3 = findViewById(R.id.BG3);
		BG4 = findViewById(R.id.BG4);
		Tv5 = findViewById(R.id.Tv5);
		BOX1 = findViewById(R.id.BOX1);
		textview4 = findViewById(R.id.textview4);
		BOX2 = findViewById(R.id.BOX2);
		textview5 = findViewById(R.id.textview5);
		BOX3 = findViewById(R.id.BOX3);
		textview26 = findViewById(R.id.textview26);
		BOX_4 = findViewById(R.id.BOX_4);
		Lg_B1 = findViewById(R.id.Lg_B1);
		E1 = findViewById(R.id.E1);
		E2 = findViewById(R.id.E2);
		E3 = findViewById(R.id.E3);
		E_4 = findViewById(R.id.E_4);
		Tv8 = findViewById(R.id.Tv8);
		prog = findViewById(R.id.prog);
		pbg1 = findViewById(R.id.pbg1);
		pbg2 = findViewById(R.id.pbg2);
		pbg3 = findViewById(R.id.pbg3);
		pbg4 = findViewById(R.id.pbg4);
		pbg5 = findViewById(R.id.pbg5);
		pbg6 = findViewById(R.id.pbg6);
		Lg_B2 = findViewById(R.id.Lg_B2);
		textview6 = findViewById(R.id.textview6);
		linear5 = findViewById(R.id.linear5);
		textview7 = findViewById(R.id.textview7);
		checkbox = findViewById(R.id.checkbox);
		textview8 = findViewById(R.id.textview8);
		linear7 = findViewById(R.id.linear7);
		textview11 = findViewById(R.id.textview11);
		BKBOX1 = findViewById(R.id.BKBOX1);
		checkbox1 = findViewById(R.id.checkbox1);
		checkbox2 = findViewById(R.id.checkbox2);
		checkbox3 = findViewById(R.id.checkbox3);
		imageview4 = findViewById(R.id.imageview4);
		BkNum = findViewById(R.id.BkNum);
		textview12 = findViewById(R.id.textview12);
		linear10 = findViewById(R.id.linear10);
		textview13 = findViewById(R.id.textview13);
		NGBOX1 = findViewById(R.id.NGBOX1);
		checkbox4 = findViewById(R.id.checkbox4);
		checkbox5 = findViewById(R.id.checkbox5);
		checkbox6 = findViewById(R.id.checkbox6);
		imageview5 = findViewById(R.id.imageview5);
		NgNum = findViewById(R.id.NgNum);
		textview14 = findViewById(R.id.textview14);
		linear13 = findViewById(R.id.linear13);
		textview15 = findViewById(R.id.textview15);
		RKBOX1 = findViewById(R.id.RKBOX1);
		checkbox7 = findViewById(R.id.checkbox7);
		checkbox8 = findViewById(R.id.checkbox8);
		checkbox9 = findViewById(R.id.checkbox9);
		imageview6 = findViewById(R.id.imageview6);
		RkNum = findViewById(R.id.RkNum);
		textview16 = findViewById(R.id.textview16);
		MINIDPBOX = findViewById(R.id.MINIDPBOX);
		textview17 = findViewById(R.id.textview17);
		MAXDPBOX = findViewById(R.id.MAXDPBOX);
		imageview10 = findViewById(R.id.imageview10);
		miniDp = findViewById(R.id.miniDp);
		miniDpx = findViewById(R.id.miniDpx);
		imageview8 = findViewById(R.id.imageview8);
		imageview7 = findViewById(R.id.imageview7);
		maxDp = findViewById(R.id.maxDp);
		textview18 = findViewById(R.id.textview18);
		MINIWDBOX = findViewById(R.id.MINIWDBOX);
		textview19 = findViewById(R.id.textview19);
		MAXWDBOX = findViewById(R.id.MAXWDBOX);
		imageview11 = findViewById(R.id.imageview11);
		miniWd = findViewById(R.id.miniWd);
		imageview9 = findViewById(R.id.imageview9);
		maxWd = findViewById(R.id.maxWd);
		Tv_8 = findViewById(R.id.Tv_8);
		progressbar1 = findViewById(R.id.progressbar1);
		textview20 = findViewById(R.id.textview20);
		VBOX1 = findViewById(R.id.VBOX1);
		textview21 = findViewById(R.id.textview21);
		VBOX2 = findViewById(R.id.VBOX2);
		textview22 = findViewById(R.id.textview22);
		VBOX3 = findViewById(R.id.VBOX3);
		textview23 = findViewById(R.id.textview23);
		VBOX4 = findViewById(R.id.VBOX4);
		Lg_B3 = findViewById(R.id.Lg_B3);
		imageview12 = findViewById(R.id.imageview12);
		videoE1 = findViewById(R.id.videoE1);
		imageview14 = findViewById(R.id.imageview14);
		videoE2 = findViewById(R.id.videoE2);
		imageview15 = findViewById(R.id.imageview15);
		videoE3 = findViewById(R.id.videoE3);
		imageview16 = findViewById(R.id.imageview16);
		videoE4 = findViewById(R.id.videoE4);
		Tv_9 = findViewById(R.id.Tv_9);
		progressbar2 = findViewById(R.id.progressbar2);
		textview24 = findViewById(R.id.textview24);
		UBOX1 = findViewById(R.id.UBOX1);
		textview25 = findViewById(R.id.textview25);
		UBOX2 = findViewById(R.id.UBOX2);
		Lg_B4 = findViewById(R.id.Lg_B4);
		imageview17 = findViewById(R.id.imageview17);
		updateE1 = findViewById(R.id.updateE1);
		imageview18 = findViewById(R.id.imageview18);
		updateE2 = findViewById(R.id.updateE2);
		Tv_10 = findViewById(R.id.Tv_10);
		progressbar3 = findViewById(R.id.progressbar3);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
				overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
			}
		});
		
		Lg_B1.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				_clickAnimation(Lg_B1);
				return true;
			}
		});
		
		Lg_B1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_clickAnimation(Lg_B1);
				if (!E1.getText().toString().equals("")) {
					if (!E2.getText().toString().equals("")) {
						if (!E3.getText().toString().equals("")) {
							prog.setVisibility(View.VISIBLE);
							Tv8.setVisibility(View.GONE);
							Map = new HashMap<>();
							Map.put("Notice", E1.getText().toString());
							Map.put("Support", E2.getText().toString());
							Map.put("Telegram", E3.getText().toString());
							Map.put("Topup", E_4.getText().toString());
							Pranto_Admin.child("Pranto_Admin").updateChildren(Map);
							Map.clear();
							Time = new TimerTask() {
								@Override
								public void run() {
									runOnUiThread(new Runnable() {
										@Override
										public void run() {
											prog.setVisibility(View.GONE);
											Tv8.setVisibility(View.VISIBLE);
											CustomToast.show(findViewById(android.R.id.content), "Information update successful", CustomToast.TYPE_SUCCESS, R.font.font3);
										}
									});
								}
							};
							_timer.schedule(Time, (int)(SketchwareUtil.getRandom((int)(500), (int)(1000))));
						} else {
							CustomToast.show(findViewById(android.R.id.content), "Please fill in all fields", CustomToast.TYPE_ERROR, R.font.font3);
						}
					} else {
						CustomToast.show(findViewById(android.R.id.content), "Please fill in all fields", CustomToast.TYPE_ERROR, R.font.font3);
					}
				} else {
					CustomToast.show(findViewById(android.R.id.content), "Please fill in all fields", CustomToast.TYPE_ERROR, R.font.font3);
				}
			}
		});
		
		Lg_B2.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				_clickAnimation(Lg_B2);
				return true;
			}
		});
		
		Lg_B2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_clickAnimation(Lg_B2);
				if (!Payment_Type.equals("")) {
					if (!Bk_Type.equals("")) {
						if (!Ng_Type.equals("")) {
							if (!Rk_Type.equals("")) {
								if (!BkNum.getText().toString().equals("")) {
									if (!NgNum.getText().toString().equals("")) {
										if (!RkNum.getText().toString().equals("")) {
											if (!miniDp.getText().toString().equals("")) {
												if (!maxDp.getText().toString().equals("")) {
													if (!miniWd.getText().toString().equals("")) {
														if (!maxWd.getText().toString().equals("")) {
															progressbar1.setVisibility(View.VISIBLE);
															Tv_8.setVisibility(View.GONE);
															Map = new HashMap<>();
															Map.put("Payment Type", Payment_Type);
															Map.put("Bkash Type", Bk_Type);
															Map.put("Nagad Type", Ng_Type);
															Map.put("Rocket Type", Rk_Type);
															Map.put("Bkash Number", BkNum.getText().toString());
															Map.put("Nagad Number", NgNum.getText().toString());
															Map.put("Rocket Number", RkNum.getText().toString());
															Map.put("Minimum Deposit", miniDp.getText().toString());
															Map.put("Maximum Deposit", maxDp.getText().toString());
															Map.put("Minimum Withdraw", miniWd.getText().toString());
															Map.put("Maximum Withdraw", maxWd.getText().toString());
															Pranto_Admin.child("Pranto_Admin").updateChildren(Map);
															Map.clear();
															Time = new TimerTask() {
																@Override
																public void run() {
																	runOnUiThread(new Runnable() {
																		@Override
																		public void run() {
																			progressbar1.setVisibility(View.GONE);
																			Tv_8.setVisibility(View.VISIBLE);
																			CustomToast.show(findViewById(android.R.id.content), "Information update successful", CustomToast.TYPE_SUCCESS, R.font.font3);
																		}
																	});
																}
															};
															_timer.schedule(Time, (int)(SketchwareUtil.getRandom((int)(500), (int)(1000))));
														} else {
															CustomToast.show(findViewById(android.R.id.content), "Please fill in all fields", CustomToast.TYPE_ERROR, R.font.font3);
														}
													} else {
														CustomToast.show(findViewById(android.R.id.content), "Please fill in all fields", CustomToast.TYPE_ERROR, R.font.font3);
													}
												} else {
													CustomToast.show(findViewById(android.R.id.content), "Please fill in all fields", CustomToast.TYPE_ERROR, R.font.font3);
												}
											} else {
												CustomToast.show(findViewById(android.R.id.content), "Please fill in all fields", CustomToast.TYPE_ERROR, R.font.font3);
											}
										} else {
											CustomToast.show(findViewById(android.R.id.content), "Please fill in all fields", CustomToast.TYPE_ERROR, R.font.font3);
										}
									} else {
										CustomToast.show(findViewById(android.R.id.content), "Please fill in all fields", CustomToast.TYPE_ERROR, R.font.font3);
									}
								} else {
									CustomToast.show(findViewById(android.R.id.content), "Please fill in all fields", CustomToast.TYPE_ERROR, R.font.font3);
								}
							} else {
								CustomToast.show(findViewById(android.R.id.content), "Please select rocket type", CustomToast.TYPE_ERROR, R.font.font3);
							}
						} else {
							CustomToast.show(findViewById(android.R.id.content), "Please select nagad type", CustomToast.TYPE_ERROR, R.font.font3);
						}
					} else {
						CustomToast.show(findViewById(android.R.id.content), "Please select bkash type", CustomToast.TYPE_ERROR, R.font.font3);
					}
				} else {
					CustomToast.show(findViewById(android.R.id.content), "Please select payment type", CustomToast.TYPE_ERROR, R.font.font3);
				}
			}
		});
		
		checkbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					Payment_Type = "Auto";
					checkbox.setChecked(true);
				} else {
					Payment_Type = "Manual";
					checkbox.setChecked(false);
				}
			}
		});
		
		checkbox1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					Bk_Type = "Personal";
					checkbox1.setChecked(true);
					checkbox2.setChecked(false);
					checkbox3.setChecked(false);
				} else {
					Bk_Type = "";
					checkbox1.setChecked(false);
					checkbox2.setChecked(false);
					checkbox3.setChecked(false);
				}
			}
		});
		
		checkbox2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					Bk_Type = "Agent";
					checkbox1.setChecked(false);
					checkbox2.setChecked(true);
					checkbox3.setChecked(false);
				} else {
					Bk_Type = "";
					checkbox1.setChecked(false);
					checkbox2.setChecked(false);
					checkbox3.setChecked(false);
				}
			}
		});
		
		checkbox3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					Bk_Type = "Merchant";
					checkbox1.setChecked(false);
					checkbox2.setChecked(false);
					checkbox3.setChecked(true);
				} else {
					Bk_Type = "";
					checkbox1.setChecked(false);
					checkbox2.setChecked(false);
					checkbox3.setChecked(false);
				}
			}
		});
		
		checkbox4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					Ng_Type = "Personal";
					checkbox4.setChecked(true);
					checkbox5.setChecked(false);
					checkbox6.setChecked(false);
				} else {
					Ng_Type = "";
					checkbox4.setChecked(false);
					checkbox5.setChecked(false);
					checkbox6.setChecked(false);
				}
			}
		});
		
		checkbox5.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					Ng_Type = "Agent";
					checkbox4.setChecked(false);
					checkbox5.setChecked(true);
					checkbox6.setChecked(false);
				} else {
					Ng_Type = "";
					checkbox4.setChecked(false);
					checkbox5.setChecked(false);
					checkbox6.setChecked(false);
				}
			}
		});
		
		checkbox6.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					Ng_Type = "Merchant";
					checkbox4.setChecked(false);
					checkbox5.setChecked(false);
					checkbox6.setChecked(true);
				} else {
					Ng_Type = "";
					checkbox4.setChecked(false);
					checkbox5.setChecked(false);
					checkbox6.setChecked(false);
				}
			}
		});
		
		checkbox7.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					Rk_Type = "Personal";
					checkbox7.setChecked(true);
					checkbox8.setChecked(false);
					checkbox9.setChecked(false);
				} else {
					Rk_Type = "";
					checkbox7.setChecked(false);
					checkbox8.setChecked(false);
					checkbox9.setChecked(false);
				}
			}
		});
		
		checkbox8.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					Rk_Type = "Agent";
					checkbox7.setChecked(false);
					checkbox8.setChecked(true);
					checkbox9.setChecked(false);
				} else {
					Rk_Type = "";
					checkbox7.setChecked(false);
					checkbox8.setChecked(false);
					checkbox9.setChecked(false);
				}
			}
		});
		
		checkbox9.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					Rk_Type = "Merchant";
					checkbox7.setChecked(false);
					checkbox8.setChecked(false);
					checkbox9.setChecked(true);
				} else {
					Rk_Type = "";
					checkbox7.setChecked(false);
					checkbox8.setChecked(false);
					checkbox9.setChecked(false);
				}
			}
		});
		
		Lg_B3.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				_clickAnimation(Lg_B3);
				return true;
			}
		});
		
		Lg_B3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_clickAnimation(Lg_B3);
				if (!videoE1.getText().toString().equals("")) {
					if (!videoE2.getText().toString().equals("")) {
						if (!videoE3.getText().toString().equals("")) {
							if (!videoE4.getText().toString().equals("")) {
								progressbar2.setVisibility(View.VISIBLE);
								Tv_9.setVisibility(View.GONE);
								Map = new HashMap<>();
								Map.put("How To Create Account", videoE1.getText().toString());
								Map.put("How To Add Money", videoE2.getText().toString());
								Map.put("How To Withdraw", videoE3.getText().toString());
								Map.put("How To Join Match", videoE4.getText().toString());
								Pranto_Admin.child("Pranto_Admin").updateChildren(Map);
								Map.clear();
								Time = new TimerTask() {
									@Override
									public void run() {
										runOnUiThread(new Runnable() {
											@Override
											public void run() {
												progressbar2.setVisibility(View.GONE);
												Tv_9.setVisibility(View.VISIBLE);
												CustomToast.show(findViewById(android.R.id.content), "Information update successful", CustomToast.TYPE_SUCCESS, R.font.font3);
											}
										});
									}
								};
								_timer.schedule(Time, (int)(SketchwareUtil.getRandom((int)(500), (int)(1000))));
							} else {
								CustomToast.show(findViewById(android.R.id.content), "Please fill in all fields", CustomToast.TYPE_ERROR, R.font.font3);
							}
						} else {
							CustomToast.show(findViewById(android.R.id.content), "Please fill in all fields", CustomToast.TYPE_ERROR, R.font.font3);
						}
					} else {
						CustomToast.show(findViewById(android.R.id.content), "Please fill in all fields", CustomToast.TYPE_ERROR, R.font.font3);
					}
				} else {
					CustomToast.show(findViewById(android.R.id.content), "Please fill in all fields", CustomToast.TYPE_ERROR, R.font.font3);
				}
			}
		});
		
		Lg_B4.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				_clickAnimation(Lg_B4);
				return true;
			}
		});
		
		Lg_B4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_clickAnimation(Lg_B4);
				if (!updateE1.getText().toString().equals("")) {
					if (!updateE2.getText().toString().equals("")) {
						progressbar3.setVisibility(View.VISIBLE);
						Tv_10.setVisibility(View.GONE);
						Map = new HashMap<>();
						Map.put("Version", updateE1.getText().toString());
						Map.put("Update Url", updateE2.getText().toString());
						Pranto_Admin.child("Pranto_Admin").updateChildren(Map);
						Map.clear();
						Time = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										progressbar3.setVisibility(View.GONE);
										Tv_10.setVisibility(View.VISIBLE);
										CustomToast.show(findViewById(android.R.id.content), "Information update successful", CustomToast.TYPE_SUCCESS, R.font.font3);
									}
								});
							}
						};
						_timer.schedule(Time, (int)(SketchwareUtil.getRandom((int)(500), (int)(1000))));
					} else {
						CustomToast.show(findViewById(android.R.id.content), "Please fill in all fields", CustomToast.TYPE_ERROR, R.font.font3);
					}
				} else {
					CustomToast.show(findViewById(android.R.id.content), "Please fill in all fields", CustomToast.TYPE_ERROR, R.font.font3);
				}
			}
		});
		
		_Pranto_Admin_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals("Pranto_Admin")) {
					if (_childValue.containsKey("Notice")) {
						E1.setText(_childValue.get("Notice").toString());
					}
					if (_childValue.containsKey("Support")) {
						E2.setText(_childValue.get("Support").toString());
					}
					if (_childValue.containsKey("Telegram")) {
						E3.setText(_childValue.get("Telegram").toString());
					}
					if (_childValue.containsKey("Topup")) {
						E_4.setText(_childValue.get("Topup").toString());
					}
					if (_childValue.containsKey("Bkash Number")) {
						BkNum.setText(_childValue.get("Bkash Number").toString());
					}
					if (_childValue.containsKey("Nagad Number")) {
						NgNum.setText(_childValue.get("Nagad Number").toString());
					}
					if (_childValue.containsKey("Rocket Number")) {
						RkNum.setText(_childValue.get("Rocket Number").toString());
					}
					if (_childValue.containsKey("Minimum Deposit")) {
						miniDp.setText(_childValue.get("Minimum Deposit").toString());
					}
					if (_childValue.containsKey("Maximum Deposit")) {
						maxDp.setText(_childValue.get("Maximum Deposit").toString());
					}
					if (_childValue.containsKey("Minimum Withdraw")) {
						miniWd.setText(_childValue.get("Minimum Withdraw").toString());
					}
					if (_childValue.containsKey("Maximum Withdraw")) {
						maxWd.setText(_childValue.get("Maximum Withdraw").toString());
					}
					if (_childValue.containsKey("Bkash Type")) {
						if (_childValue.get("Bkash Type").toString().equals("Personal")) {
							Bk_Type = "Personal";
							checkbox1.setChecked(true);
							checkbox2.setChecked(false);
							checkbox3.setChecked(false);
						} else {
							if (_childValue.get("Bkash Type").toString().equals("Agent")) {
								Bk_Type = "Agent";
								checkbox1.setChecked(false);
								checkbox2.setChecked(true);
								checkbox3.setChecked(false);
							} else {
								if (_childValue.get("Bkash Type").toString().equals("Merchant")) {
									Bk_Type = "Merchant";
									checkbox1.setChecked(false);
									checkbox2.setChecked(false);
									checkbox3.setChecked(true);
								}
							}
						}
					}
					if (_childValue.containsKey("Nagad Type")) {
						if (_childValue.get("Nagad Type").toString().equals("Personal")) {
							Ng_Type = "Personal";
							checkbox4.setChecked(true);
							checkbox5.setChecked(false);
							checkbox6.setChecked(false);
						} else {
							if (_childValue.get("Nagad Type").toString().equals("Agent")) {
								Ng_Type = "Agent";
								checkbox4.setChecked(false);
								checkbox5.setChecked(true);
								checkbox6.setChecked(false);
							} else {
								if (_childValue.get("Nagad Type").toString().equals("Merchant")) {
									Ng_Type = "Merchant";
									checkbox4.setChecked(false);
									checkbox5.setChecked(false);
									checkbox6.setChecked(true);
								}
							}
						}
					}
					if (_childValue.containsKey("Rocket Type")) {
						if (_childValue.get("Rocket Type").toString().equals("Personal")) {
							Rk_Type = "Personal";
							checkbox7.setChecked(true);
							checkbox8.setChecked(false);
							checkbox9.setChecked(false);
						} else {
							if (_childValue.get("Rocket Type").toString().equals("Agent")) {
								Rk_Type = "Agent";
								checkbox7.setChecked(false);
								checkbox8.setChecked(true);
								checkbox9.setChecked(false);
							} else {
								if (_childValue.get("Rocket Type").toString().equals("Merchant")) {
									Rk_Type = "Merchant";
									checkbox7.setChecked(false);
									checkbox8.setChecked(false);
									checkbox9.setChecked(true);
								}
							}
						}
					}
					if (_childValue.containsKey("Payment Type")) {
						if (_childValue.get("Payment Type").toString().equals("Auto")) {
							Payment_Type = "Auto";
							checkbox.setChecked(true);
						} else {
							Payment_Type = "Manual";
							checkbox.setChecked(false);
						}
					}
					if (_childValue.containsKey("How To Create Account")) {
						videoE1.setText(_childValue.get("How To Create Account").toString());
					}
					if (_childValue.containsKey("How To Add Money")) {
						videoE2.setText(_childValue.get("How To Add Money").toString());
					}
					if (_childValue.containsKey("How To Withdraw")) {
						videoE3.setText(_childValue.get("How To Withdraw").toString());
					}
					if (_childValue.containsKey("How To Join Match")) {
						videoE4.setText(_childValue.get("How To Join Match").toString());
					}
					if (_childValue.containsKey("Version")) {
						updateE1.setText(_childValue.get("Version").toString());
					}
					if (_childValue.containsKey("Update Url")) {
						updateE2.setText(_childValue.get("Update Url").toString());
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals("Pranto_Admin")) {
					if (_childValue.containsKey("Notice")) {
						E1.setText(_childValue.get("Notice").toString());
					}
					if (_childValue.containsKey("Support")) {
						E2.setText(_childValue.get("Support").toString());
					}
					if (_childValue.containsKey("Telegram")) {
						E3.setText(_childValue.get("Telegram").toString());
					}
					if (_childValue.containsKey("Topup")) {
						E_4.setText(_childValue.get("Topup").toString());
					}
					if (_childValue.containsKey("Bkash Number")) {
						BkNum.setText(_childValue.get("Bkash Number").toString());
					}
					if (_childValue.containsKey("Nagad Number")) {
						NgNum.setText(_childValue.get("Nagad Number").toString());
					}
					if (_childValue.containsKey("Rocket Number")) {
						RkNum.setText(_childValue.get("Rocket Number").toString());
					}
					if (_childValue.containsKey("Minimum Deposit")) {
						miniDp.setText(_childValue.get("Minimum Deposit").toString());
					}
					if (_childValue.containsKey("Maximum Deposit")) {
						maxDp.setText(_childValue.get("Maximum Deposit").toString());
					}
					if (_childValue.containsKey("Minimum Withdraw")) {
						miniWd.setText(_childValue.get("Minimum Withdraw").toString());
					}
					if (_childValue.containsKey("Maximum Withdraw")) {
						maxWd.setText(_childValue.get("Maximum Withdraw").toString());
					}
					if (_childValue.containsKey("Bkash Type")) {
						if (_childValue.get("Bkash Type").toString().equals("Personal")) {
							Bk_Type = "Personal";
							checkbox1.setChecked(true);
							checkbox2.setChecked(false);
							checkbox3.setChecked(false);
						} else {
							if (_childValue.get("Bkash Type").toString().equals("Agent")) {
								Bk_Type = "Agent";
								checkbox1.setChecked(false);
								checkbox2.setChecked(true);
								checkbox3.setChecked(false);
							} else {
								if (_childValue.get("Bkash Type").toString().equals("Merchant")) {
									Bk_Type = "Merchant";
									checkbox1.setChecked(false);
									checkbox2.setChecked(false);
									checkbox3.setChecked(true);
								}
							}
						}
					}
					if (_childValue.containsKey("Nagad Type")) {
						if (_childValue.get("Nagad Type").toString().equals("Personal")) {
							Ng_Type = "Personal";
							checkbox4.setChecked(true);
							checkbox5.setChecked(false);
							checkbox6.setChecked(false);
						} else {
							if (_childValue.get("Nagad Type").toString().equals("Agent")) {
								Ng_Type = "Agent";
								checkbox4.setChecked(false);
								checkbox5.setChecked(true);
								checkbox6.setChecked(false);
							} else {
								if (_childValue.get("Nagad Type").toString().equals("Merchant")) {
									Ng_Type = "Merchant";
									checkbox4.setChecked(false);
									checkbox5.setChecked(false);
									checkbox6.setChecked(true);
								}
							}
						}
					}
					if (_childValue.containsKey("Rocket Type")) {
						if (_childValue.get("Rocket Type").toString().equals("Personal")) {
							Rk_Type = "Personal";
							checkbox7.setChecked(true);
							checkbox8.setChecked(false);
							checkbox9.setChecked(false);
						} else {
							if (_childValue.get("Rocket Type").toString().equals("Agent")) {
								Rk_Type = "Agent";
								checkbox7.setChecked(false);
								checkbox8.setChecked(true);
								checkbox9.setChecked(false);
							} else {
								if (_childValue.get("Rocket Type").toString().equals("Merchant")) {
									Rk_Type = "Merchant";
									checkbox7.setChecked(false);
									checkbox8.setChecked(false);
									checkbox9.setChecked(true);
								}
							}
						}
					}
					if (_childValue.containsKey("Payment Type")) {
						if (_childValue.get("Payment Type").toString().equals("Auto")) {
							Payment_Type = "Auto";
							checkbox.setChecked(true);
						} else {
							Payment_Type = "Manual";
							checkbox.setChecked(false);
						}
					}
					if (_childValue.containsKey("How To Create Account")) {
						videoE1.setText(_childValue.get("How To Create Account").toString());
					}
					if (_childValue.containsKey("How To Add Money")) {
						videoE2.setText(_childValue.get("How To Add Money").toString());
					}
					if (_childValue.containsKey("How To Withdraw")) {
						videoE3.setText(_childValue.get("How To Withdraw").toString());
					}
					if (_childValue.containsKey("How To Join Match")) {
						videoE4.setText(_childValue.get("How To Join Match").toString());
					}
					if (_childValue.containsKey("Version")) {
						updateE1.setText(_childValue.get("Version").toString());
					}
					if (_childValue.containsKey("Update Url")) {
						updateE2.setText(_childValue.get("Update Url").toString());
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		Pranto_Admin.addChildEventListener(_Pranto_Admin_child_listener);
	}
	
	private void initializeLogic() {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
			Window w =PrantoSettingDetailsActivity.this.getWindow();
			w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFF000000);
		}
		BOX1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		BOX2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		BOX3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		BOX_4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		Lg_B1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF0D00FF));
		Lg_B2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF0D00FF));
		Lg_B3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF0D00FF));
		Lg_B4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF0D00FF));
		Tv8.setVisibility(View.VISIBLE);
		prog.setVisibility(View.GONE);
		Tv_8.setVisibility(View.VISIBLE);
		progressbar1.setVisibility(View.GONE);
		Tv_9.setVisibility(View.VISIBLE);
		progressbar2.setVisibility(View.GONE);
		Tv_10.setVisibility(View.VISIBLE);
		progressbar3.setVisibility(View.GONE);
		pbg1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFF212121, Color.TRANSPARENT));
		pbg2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFF212121, Color.TRANSPARENT));
		pbg3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFF212121, Color.TRANSPARENT));
		pbg4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFF212121, Color.TRANSPARENT));
		pbg5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFF212121, Color.TRANSPARENT));
		pbg6.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFF212121, Color.TRANSPARENT));
		BKBOX1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		NGBOX1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		RKBOX1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		MINIDPBOX.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		MAXDPBOX.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		MINIWDBOX.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		MAXWDBOX.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		VBOX1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		VBOX2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		VBOX3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		VBOX4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		UBOX1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		UBOX2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		if (getIntent().getStringExtra("Type").equals("App")) {
			textview3.setText("App Setting");
			BG1.setVisibility(View.VISIBLE);
			BG2.setVisibility(View.GONE);
			BG3.setVisibility(View.GONE);
			BG4.setVisibility(View.GONE);
		} else {
			if (getIntent().getStringExtra("Type").equals("Payment")) {
				textview3.setText("Payment Setting");
				BG2.setVisibility(View.VISIBLE);
				BG1.setVisibility(View.GONE);
				BG3.setVisibility(View.GONE);
				BG4.setVisibility(View.GONE);
			} else {
				if (getIntent().getStringExtra("Type").equals("Video")) {
					textview3.setText("Video Setting");
					BG1.setVisibility(View.GONE);
					BG2.setVisibility(View.GONE);
					BG3.setVisibility(View.VISIBLE);
					BG4.setVisibility(View.GONE);
				} else {
					if (getIntent().getStringExtra("Type").equals("Update")) {
						textview3.setText("App Update");
						BG1.setVisibility(View.GONE);
						BG2.setVisibility(View.GONE);
						BG3.setVisibility(View.GONE);
						BG4.setVisibility(View.VISIBLE);
					}
				}
			}
		}
	}
	
	@Override
	public void onBackPressed() {
		finish();
		overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
	}
	public void _clickAnimation(final View _view) {
		ScaleAnimation clickAnim = new ScaleAnimation(
		    1f, 0.9f,
		    1f, 0.9f,
		    Animation.RELATIVE_TO_SELF, 0.5f,
		    Animation.RELATIVE_TO_SELF, 0.5f
		);
		
		clickAnim.setDuration(100);
		clickAnim.setRepeatCount(1);
		clickAnim.setRepeatMode(Animation.REVERSE);
		clickAnim.setFillAfter(false);
		
		_view.startAnimation(clickAnim);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}
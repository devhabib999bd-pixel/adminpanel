package com.totalzone.devhabibbd.admin;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.google.firebase.FirebaseApp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class PrantoAdminDetailsActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private String Role = "";
	private HashMap<String, Object> IM_PRANTO = new HashMap<>();
	private HashMap<String, Object> admin = new HashMap<>();
	private String p1 = "";
	private String p2 = "";
	private String p3 = "";
	private String p4 = "";
	private String p5 = "";
	private String p6 = "";
	private String p7 = "";
	private String p8 = "";
	private String p9 = "";
	private String p10 = "";
	private String p11 = "";
	private String p12 = "";
	private String p13 = "";
	private HashMap<String, Object> addResponse = new HashMap<>();
	private HashMap<String, Object> dataResponse = new HashMap<>();
	private String up1 = "";
	private String up2 = "";
	private String up3 = "";
	private String up4 = "";
	private String up5 = "";
	private String up6 = "";
	private String up7 = "";
	private String up8 = "";
	private String up9 = "";
	private String up10 = "";
	private String up11 = "";
	private String up12 = "";
	private String up13 = "";
	private String uRole = "";
	private HashMap<String, Object> update = new HashMap<>();
	private HashMap<String, Object> updateResponse = new HashMap<>();
	private HashMap<String, Object> mapU1 = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> permission_list = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> adminTxn = new ArrayList<>();
	
	private LinearLayout BG;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private ImageView imageview1;
	private TextView textview3;
	private ScrollView Scroll;
	private LinearLayout BGX;
	private LinearLayout Bg1;
	private LinearLayout Bg2;
	private TextView Tv1;
	private TextView Tv2;
	private TextView Tv5;
	private LinearLayout BOX1;
	private TextView textview4;
	private LinearLayout BOX2;
	private TextView textview5;
	private LinearLayout BOX3;
	private TextView textview6;
	private LinearLayout linear7;
	private TextView textview7;
	private LinearLayout linear9;
	private LinearLayout linear8;
	private LinearLayout linear11;
	private LinearLayout linear12;
	private LinearLayout linear14;
	private LinearLayout Lg_B1;
	private ImageView imageview4;
	private EditText E1;
	private ImageView imageview5;
	private EditText E2;
	private ImageView imageview6;
	private EditText E3;
	private LinearLayout linear6;
	private ImageView show;
	private ImageView hide;
	private CheckBox checkbox1;
	private CheckBox checkbox2;
	private CheckBox chec1;
	private CheckBox chec2;
	private CheckBox chec3;
	private CheckBox chec4;
	private CheckBox chec5;
	private CheckBox chec6;
	private CheckBox chec7;
	private CheckBox chec8;
	private CheckBox chec9;
	private CheckBox chec10;
	private CheckBox chec11;
	private CheckBox chec12;
	private CheckBox chec13;
	private TextView Tv8;
	private ProgressBar prog;
	private LinearLayout linear48;
	private LinearLayout linear49;
	private LinearLayout uPBg;
	private LinearLayout TrxBg;
	private LinearLayout bg1;
	private LinearLayout bg2;
	private TextView tv1;
	private TextView tv2;
	private LinearLayout div1;
	private LinearLayout div2;
	private TextView textview8;
	private TextView textview9;
	private TextView textview34;
	private CardView cardview2;
	private TextView textview14;
	private LinearLayout linear20;
	private LinearLayout linear21;
	private LinearLayout linear22;
	private LinearLayout linear23;
	private LinearLayout linear24;
	private LinearLayout linear37;
	private LinearLayout linear10;
	private LinearLayout linear25;
	private LinearLayout linear26;
	private LinearLayout linear13;
	private LinearLayout linear27;
	private LinearLayout linear15;
	private LinearLayout linear38;
	private LinearLayout linear45;
	private LinearLayout linear46;
	private LinearLayout linear39;
	private LinearLayout linear40;
	private LinearLayout linear43;
	private ImageView imageview2;
	private TextView textview2;
	private TextView idTv;
	private ImageView imageview3;
	private ImageView imageview9;
	private TextView textview15;
	private TextView usernameTv;
	private ImageView imageview10;
	private TextView textview16;
	private TextView emailTv;
	private ImageView imageview30;
	private TextView textview33;
	private TextView roleTv;
	private ImageView imageview13;
	private TextView textview12;
	private TextView statusTv;
	private ImageView imageview28;
	private TextView textview28;
	private TextView dateTv;
	private CheckBox uchec1;
	private CheckBox uchec2;
	private CheckBox uchec3;
	private CheckBox uchec4;
	private CheckBox uchec5;
	private CheckBox uchec6;
	private CheckBox uchec7;
	private CheckBox uchec8;
	private CheckBox uchec9;
	private CheckBox uchec10;
	private CheckBox uchec11;
	private CheckBox uchec12;
	private CheckBox uchec13;
	private LinearLayout banBg;
	private LinearLayout notificationBg;
	private ImageView banImg;
	private TextView banTv;
	private ProgressBar prog2;
	private TextView textview30;
	private TextView textview1;
	private RecyclerView TrxView;
	
	private RequestNetwork Admin;
	private RequestNetwork.RequestListener _Admin_request_listener;
	private SharedPreferences Auth;
	private SharedPreferences app_infos;
	private SharedPreferences Finish;
	private TimerTask Time;
	private RequestNetwork AdminsData;
	private RequestNetwork.RequestListener _AdminsData_request_listener;
	private RequestNetwork Update;
	private RequestNetwork.RequestListener _Update_request_listener;
	private RequestNetwork Status;
	private RequestNetwork.RequestListener _Status_request_listener;
	private RequestNetwork Admin_Txn;
	private RequestNetwork.RequestListener _Admin_Txn_request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.pranto_admin_details);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		BG = findViewById(R.id.BG);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		imageview1 = findViewById(R.id.imageview1);
		textview3 = findViewById(R.id.textview3);
		Scroll = findViewById(R.id.Scroll);
		BGX = findViewById(R.id.BGX);
		Bg1 = findViewById(R.id.Bg1);
		Bg2 = findViewById(R.id.Bg2);
		Tv1 = findViewById(R.id.Tv1);
		Tv2 = findViewById(R.id.Tv2);
		Tv5 = findViewById(R.id.Tv5);
		BOX1 = findViewById(R.id.BOX1);
		textview4 = findViewById(R.id.textview4);
		BOX2 = findViewById(R.id.BOX2);
		textview5 = findViewById(R.id.textview5);
		BOX3 = findViewById(R.id.BOX3);
		textview6 = findViewById(R.id.textview6);
		linear7 = findViewById(R.id.linear7);
		textview7 = findViewById(R.id.textview7);
		linear9 = findViewById(R.id.linear9);
		linear8 = findViewById(R.id.linear8);
		linear11 = findViewById(R.id.linear11);
		linear12 = findViewById(R.id.linear12);
		linear14 = findViewById(R.id.linear14);
		Lg_B1 = findViewById(R.id.Lg_B1);
		imageview4 = findViewById(R.id.imageview4);
		E1 = findViewById(R.id.E1);
		imageview5 = findViewById(R.id.imageview5);
		E2 = findViewById(R.id.E2);
		imageview6 = findViewById(R.id.imageview6);
		E3 = findViewById(R.id.E3);
		linear6 = findViewById(R.id.linear6);
		show = findViewById(R.id.show);
		hide = findViewById(R.id.hide);
		checkbox1 = findViewById(R.id.checkbox1);
		checkbox2 = findViewById(R.id.checkbox2);
		chec1 = findViewById(R.id.chec1);
		chec2 = findViewById(R.id.chec2);
		chec3 = findViewById(R.id.chec3);
		chec4 = findViewById(R.id.chec4);
		chec5 = findViewById(R.id.chec5);
		chec6 = findViewById(R.id.chec6);
		chec7 = findViewById(R.id.chec7);
		chec8 = findViewById(R.id.chec8);
		chec9 = findViewById(R.id.chec9);
		chec10 = findViewById(R.id.chec10);
		chec11 = findViewById(R.id.chec11);
		chec12 = findViewById(R.id.chec12);
		chec13 = findViewById(R.id.chec13);
		Tv8 = findViewById(R.id.Tv8);
		prog = findViewById(R.id.prog);
		linear48 = findViewById(R.id.linear48);
		linear49 = findViewById(R.id.linear49);
		uPBg = findViewById(R.id.uPBg);
		TrxBg = findViewById(R.id.TrxBg);
		bg1 = findViewById(R.id.bg1);
		bg2 = findViewById(R.id.bg2);
		tv1 = findViewById(R.id.tv1);
		tv2 = findViewById(R.id.tv2);
		div1 = findViewById(R.id.div1);
		div2 = findViewById(R.id.div2);
		textview8 = findViewById(R.id.textview8);
		textview9 = findViewById(R.id.textview9);
		textview34 = findViewById(R.id.textview34);
		cardview2 = findViewById(R.id.cardview2);
		textview14 = findViewById(R.id.textview14);
		linear20 = findViewById(R.id.linear20);
		linear21 = findViewById(R.id.linear21);
		linear22 = findViewById(R.id.linear22);
		linear23 = findViewById(R.id.linear23);
		linear24 = findViewById(R.id.linear24);
		linear37 = findViewById(R.id.linear37);
		linear10 = findViewById(R.id.linear10);
		linear25 = findViewById(R.id.linear25);
		linear26 = findViewById(R.id.linear26);
		linear13 = findViewById(R.id.linear13);
		linear27 = findViewById(R.id.linear27);
		linear15 = findViewById(R.id.linear15);
		linear38 = findViewById(R.id.linear38);
		linear45 = findViewById(R.id.linear45);
		linear46 = findViewById(R.id.linear46);
		linear39 = findViewById(R.id.linear39);
		linear40 = findViewById(R.id.linear40);
		linear43 = findViewById(R.id.linear43);
		imageview2 = findViewById(R.id.imageview2);
		textview2 = findViewById(R.id.textview2);
		idTv = findViewById(R.id.idTv);
		imageview3 = findViewById(R.id.imageview3);
		imageview9 = findViewById(R.id.imageview9);
		textview15 = findViewById(R.id.textview15);
		usernameTv = findViewById(R.id.usernameTv);
		imageview10 = findViewById(R.id.imageview10);
		textview16 = findViewById(R.id.textview16);
		emailTv = findViewById(R.id.emailTv);
		imageview30 = findViewById(R.id.imageview30);
		textview33 = findViewById(R.id.textview33);
		roleTv = findViewById(R.id.roleTv);
		imageview13 = findViewById(R.id.imageview13);
		textview12 = findViewById(R.id.textview12);
		statusTv = findViewById(R.id.statusTv);
		imageview28 = findViewById(R.id.imageview28);
		textview28 = findViewById(R.id.textview28);
		dateTv = findViewById(R.id.dateTv);
		uchec1 = findViewById(R.id.uchec1);
		uchec2 = findViewById(R.id.uchec2);
		uchec3 = findViewById(R.id.uchec3);
		uchec4 = findViewById(R.id.uchec4);
		uchec5 = findViewById(R.id.uchec5);
		uchec6 = findViewById(R.id.uchec6);
		uchec7 = findViewById(R.id.uchec7);
		uchec8 = findViewById(R.id.uchec8);
		uchec9 = findViewById(R.id.uchec9);
		uchec10 = findViewById(R.id.uchec10);
		uchec11 = findViewById(R.id.uchec11);
		uchec12 = findViewById(R.id.uchec12);
		uchec13 = findViewById(R.id.uchec13);
		banBg = findViewById(R.id.banBg);
		notificationBg = findViewById(R.id.notificationBg);
		banImg = findViewById(R.id.banImg);
		banTv = findViewById(R.id.banTv);
		prog2 = findViewById(R.id.prog2);
		textview30 = findViewById(R.id.textview30);
		textview1 = findViewById(R.id.textview1);
		TrxView = findViewById(R.id.TrxView);
		Admin = new RequestNetwork(this);
		Auth = getSharedPreferences("Auth", Activity.MODE_PRIVATE);
		app_infos = getSharedPreferences("app_infos", Activity.MODE_PRIVATE);
		Finish = getSharedPreferences("Finish", Activity.MODE_PRIVATE);
		AdminsData = new RequestNetwork(this);
		Update = new RequestNetwork(this);
		Status = new RequestNetwork(this);
		Admin_Txn = new RequestNetwork(this);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
				overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
			}
		});
		
		Lg_B1.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				_clickAnimation(Lg_B1);
				return true;
			}
		});
		
		Lg_B1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_clickAnimation(Lg_B1);
				if (!E1.getText().toString().equals("")) {
					if (!E2.getText().toString().equals("")) {
						if (!E3.getText().toString().equals("")) {
							if (!Role.equals("")) {
								prog.setVisibility(View.VISIBLE);
								Tv8.setVisibility(View.GONE);
								if (vpn()) {
								} else {
									IM_PRANTO = new HashMap<>();
									admin = new HashMap<>();
									admin.put("type", "add");
									admin.put("username", E1.getText().toString());
									admin.put("new_email", E2.getText().toString());
									admin.put("password", E3.getText().toString());
									admin.put("role", Role);
									admin.put("permission", p1.concat(",".concat(p2.concat(",".concat(p3.concat(",".concat(p4.concat(",".concat(p5.concat(",".concat(p6.concat(",".concat(p7.concat(",".concat(p8.concat(",".concat(p9.concat(",".concat(p10.concat(",".concat(p11.concat(",".concat(p12.concat(",".concat(p13)))))))))))))))))))))))));
									admin.put("email", Auth.getString("Email", ""));
									admin.put("session_id", Auth.getString("Session_id", ""));
									IM_PRANTO.put("X-IM-PRANTO", (new Object() {
										   int t;
										   public String toString() {
											      byte[] buf = new byte[22];
											      t = 5242880;
											      buf[0] = (byte) (t >>> 16);
											      t = 116736;
											      buf[1] = (byte) (t >>> 10);
											      t = 12713984;
											      buf[2] = (byte) (t >>> 17);
											      t = 28835840;
											      buf[3] = (byte) (t >>> 18);
											      t = 30408704;
											      buf[4] = (byte) (t >>> 18);
											      t = 56832;
											      buf[5] = (byte) (t >>> 9);
											      t = 3112960;
											      buf[6] = (byte) (t >>> 15);
											      t = 104857600;
											      buf[7] = (byte) (t >>> 21);
											      t = 100663296;
											      buf[8] = (byte) (t >>> 21);
											      t = 6291456;
											      buf[9] = (byte) (t >>> 17);
											      t = 230686720;
											      buf[10] = (byte) (t >>> 22);
											      t = 24320;
											      buf[11] = (byte) (t >>> 8);
											      t = 4928;
											      buf[12] = (byte) (t >>> 6);
											      t = 199229440;
											      buf[13] = (byte) (t >>> 21);
											      t = 1359872;
											      buf[14] = (byte) (t >>> 14);
											      t = 105906176;
											      buf[15] = (byte) (t >>> 20);
											      t = 25952256;
											      buf[16] = (byte) (t >>> 18);
											      t = 245366784;
											      buf[17] = (byte) (t >>> 21);
											      t = 478150656;
											      buf[18] = (byte) (t >>> 22);
											      t = 880803840;
											      buf[19] = (byte) (t >>> 23);
											      t = 14848;
											      buf[20] = (byte) (t >>> 7);
											      t = 7929856;
											      buf[21] = (byte) (t >>> 16);
											      return new String(buf);
											   }
									}.toString()));
									Admin.setHeaders(IM_PRANTO);
									Admin.setParams(admin, RequestNetworkController.REQUEST_PARAM);
									Admin.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("admins.php"), "", _Admin_request_listener);
									admin.clear();
									IM_PRANTO.clear();
								}
							} else {
								CustomToast.show(findViewById(android.R.id.content), "Please select role", CustomToast.TYPE_ERROR, R.font.font3);
							}
						} else {
							CustomToast.show(findViewById(android.R.id.content), "Please fill in all fields", CustomToast.TYPE_ERROR, R.font.font3);
						}
					} else {
						CustomToast.show(findViewById(android.R.id.content), "Please fill in all fields", CustomToast.TYPE_ERROR, R.font.font3);
					}
				} else {
					CustomToast.show(findViewById(android.R.id.content), "Please fill in all fields", CustomToast.TYPE_ERROR, R.font.font3);
				}
			}
		});
		
		show.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				show.setVisibility(View.GONE);
				hide.setVisibility(View.VISIBLE);
				E3.setTransformationMethod(android.text.method.HideReturnsTransformationMethod.getInstance());
			}
		});
		
		hide.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				hide.setVisibility(View.GONE);
				show.setVisibility(View.VISIBLE);
				E3.setTransformationMethod(android.text.method.PasswordTransformationMethod.getInstance());
			}
		});
		
		checkbox1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					checkbox1.setChecked(true);
					checkbox2.setChecked(false);
					Role = "Admin";
				} else {
					checkbox1.setChecked(false);
					checkbox2.setChecked(false);
					Role = "";
				}
			}
		});
		
		checkbox2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					checkbox1.setChecked(false);
					checkbox2.setChecked(true);
					Role = "Moderator";
				} else {
					checkbox1.setChecked(false);
					checkbox2.setChecked(false);
					Role = "";
				}
			}
		});
		
		chec1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					chec1.setChecked(true);
					p1 = "users";
				} else {
					chec1.setChecked(false);
					p1 = "";
				}
			}
		});
		
		chec2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					chec2.setChecked(true);
					p2 = "deposit";
				} else {
					chec2.setChecked(false);
					p2 = "";
				}
			}
		});
		
		chec3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					chec3.setChecked(true);
					p3 = "withdraw";
				} else {
					chec3.setChecked(false);
					p3 = "";
				}
			}
		});
		
		chec4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					chec4.setChecked(true);
					p4 = "category";
				} else {
					chec4.setChecked(false);
					p4 = "";
				}
			}
		});
		
		chec5.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					chec5.setChecked(true);
					p5 = "push_notification";
				} else {
					chec5.setChecked(false);
					p5 = "";
				}
			}
		});
		
		chec6.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					chec6.setChecked(true);
					p6 = "slider";
				} else {
					chec6.setChecked(false);
					p6 = "";
				}
			}
		});
		
		chec7.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					chec7.setChecked(true);
					p7 = "setting";
				} else {
					chec7.setChecked(false);
					p7 = "";
				}
			}
		});
		
		chec8.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					chec8.setChecked(true);
					p8 = "app_admin";
				} else {
					chec8.setChecked(false);
					p8 = "";
				}
			}
		});
		
		chec9.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					chec9.setChecked(true);
					p9 = "admin_transaction";
				} else {
					chec9.setChecked(false);
					p9 = "";
				}
			}
		});
		
		chec10.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					chec10.setChecked(true);
					p10 = "device";
				} else {
					chec10.setChecked(false);
					p10 = "";
				}
			}
		});
		
		chec11.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					chec11.setChecked(true);
					p11 = "winning";
				} else {
					chec11.setChecked(false);
					p11 = "";
				}
			}
		});
		
		chec12.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					chec12.setChecked(true);
					p12 = "refund";
				} else {
					chec12.setChecked(false);
					p12 = "";
				}
			}
		});
		
		chec13.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					chec13.setChecked(true);
					p13 = "Match";
				} else {
					chec13.setChecked(false);
					p13 = "";
				}
			}
		});
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", idTv.getText().toString()));
				CustomToast.show(findViewById(android.R.id.content), "Admin id copied to clipboard", CustomToast.TYPE_SUCCESS, R.font.font3);
			}
		});
		
		uchec1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					uchec1.setChecked(true);
					up1 = "users";
				} else {
					uchec1.setChecked(false);
					up1 = "";
				}
			}
		});
		
		uchec2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					uchec2.setChecked(true);
					up2 = "deposit";
				} else {
					uchec2.setChecked(false);
					up2 = "";
				}
			}
		});
		
		uchec3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					uchec3.setChecked(true);
					up3 = "withdraw";
				} else {
					uchec3.setChecked(false);
					up3 = "";
				}
			}
		});
		
		uchec4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					uchec4.setChecked(true);
					up4 = "category";
				} else {
					uchec4.setChecked(false);
					up4 = "";
				}
			}
		});
		
		uchec5.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					uchec5.setChecked(true);
					up5 = "push_notification";
				} else {
					uchec5.setChecked(false);
					up5 = "";
				}
			}
		});
		
		uchec6.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					uchec6.setChecked(true);
					up6 = "slider";
				} else {
					uchec6.setChecked(false);
					up6 = "";
				}
			}
		});
		
		uchec7.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					uchec7.setChecked(true);
					up7 = "setting";
				} else {
					uchec7.setChecked(false);
					up7 = "";
				}
			}
		});
		
		uchec8.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					uchec8.setChecked(true);
					up8 = "app_admin";
				} else {
					uchec8.setChecked(false);
					up8 = "";
				}
			}
		});
		
		uchec9.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					uchec9.setChecked(true);
					up9 = "admin_transaction";
				} else {
					uchec9.setChecked(false);
					up9 = "";
				}
			}
		});
		
		uchec10.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					uchec10.setChecked(true);
					up10 = "device";
				} else {
					uchec10.setChecked(false);
					up10 = "";
				}
			}
		});
		
		uchec11.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					uchec11.setChecked(true);
					up11 = "winning";
				} else {
					uchec11.setChecked(false);
					up11 = "";
				}
			}
		});
		
		uchec12.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					uchec12.setChecked(true);
					up12 = "refund";
				} else {
					uchec12.setChecked(false);
					up12 = "";
				}
			}
		});
		
		uchec13.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					uchec13.setChecked(true);
					up13 = "Match";
				} else {
					uchec13.setChecked(false);
					up13 = "";
				}
			}
		});
		
		banBg.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				_clickAnimation(banBg);
				return true;
			}
		});
		
		notificationBg.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				_clickAnimation(notificationBg);
				return true;
			}
		});
		
		notificationBg.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_clickAnimation(notificationBg);
				prog2.setVisibility(View.VISIBLE);
				textview30.setVisibility(View.GONE);
				if (vpn()) {
				} else {
					IM_PRANTO = new HashMap<>();
					update = new HashMap<>();
					update.put("type", "update");
					update.put("id", getIntent().getStringExtra("Id"));
					update.put("permission", up1.concat(",".concat(up2.concat(",".concat(up3.concat(",".concat(up4.concat(",".concat(up5.concat(",".concat(up6.concat(",".concat(up7.concat(",".concat(up8.concat(",".concat(up9.concat(",".concat(up10.concat(",".concat(up11.concat(",".concat(up12.concat(",".concat(up13)))))))))))))))))))))))));
					update.put("email", Auth.getString("Email", ""));
					update.put("session_id", Auth.getString("Session_id", ""));
					IM_PRANTO.put("X-IM-PRANTO", (new Object() {
						   int t;
						   public String toString() {
							      byte[] buf = new byte[22];
							      t = 5242880;
							      buf[0] = (byte) (t >>> 16);
							      t = 116736;
							      buf[1] = (byte) (t >>> 10);
							      t = 12713984;
							      buf[2] = (byte) (t >>> 17);
							      t = 28835840;
							      buf[3] = (byte) (t >>> 18);
							      t = 30408704;
							      buf[4] = (byte) (t >>> 18);
							      t = 56832;
							      buf[5] = (byte) (t >>> 9);
							      t = 3112960;
							      buf[6] = (byte) (t >>> 15);
							      t = 104857600;
							      buf[7] = (byte) (t >>> 21);
							      t = 100663296;
							      buf[8] = (byte) (t >>> 21);
							      t = 6291456;
							      buf[9] = (byte) (t >>> 17);
							      t = 230686720;
							      buf[10] = (byte) (t >>> 22);
							      t = 24320;
							      buf[11] = (byte) (t >>> 8);
							      t = 4928;
							      buf[12] = (byte) (t >>> 6);
							      t = 199229440;
							      buf[13] = (byte) (t >>> 21);
							      t = 1359872;
							      buf[14] = (byte) (t >>> 14);
							      t = 105906176;
							      buf[15] = (byte) (t >>> 20);
							      t = 25952256;
							      buf[16] = (byte) (t >>> 18);
							      t = 245366784;
							      buf[17] = (byte) (t >>> 21);
							      t = 478150656;
							      buf[18] = (byte) (t >>> 22);
							      t = 880803840;
							      buf[19] = (byte) (t >>> 23);
							      t = 14848;
							      buf[20] = (byte) (t >>> 7);
							      t = 7929856;
							      buf[21] = (byte) (t >>> 16);
							      return new String(buf);
							   }
					}.toString()));
					Update.setHeaders(IM_PRANTO);
					Update.setParams(update, RequestNetworkController.REQUEST_PARAM);
					Update.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("admins.php"), "", _Update_request_listener);
					update.clear();
					IM_PRANTO.clear();
				}
			}
		});
		
		_Admin_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				Tv8.setVisibility(View.VISIBLE);
				prog.setVisibility(View.GONE);
				try{
					addResponse.clear();
					addResponse = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
					if (addResponse.get("status").toString().equals("success")) {
						Finish.edit().putString("Add", "YES").commit();
						CustomToast.show(findViewById(android.R.id.content), "New administer add successful", CustomToast.TYPE_SUCCESS, R.font.font3);
						Time = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										finish();
										overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
									}
								});
							}
						};
						_timer.schedule(Time, (int)(1000));
					} else {
						CustomToast.show(findViewById(android.R.id.content),addResponse.get("message").toString(),CustomToast.TYPE_ERROR,R.font.font3);
					}
				}catch(Exception e){
					 
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_AdminsData_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				try{
					dataResponse.clear();
					dataResponse = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
					idTv.setText("#".concat(String.valueOf((long)(Double.parseDouble(dataResponse.get("id").toString())))));
					usernameTv.setText(dataResponse.get("username").toString());
					emailTv.setText(dataResponse.get("email").toString());
					dateTv.setText(dataResponse.get("date").toString());
					roleTv.setText(dataResponse.get("role").toString());
					if (String.valueOf((long)(Double.parseDouble(dataResponse.get("status").toString()))).equals("0")) {
						statusTv.setText("Active");
						statusTv.setTextColor(0xFF4CAF50);
						statusTv.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFF4CAF50, 0x334CAF50));
						banBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)30, (int)3, 0xFFF44336, 0xFF000000));
						banTv.setText("Ban");
						banTv.setTextColor(0xFFF44336);
						banImg.setImageResource(R.drawable.icon_block_round);
						banBg.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View _view) {
								if (vpn()) {
								} else {
									_clickAnimation(banBg);
									CustomLoading.show(PrantoAdminDetailsActivity.this);
									IM_PRANTO = new HashMap<>();
									update = new HashMap<>();
									update.put("type", "status");
									update.put("id", getIntent().getStringExtra("Id"));
									update.put("status", "1");
									update.put("email", Auth.getString("Email", ""));
									update.put("session_id", Auth.getString("Session_id", ""));
									IM_PRANTO.put("X-IM-PRANTO", (new Object() {
										   int t;
										   public String toString() {
											      byte[] buf = new byte[22];
											      t = 5242880;
											      buf[0] = (byte) (t >>> 16);
											      t = 116736;
											      buf[1] = (byte) (t >>> 10);
											      t = 12713984;
											      buf[2] = (byte) (t >>> 17);
											      t = 28835840;
											      buf[3] = (byte) (t >>> 18);
											      t = 30408704;
											      buf[4] = (byte) (t >>> 18);
											      t = 56832;
											      buf[5] = (byte) (t >>> 9);
											      t = 3112960;
											      buf[6] = (byte) (t >>> 15);
											      t = 104857600;
											      buf[7] = (byte) (t >>> 21);
											      t = 100663296;
											      buf[8] = (byte) (t >>> 21);
											      t = 6291456;
											      buf[9] = (byte) (t >>> 17);
											      t = 230686720;
											      buf[10] = (byte) (t >>> 22);
											      t = 24320;
											      buf[11] = (byte) (t >>> 8);
											      t = 4928;
											      buf[12] = (byte) (t >>> 6);
											      t = 199229440;
											      buf[13] = (byte) (t >>> 21);
											      t = 1359872;
											      buf[14] = (byte) (t >>> 14);
											      t = 105906176;
											      buf[15] = (byte) (t >>> 20);
											      t = 25952256;
											      buf[16] = (byte) (t >>> 18);
											      t = 245366784;
											      buf[17] = (byte) (t >>> 21);
											      t = 478150656;
											      buf[18] = (byte) (t >>> 22);
											      t = 880803840;
											      buf[19] = (byte) (t >>> 23);
											      t = 14848;
											      buf[20] = (byte) (t >>> 7);
											      t = 7929856;
											      buf[21] = (byte) (t >>> 16);
											      return new String(buf);
											   }
									}.toString()));
									Status.setHeaders(IM_PRANTO);
									Status.setParams(update, RequestNetworkController.REQUEST_PARAM);
									Status.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("admins.php"), "", _Status_request_listener);
									update.clear();
									IM_PRANTO.clear();
								}
							}
						});
					} else {
						statusTv.setText("Ban");
						statusTv.setTextColor(0xFFF44336);
						statusTv.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFFF44336, 0x33F44336));
						banBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)30, (int)3, 0xFF4CAF50, 0xFF000000));
						banTv.setText("Unban");
						banTv.setTextColor(0xFF4CAF50);
						banImg.setImageResource(R.drawable.icon_check_circle);
						banBg.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View _view) {
								if (vpn()) {
								} else {
									_clickAnimation(banBg);
									CustomLoading.show(PrantoAdminDetailsActivity.this);
									IM_PRANTO = new HashMap<>();
									update = new HashMap<>();
									update.put("type", "status");
									update.put("id", getIntent().getStringExtra("Id"));
									update.put("status", "0");
									update.put("email", Auth.getString("Email", ""));
									update.put("session_id", Auth.getString("Session_id", ""));
									IM_PRANTO.put("X-IM-PRANTO", (new Object() {
										   int t;
										   public String toString() {
											      byte[] buf = new byte[22];
											      t = 5242880;
											      buf[0] = (byte) (t >>> 16);
											      t = 116736;
											      buf[1] = (byte) (t >>> 10);
											      t = 12713984;
											      buf[2] = (byte) (t >>> 17);
											      t = 28835840;
											      buf[3] = (byte) (t >>> 18);
											      t = 30408704;
											      buf[4] = (byte) (t >>> 18);
											      t = 56832;
											      buf[5] = (byte) (t >>> 9);
											      t = 3112960;
											      buf[6] = (byte) (t >>> 15);
											      t = 104857600;
											      buf[7] = (byte) (t >>> 21);
											      t = 100663296;
											      buf[8] = (byte) (t >>> 21);
											      t = 6291456;
											      buf[9] = (byte) (t >>> 17);
											      t = 230686720;
											      buf[10] = (byte) (t >>> 22);
											      t = 24320;
											      buf[11] = (byte) (t >>> 8);
											      t = 4928;
											      buf[12] = (byte) (t >>> 6);
											      t = 199229440;
											      buf[13] = (byte) (t >>> 21);
											      t = 1359872;
											      buf[14] = (byte) (t >>> 14);
											      t = 105906176;
											      buf[15] = (byte) (t >>> 20);
											      t = 25952256;
											      buf[16] = (byte) (t >>> 18);
											      t = 245366784;
											      buf[17] = (byte) (t >>> 21);
											      t = 478150656;
											      buf[18] = (byte) (t >>> 22);
											      t = 880803840;
											      buf[19] = (byte) (t >>> 23);
											      t = 14848;
											      buf[20] = (byte) (t >>> 7);
											      t = 7929856;
											      buf[21] = (byte) (t >>> 16);
											      return new String(buf);
											   }
									}.toString()));
									Status.setHeaders(IM_PRANTO);
									Status.setParams(update, RequestNetworkController.REQUEST_PARAM);
									Status.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("admins.php"), "", _Status_request_listener);
									update.clear();
									IM_PRANTO.clear();
								}
							}
						});
					}
					try {
						    String rawPermission = dataResponse.get("permission") != null ? dataResponse.get("permission").toString() : "";
						    
						    java.util.ArrayList<String> permission_list = new Gson().fromJson(
						        rawPermission,
						        new TypeToken<java.util.ArrayList<String>>(){}.getType()
						    );
						
						    if (permission_list != null) {
							        if (permission_list.contains("users")) {
								            uchec1.setChecked(true);
								            up1 = "users";
								        } else {
								            uchec1.setChecked(false);
								            up1 = "";
								        }
							
							        if (permission_list.contains("deposit")) {
								            uchec2.setChecked(true);
								            up2 = "deposit";
								        } else {
								            uchec2.setChecked(false);
								            up2 = "";
								        }
							
							        if (permission_list.contains("withdraw")) {
								            uchec3.setChecked(true);
								            up3 = "withdraw";
								        } else {
								            uchec3.setChecked(false);
								            up3 = "";
								        }
							
							        if (permission_list.contains("category")) {
								            uchec4.setChecked(true);
								            up4 = "category";
								        } else {
								            uchec4.setChecked(false);
								            up4 = "";
								        }
							
							        if (permission_list.contains("push_notification")) {
								            uchec5.setChecked(true);
								            up5 = "push_notification";
								        } else {
								            uchec5.setChecked(false);
								            up5 = "";
								        }
							
							        if (permission_list.contains("slider")) {
								            uchec6.setChecked(true);
								            up6 = "slider";
								        } else {
								            uchec6.setChecked(false);
								            up6 = "";
								        }
							
							        if (permission_list.contains("setting")) {
								            uchec7.setChecked(true);
								            up7 = "setting";
								        } else {
								            uchec7.setChecked(false);
								            up7 = "";
								        }
							
							        if (permission_list.contains("app_admin")) {
								            uchec8.setChecked(true);
								            up8 = "app_admin";
								        } else {
								            uchec8.setChecked(false);
								            up8 = "";
								        }
							
							        if (permission_list.contains("admin_transaction")) {
								            uchec9.setChecked(true);
								            up9 = "admin_transaction";
								        } else {
								            uchec9.setChecked(false);
								            up9 = "";
								        }
							
							        if (permission_list.contains("device")) {
								            uchec10.setChecked(true);
								            up10 = "device";
								        } else {
								            uchec10.setChecked(false);
								            up10 = "";
								        }
							
							        if (permission_list.contains("winning")) {
								            uchec11.setChecked(true);
								            up11 = "winning";
								        } else {
								            uchec11.setChecked(false);
								            up11 = "";
								        }
							
							        if (permission_list.contains("refund")) {
								            uchec12.setChecked(true);
								            up12 = "refund";
								        } else {
								            uchec12.setChecked(false);
								            up12 = "";
								        }
							
							        if (permission_list.contains("Match")) {
								            uchec13.setChecked(true);
								            up13 = "Match";
								        } else {
								            uchec13.setChecked(false);
								            up13 = "";
								        }
							    }
						
					} catch (Exception e) {
						    
					}
					
				}catch(Exception e){
					CustomToast.show(findViewById(android.R.id.content), "Data Fetch Unsuccessfully", CustomToast.TYPE_ERROR, R.font.font2);
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_Update_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				textview30.setVisibility(View.VISIBLE);
				prog2.setVisibility(View.GONE);
				try{
					updateResponse.clear();
					updateResponse = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
					if (updateResponse.get("status").toString().equals("success")) {
						CustomToast.show(findViewById(android.R.id.content), "Administer update successful", CustomToast.TYPE_SUCCESS, R.font.font3);
					} else {
						CustomToast.show(findViewById(android.R.id.content), "Administer update failed", CustomToast.TYPE_ERROR, R.font.font3);
					}
				}catch(Exception e){
					 
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_Status_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				CustomLoading.dismiss();
				try{
					updateResponse.clear();
					updateResponse = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
					if (updateResponse.get("status").toString().equals("success")) {
						if (vpn()) {
						} else {
							IM_PRANTO = new HashMap<>();
							admin = new HashMap<>();
							admin.put("type", "one");
							admin.put("id", getIntent().getStringExtra("Id"));
							admin.put("email", Auth.getString("Email", ""));
							admin.put("session_id", Auth.getString("Session_id", ""));
							IM_PRANTO.put("X-IM-PRANTO", (new Object() {
								   int t;
								   public String toString() {
									      byte[] buf = new byte[22];
									      t = 5242880;
									      buf[0] = (byte) (t >>> 16);
									      t = 116736;
									      buf[1] = (byte) (t >>> 10);
									      t = 12713984;
									      buf[2] = (byte) (t >>> 17);
									      t = 28835840;
									      buf[3] = (byte) (t >>> 18);
									      t = 30408704;
									      buf[4] = (byte) (t >>> 18);
									      t = 56832;
									      buf[5] = (byte) (t >>> 9);
									      t = 3112960;
									      buf[6] = (byte) (t >>> 15);
									      t = 104857600;
									      buf[7] = (byte) (t >>> 21);
									      t = 100663296;
									      buf[8] = (byte) (t >>> 21);
									      t = 6291456;
									      buf[9] = (byte) (t >>> 17);
									      t = 230686720;
									      buf[10] = (byte) (t >>> 22);
									      t = 24320;
									      buf[11] = (byte) (t >>> 8);
									      t = 4928;
									      buf[12] = (byte) (t >>> 6);
									      t = 199229440;
									      buf[13] = (byte) (t >>> 21);
									      t = 1359872;
									      buf[14] = (byte) (t >>> 14);
									      t = 105906176;
									      buf[15] = (byte) (t >>> 20);
									      t = 25952256;
									      buf[16] = (byte) (t >>> 18);
									      t = 245366784;
									      buf[17] = (byte) (t >>> 21);
									      t = 478150656;
									      buf[18] = (byte) (t >>> 22);
									      t = 880803840;
									      buf[19] = (byte) (t >>> 23);
									      t = 14848;
									      buf[20] = (byte) (t >>> 7);
									      t = 7929856;
									      buf[21] = (byte) (t >>> 16);
									      return new String(buf);
									   }
							}.toString()));
							AdminsData.setHeaders(IM_PRANTO);
							AdminsData.setParams(admin, RequestNetworkController.REQUEST_PARAM);
							AdminsData.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("admins.php"), "", _AdminsData_request_listener);
							admin.clear();
							IM_PRANTO.clear();
						}
						CustomToast.show(findViewById(android.R.id.content), "Status update successful", CustomToast.TYPE_SUCCESS, R.font.font3);
					} else {
						CustomToast.show(findViewById(android.R.id.content), "Status update failed", CustomToast.TYPE_ERROR, R.font.font3);
					}
				}catch(Exception e){
					 
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_Admin_Txn_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				mapU1.clear();
				adminTxn.clear();
				try {
					try {
							JSONArray Array1 = new JSONArray(_response);
							for (int Ps1 = 0; Ps1 < Array1.length(); Ps1++) {
									JSONObject PRANTO1 = Array1.getJSONObject(Ps1);
									try { 
								mapU1 = new HashMap<>();
								mapU1.put("id", PRANTO1.getString("id"));
								mapU1.put("title", PRANTO1.getString("title"));
								mapU1.put("description", PRANTO1.getString("description"));
								mapU1.put("date", PRANTO1.getString("date"));
								adminTxn.add(mapU1);
								TrxView.setAdapter(new TrxViewAdapter(adminTxn));
							}catch(Exception ex){ex.printStackTrace();}
							}
					} catch (JSONException e) {
							e.printStackTrace();
					}
				} catch (Exception e) {
					
				}
				if (adminTxn.size() == 0) {
					TrxView.setVisibility(View.GONE);
				} else {
					TrxView.setVisibility(View.VISIBLE);
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
			Window w =PrantoAdminDetailsActivity.this.getWindow();
			w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFF000000);
		}
		Tv8.setVisibility(View.VISIBLE);
		prog.setVisibility(View.GONE);
		textview30.setVisibility(View.VISIBLE);
		prog2.setVisibility(View.GONE);
		BOX1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		BOX2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		BOX3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		Lg_B1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF0D00FF));
		notificationBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF0D00FF));
		show.setVisibility(View.VISIBLE);
		hide.setVisibility(View.GONE);
		if (getIntent().getStringExtra("Type").equals("Add")) {
			textview3.setText("Add Administer");
			Bg1.setVisibility(View.VISIBLE);
			Bg2.setVisibility(View.GONE);
		} else {
			textview3.setText("Update Administer");
			Bg2.setVisibility(View.VISIBLE);
			Bg1.setVisibility(View.GONE);
		}
		TrxView.setLayoutManager(new LinearLayoutManager(this));
		bg1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				int[] colorsCRNDY = { Color.parseColor("#0D00FF"), Color.parseColor("#0D00FF") }; android.graphics.drawable.GradientDrawable CRNDY = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNDY);
				CRNDY.setCornerRadii(new float[]{(int)62,(int)62,(int)62,(int)62,(int)0,(int)0,(int)0,(int)0});
				CRNDY.setStroke((int) 0, Color.parseColor("#000000"));
				div1.setElevation((float) 0);
				div1.setBackground(CRNDY);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				tv1.setTextColor(0xFF0D00FF);
				tv2.setTextColor(0xFF757575);
				div1.setVisibility(View.VISIBLE);
				div2.setVisibility(View.INVISIBLE);
				uPBg.setVisibility(View.VISIBLE);
				TrxBg.setVisibility(View.GONE);
			}
		});
		bg2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				int[] colorsCRNXE = { Color.parseColor("#0D00FF"), Color.parseColor("#0D00FF") }; android.graphics.drawable.GradientDrawable CRNXE = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNXE);
				CRNXE.setCornerRadii(new float[]{(int)62,(int)62,(int)62,(int)62,(int)0,(int)0,(int)0,(int)0});
				CRNXE.setStroke((int) 0, Color.parseColor("#000000"));
				div2.setElevation((float) 0);
				div2.setBackground(CRNXE);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				tv1.setTextColor(0xFF757575);
				tv2.setTextColor(0xFF0D00FF);
				div1.setVisibility(View.INVISIBLE);
				div2.setVisibility(View.VISIBLE);
				TrxBg.setVisibility(View.VISIBLE);
				uPBg.setVisibility(View.GONE);
				if (vpn()) {
				} else {
					IM_PRANTO = new HashMap<>();
					admin = new HashMap<>();
					admin.put("type", "one");
					admin.put("admin_id", getIntent().getStringExtra("Id"));
					admin.put("email", Auth.getString("Email", ""));
					admin.put("session_id", Auth.getString("Session_id", ""));
					IM_PRANTO.put("X-IM-PRANTO", (new Object() {
						   int t;
						   public String toString() {
							      byte[] buf = new byte[22];
							      t = 5242880;
							      buf[0] = (byte) (t >>> 16);
							      t = 116736;
							      buf[1] = (byte) (t >>> 10);
							      t = 12713984;
							      buf[2] = (byte) (t >>> 17);
							      t = 28835840;
							      buf[3] = (byte) (t >>> 18);
							      t = 30408704;
							      buf[4] = (byte) (t >>> 18);
							      t = 56832;
							      buf[5] = (byte) (t >>> 9);
							      t = 3112960;
							      buf[6] = (byte) (t >>> 15);
							      t = 104857600;
							      buf[7] = (byte) (t >>> 21);
							      t = 100663296;
							      buf[8] = (byte) (t >>> 21);
							      t = 6291456;
							      buf[9] = (byte) (t >>> 17);
							      t = 230686720;
							      buf[10] = (byte) (t >>> 22);
							      t = 24320;
							      buf[11] = (byte) (t >>> 8);
							      t = 4928;
							      buf[12] = (byte) (t >>> 6);
							      t = 199229440;
							      buf[13] = (byte) (t >>> 21);
							      t = 1359872;
							      buf[14] = (byte) (t >>> 14);
							      t = 105906176;
							      buf[15] = (byte) (t >>> 20);
							      t = 25952256;
							      buf[16] = (byte) (t >>> 18);
							      t = 245366784;
							      buf[17] = (byte) (t >>> 21);
							      t = 478150656;
							      buf[18] = (byte) (t >>> 22);
							      t = 880803840;
							      buf[19] = (byte) (t >>> 23);
							      t = 14848;
							      buf[20] = (byte) (t >>> 7);
							      t = 7929856;
							      buf[21] = (byte) (t >>> 16);
							      return new String(buf);
							   }
					}.toString()));
					Admin_Txn.setHeaders(IM_PRANTO);
					Admin_Txn.setParams(admin, RequestNetworkController.REQUEST_PARAM);
					Admin_Txn.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("admin_trx.php"), "", _Admin_Txn_request_listener);
					admin.clear();
					IM_PRANTO.clear();
				}
			}
		});
		bg1.performClick();
	}
	
	@Override
	public void onBackPressed() {
		finish();
		overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
	}
	
	@Override
	public void onStart() {
		super.onStart();
		if (getIntent().getStringExtra("Type").equals("Update")) {
			if (vpn()) {
			} else {
				IM_PRANTO = new HashMap<>();
				admin = new HashMap<>();
				admin.put("type", "one");
				admin.put("id", getIntent().getStringExtra("Id"));
				admin.put("email", Auth.getString("Email", ""));
				admin.put("session_id", Auth.getString("Session_id", ""));
				IM_PRANTO.put("X-IM-PRANTO", (new Object() {
					   int t;
					   public String toString() {
						      byte[] buf = new byte[22];
						      t = 5242880;
						      buf[0] = (byte) (t >>> 16);
						      t = 116736;
						      buf[1] = (byte) (t >>> 10);
						      t = 12713984;
						      buf[2] = (byte) (t >>> 17);
						      t = 28835840;
						      buf[3] = (byte) (t >>> 18);
						      t = 30408704;
						      buf[4] = (byte) (t >>> 18);
						      t = 56832;
						      buf[5] = (byte) (t >>> 9);
						      t = 3112960;
						      buf[6] = (byte) (t >>> 15);
						      t = 104857600;
						      buf[7] = (byte) (t >>> 21);
						      t = 100663296;
						      buf[8] = (byte) (t >>> 21);
						      t = 6291456;
						      buf[9] = (byte) (t >>> 17);
						      t = 230686720;
						      buf[10] = (byte) (t >>> 22);
						      t = 24320;
						      buf[11] = (byte) (t >>> 8);
						      t = 4928;
						      buf[12] = (byte) (t >>> 6);
						      t = 199229440;
						      buf[13] = (byte) (t >>> 21);
						      t = 1359872;
						      buf[14] = (byte) (t >>> 14);
						      t = 105906176;
						      buf[15] = (byte) (t >>> 20);
						      t = 25952256;
						      buf[16] = (byte) (t >>> 18);
						      t = 245366784;
						      buf[17] = (byte) (t >>> 21);
						      t = 478150656;
						      buf[18] = (byte) (t >>> 22);
						      t = 880803840;
						      buf[19] = (byte) (t >>> 23);
						      t = 14848;
						      buf[20] = (byte) (t >>> 7);
						      t = 7929856;
						      buf[21] = (byte) (t >>> 16);
						      return new String(buf);
						   }
				}.toString()));
				AdminsData.setHeaders(IM_PRANTO);
				AdminsData.setParams(admin, RequestNetworkController.REQUEST_PARAM);
				AdminsData.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("admins.php"), "", _AdminsData_request_listener);
				admin.clear();
				IM_PRANTO.clear();
			}
		}
	}
	public void _clickAnimation(final View _view) {
		ScaleAnimation clickAnim = new ScaleAnimation(
		    1f, 0.9f,
		    1f, 0.9f,
		    Animation.RELATIVE_TO_SELF, 0.5f,
		    Animation.RELATIVE_TO_SELF, 0.5f
		);
		
		clickAnim.setDuration(100);
		clickAnim.setRepeatCount(1);
		clickAnim.setRepeatMode(Animation.REVERSE);
		clickAnim.setFillAfter(false);
		
		_view.startAnimation(clickAnim);
	}
	
	
	public void _vpn() {
	}
	public boolean vpn() {
		    String iface = "";
		    try {
			        for (java.net.NetworkInterface networkInterface : Collections.list(java.net.NetworkInterface.getNetworkInterfaces())) {
				            if (networkInterface.isUp())
				                iface = networkInterface.getName();
				                Log.d("DEBUG", "IFACE NAME: " + iface);
				            if ( iface.contains("tun") || iface.contains("ppp") || iface.contains("pptp")) {
					                return true;
					            }
				        }
			    } catch (Exception e1) {
			        e1.printStackTrace();
			    }
		
		    return false;
	}
	{
	}
	
	public class TrxViewAdapter extends RecyclerView.Adapter<TrxViewAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public TrxViewAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.admin_trx, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout BG1 = _view.findViewById(R.id.BG1);
			final LinearLayout div = _view.findViewById(R.id.div);
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final TextView descriptionTv = _view.findViewById(R.id.descriptionTv);
			final TextView admin_id = _view.findViewById(R.id.admin_id);
			final TextView dateTv = _view.findViewById(R.id.dateTv);
			final TextView Tv1 = _view.findViewById(R.id.Tv1);
			
			admin_id.setVisibility(View.GONE);
			Tv1.setText(_data.get((int)_position).get("title").toString());
			descriptionTv.setText(_data.get((int)_position).get("description").toString());
			dateTv.setText(_data.get((int)_position).get("date").toString());
			if (_position < (_data.size() - 1)) {
				div.setVisibility(View.VISIBLE);
			} else {
				div.setVisibility(View.GONE);
			}
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}
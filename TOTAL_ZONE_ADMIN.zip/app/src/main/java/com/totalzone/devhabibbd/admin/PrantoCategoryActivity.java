package com.totalzone.devhabibbd.admin;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.bumptech.glide.Glide;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.FirebaseApp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class PrantoCategoryActivity extends AppCompatActivity {
	
	private FloatingActionButton _fab;
	private String Url = "";
	private HashMap<String, Object> IM_PRANTO = new HashMap<>();
	private HashMap<String, Object> category = new HashMap<>();
	private HashMap<String, Object> mapU1 = new HashMap<>();
	private String Status = "";
	private String Type = "";
	private HashMap<String, Object> addResponse = new HashMap<>();
	private String upStatus = "";
	private String upType = "";
	private HashMap<String, Object> updateResponse = new HashMap<>();
	private HashMap<String, Object> deleteResponse = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> categoryList = new ArrayList<>();
	
	private LinearLayout BG;
	private LinearLayout linear3;
	private LinearLayout Bg1;
	private ImageView imageview1;
	private TextView textview3;
	private RecyclerView CategoryView;
	private LinearLayout LiadingBg;
	private ProgressBar prog;
	
	private SharedPreferences Auth;
	private SharedPreferences app_infos;
	private RequestNetwork Category;
	private RequestNetwork.RequestListener _Category_request_listener;
	private AlertDialog D;
	private RequestNetwork Add;
	private RequestNetwork.RequestListener _Add_request_listener;
	private RequestNetwork Update;
	private RequestNetwork.RequestListener _Update_request_listener;
	private RequestNetwork Delete;
	private RequestNetwork.RequestListener _Delete_request_listener;
	private SharedPreferences MATCH_TYPE;
	private Intent New_Activity = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.pranto_category);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_fab = findViewById(R.id._fab);
		BG = findViewById(R.id.BG);
		linear3 = findViewById(R.id.linear3);
		Bg1 = findViewById(R.id.Bg1);
		imageview1 = findViewById(R.id.imageview1);
		textview3 = findViewById(R.id.textview3);
		CategoryView = findViewById(R.id.CategoryView);
		LiadingBg = findViewById(R.id.LiadingBg);
		prog = findViewById(R.id.prog);
		Auth = getSharedPreferences("Auth", Activity.MODE_PRIVATE);
		app_infos = getSharedPreferences("app_infos", Activity.MODE_PRIVATE);
		Category = new RequestNetwork(this);
		Add = new RequestNetwork(this);
		Update = new RequestNetwork(this);
		Delete = new RequestNetwork(this);
		MATCH_TYPE = getSharedPreferences("MATCH_TYPE", Activity.MODE_PRIVATE);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
				overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
			}
		});
		
		_fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				D = new AlertDialog.Builder(PrantoCategoryActivity.this).create();
				LayoutInflater DLI = getLayoutInflater();
				View DCV = (View) DLI.inflate(R.layout.add_category, null);
				D.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
				D.setView(DCV);
				final EditText E1 = (EditText)
				DCV.findViewById(R.id.E1);
				final EditText E2 = (EditText)
				DCV.findViewById(R.id.E2);
				final EditText E3 = (EditText)
				DCV.findViewById(R.id.E3);
				final CheckBox checkbox1 = (CheckBox)
				DCV.findViewById(R.id.checkbox1);
				final CheckBox checkbox2 = (CheckBox)
				DCV.findViewById(R.id.checkbox2);
				final CheckBox check1 = (CheckBox)
				DCV.findViewById(R.id.check1);
				final CheckBox check2 = (CheckBox)
				DCV.findViewById(R.id.check2);
				final CheckBox check3 = (CheckBox)
				DCV.findViewById(R.id.check3);
				final CheckBox check4 = (CheckBox)
				DCV.findViewById(R.id.check4);
				final TextView Done = (TextView)
				DCV.findViewById(R.id.Done);
				E1.setTextIsSelectable(true);
				E2.setTextIsSelectable(true);
				E3.setTextIsSelectable(true);
				E1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
				E2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
				E3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
				Done.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF0D00FF));
				checkbox1.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						Status = "1";
						checkbox1.setChecked(true);
						checkbox2.setChecked(false);
					}
				});
				checkbox2.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						Status = "0";
						checkbox1.setChecked(false);
						checkbox2.setChecked(true);
					}
				});
				check1.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						Type = "BR MATCH";
						check1.setChecked(true);
						check2.setChecked(false);
						check3.setChecked(false);
						check4.setChecked(false);
					}
				});
				check2.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						Type = "SQUAD MATCHES";
						check1.setChecked(false);
						check2.setChecked(true);
						check3.setChecked(false);
						check4.setChecked(false);
					}
				});
				check3.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						Type = "LONE WOLF";
						check1.setChecked(false);
						check2.setChecked(false);
						check3.setChecked(true);
						check4.setChecked(false);
					}
				});
				check4.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						Type = "HEADSHOT MODES";
						check1.setChecked(false);
						check2.setChecked(false);
						check3.setChecked(false);
						check4.setChecked(true);
					}
				});
				Done.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						if (!E1.getText().toString().equals("")) {
							if (!E2.getText().toString().equals("")) {
								if (!E3.getText().toString().equals("")) {
									if (!Status.equals("")) {
										if (!Type.equals("")) {
											D.dismiss();
											if (vpn()) {
											} else {
												CustomLoading.show(PrantoCategoryActivity.this);
												IM_PRANTO = new HashMap<>();
												category = new HashMap<>();
												category.put("type", "add");
												category.put("category_type", Type);
												category.put("title", E1.getText().toString());
												category.put("image_url", E2.getText().toString());
												category.put("rules", E3.getText().toString());
												category.put("status", Status);
												category.put("email", Auth.getString("Email", ""));
												category.put("session_id", Auth.getString("Session_id", ""));
												IM_PRANTO.put("X-IM-PRANTO", (new Object() {
													   int t;
													   public String toString() {
														      byte[] buf = new byte[22];
														      t = 5242880;
														      buf[0] = (byte) (t >>> 16);
														      t = 116736;
														      buf[1] = (byte) (t >>> 10);
														      t = 12713984;
														      buf[2] = (byte) (t >>> 17);
														      t = 28835840;
														      buf[3] = (byte) (t >>> 18);
														      t = 30408704;
														      buf[4] = (byte) (t >>> 18);
														      t = 56832;
														      buf[5] = (byte) (t >>> 9);
														      t = 3112960;
														      buf[6] = (byte) (t >>> 15);
														      t = 104857600;
														      buf[7] = (byte) (t >>> 21);
														      t = 100663296;
														      buf[8] = (byte) (t >>> 21);
														      t = 6291456;
														      buf[9] = (byte) (t >>> 17);
														      t = 230686720;
														      buf[10] = (byte) (t >>> 22);
														      t = 24320;
														      buf[11] = (byte) (t >>> 8);
														      t = 4928;
														      buf[12] = (byte) (t >>> 6);
														      t = 199229440;
														      buf[13] = (byte) (t >>> 21);
														      t = 1359872;
														      buf[14] = (byte) (t >>> 14);
														      t = 105906176;
														      buf[15] = (byte) (t >>> 20);
														      t = 25952256;
														      buf[16] = (byte) (t >>> 18);
														      t = 245366784;
														      buf[17] = (byte) (t >>> 21);
														      t = 478150656;
														      buf[18] = (byte) (t >>> 22);
														      t = 880803840;
														      buf[19] = (byte) (t >>> 23);
														      t = 14848;
														      buf[20] = (byte) (t >>> 7);
														      t = 7929856;
														      buf[21] = (byte) (t >>> 16);
														      return new String(buf);
														   }
												}.toString()));
												Add.setHeaders(IM_PRANTO);
												Add.setParams(category, RequestNetworkController.REQUEST_PARAM);
												Add.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("category.php"), "", _Add_request_listener);
												category.clear();
												IM_PRANTO.clear();
											}
										}
									}
								}
							}
						}
					}
				});
				D.setCancelable(true);
				D.show();
			}
		});
		
		_Category_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				LiadingBg.setVisibility(View.GONE);
				mapU1.clear();
				categoryList.clear();
				try {
					try {
							JSONArray Array1 = new JSONArray(_response);
							for (int Ps1 = 0; Ps1 < Array1.length(); Ps1++) {
									JSONObject PRANTO1 = Array1.getJSONObject(Ps1);
									try { 
								mapU1 = new HashMap<>();
								mapU1.put("id", PRANTO1.getString("id"));
								mapU1.put("type", PRANTO1.getString("type"));
								mapU1.put("title", PRANTO1.getString("title"));
								mapU1.put("image_url", PRANTO1.getString("image_url"));
								mapU1.put("rules", PRANTO1.getString("rules"));
								mapU1.put("status", PRANTO1.getString("status"));
								categoryList.add(mapU1);
								CategoryView.setAdapter(new CategoryViewAdapter(categoryList));
							}catch(Exception ex){ex.printStackTrace();}
							}
					} catch (JSONException e) {
							e.printStackTrace();
					}
				} catch (Exception e) {
					
				}
				if (categoryList.size() == 0) {
					CategoryView.setVisibility(View.GONE);
				} else {
					CategoryView.setVisibility(View.VISIBLE);
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_Add_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				CustomLoading.dismiss();
				try{
					addResponse.clear();
					addResponse = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
					if (addResponse.get("status").toString().equals("success")) {
						if (vpn()) {
						} else {
							IM_PRANTO = new HashMap<>();
							category = new HashMap<>();
							category.put("type", "all");
							category.put("email", Auth.getString("Email", ""));
							category.put("session_id", Auth.getString("Session_id", ""));
							IM_PRANTO.put("X-IM-PRANTO", (new Object() {
								   int t;
								   public String toString() {
									      byte[] buf = new byte[22];
									      t = 5242880;
									      buf[0] = (byte) (t >>> 16);
									      t = 116736;
									      buf[1] = (byte) (t >>> 10);
									      t = 12713984;
									      buf[2] = (byte) (t >>> 17);
									      t = 28835840;
									      buf[3] = (byte) (t >>> 18);
									      t = 30408704;
									      buf[4] = (byte) (t >>> 18);
									      t = 56832;
									      buf[5] = (byte) (t >>> 9);
									      t = 3112960;
									      buf[6] = (byte) (t >>> 15);
									      t = 104857600;
									      buf[7] = (byte) (t >>> 21);
									      t = 100663296;
									      buf[8] = (byte) (t >>> 21);
									      t = 6291456;
									      buf[9] = (byte) (t >>> 17);
									      t = 230686720;
									      buf[10] = (byte) (t >>> 22);
									      t = 24320;
									      buf[11] = (byte) (t >>> 8);
									      t = 4928;
									      buf[12] = (byte) (t >>> 6);
									      t = 199229440;
									      buf[13] = (byte) (t >>> 21);
									      t = 1359872;
									      buf[14] = (byte) (t >>> 14);
									      t = 105906176;
									      buf[15] = (byte) (t >>> 20);
									      t = 25952256;
									      buf[16] = (byte) (t >>> 18);
									      t = 245366784;
									      buf[17] = (byte) (t >>> 21);
									      t = 478150656;
									      buf[18] = (byte) (t >>> 22);
									      t = 880803840;
									      buf[19] = (byte) (t >>> 23);
									      t = 14848;
									      buf[20] = (byte) (t >>> 7);
									      t = 7929856;
									      buf[21] = (byte) (t >>> 16);
									      return new String(buf);
									   }
							}.toString()));
							Category.setHeaders(IM_PRANTO);
							Category.setParams(category, RequestNetworkController.REQUEST_PARAM);
							Category.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("category.php"), "", _Category_request_listener);
							category.clear();
							IM_PRANTO.clear();
						}
						CustomToast.show(findViewById(android.R.id.content), "Category add successful", CustomToast.TYPE_SUCCESS, R.font.font3);
					} else {
						CustomToast.show(findViewById(android.R.id.content), "Category add failed", CustomToast.TYPE_ERROR, R.font.font3);
					}
				}catch(Exception e){
					 
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_Update_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				CustomLoading.dismiss();
				try{
					updateResponse.clear();
					updateResponse = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
					if (updateResponse.get("status").toString().equals("success")) {
						if (vpn()) {
						} else {
							IM_PRANTO = new HashMap<>();
							category = new HashMap<>();
							category.put("type", "all");
							category.put("email", Auth.getString("Email", ""));
							category.put("session_id", Auth.getString("Session_id", ""));
							IM_PRANTO.put("X-IM-PRANTO", (new Object() {
								   int t;
								   public String toString() {
									      byte[] buf = new byte[22];
									      t = 5242880;
									      buf[0] = (byte) (t >>> 16);
									      t = 116736;
									      buf[1] = (byte) (t >>> 10);
									      t = 12713984;
									      buf[2] = (byte) (t >>> 17);
									      t = 28835840;
									      buf[3] = (byte) (t >>> 18);
									      t = 30408704;
									      buf[4] = (byte) (t >>> 18);
									      t = 56832;
									      buf[5] = (byte) (t >>> 9);
									      t = 3112960;
									      buf[6] = (byte) (t >>> 15);
									      t = 104857600;
									      buf[7] = (byte) (t >>> 21);
									      t = 100663296;
									      buf[8] = (byte) (t >>> 21);
									      t = 6291456;
									      buf[9] = (byte) (t >>> 17);
									      t = 230686720;
									      buf[10] = (byte) (t >>> 22);
									      t = 24320;
									      buf[11] = (byte) (t >>> 8);
									      t = 4928;
									      buf[12] = (byte) (t >>> 6);
									      t = 199229440;
									      buf[13] = (byte) (t >>> 21);
									      t = 1359872;
									      buf[14] = (byte) (t >>> 14);
									      t = 105906176;
									      buf[15] = (byte) (t >>> 20);
									      t = 25952256;
									      buf[16] = (byte) (t >>> 18);
									      t = 245366784;
									      buf[17] = (byte) (t >>> 21);
									      t = 478150656;
									      buf[18] = (byte) (t >>> 22);
									      t = 880803840;
									      buf[19] = (byte) (t >>> 23);
									      t = 14848;
									      buf[20] = (byte) (t >>> 7);
									      t = 7929856;
									      buf[21] = (byte) (t >>> 16);
									      return new String(buf);
									   }
							}.toString()));
							Category.setHeaders(IM_PRANTO);
							Category.setParams(category, RequestNetworkController.REQUEST_PARAM);
							Category.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("category.php"), "", _Category_request_listener);
							category.clear();
							IM_PRANTO.clear();
						}
						CustomToast.show(findViewById(android.R.id.content), "Category update successful", CustomToast.TYPE_SUCCESS, R.font.font3);
					} else {
						CustomToast.show(findViewById(android.R.id.content), "Category update failed", CustomToast.TYPE_ERROR, R.font.font3);
					}
				}catch(Exception e){
					 
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_Delete_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				CustomLoading.dismiss();
				try{
					deleteResponse.clear();
					deleteResponse = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
					if (deleteResponse.get("status").toString().equals("success")) {
						CustomToast.show(findViewById(android.R.id.content), "Category delete successful", CustomToast.TYPE_SUCCESS, R.font.font2);
						if (vpn()) {
						} else {
							IM_PRANTO = new HashMap<>();
							category = new HashMap<>();
							category.put("type", "all");
							category.put("email", Auth.getString("Email", ""));
							category.put("session_id", Auth.getString("Session_id", ""));
							IM_PRANTO.put("X-IM-PRANTO", (new Object() {
								   int t;
								   public String toString() {
									      byte[] buf = new byte[22];
									      t = 5242880;
									      buf[0] = (byte) (t >>> 16);
									      t = 116736;
									      buf[1] = (byte) (t >>> 10);
									      t = 12713984;
									      buf[2] = (byte) (t >>> 17);
									      t = 28835840;
									      buf[3] = (byte) (t >>> 18);
									      t = 30408704;
									      buf[4] = (byte) (t >>> 18);
									      t = 56832;
									      buf[5] = (byte) (t >>> 9);
									      t = 3112960;
									      buf[6] = (byte) (t >>> 15);
									      t = 104857600;
									      buf[7] = (byte) (t >>> 21);
									      t = 100663296;
									      buf[8] = (byte) (t >>> 21);
									      t = 6291456;
									      buf[9] = (byte) (t >>> 17);
									      t = 230686720;
									      buf[10] = (byte) (t >>> 22);
									      t = 24320;
									      buf[11] = (byte) (t >>> 8);
									      t = 4928;
									      buf[12] = (byte) (t >>> 6);
									      t = 199229440;
									      buf[13] = (byte) (t >>> 21);
									      t = 1359872;
									      buf[14] = (byte) (t >>> 14);
									      t = 105906176;
									      buf[15] = (byte) (t >>> 20);
									      t = 25952256;
									      buf[16] = (byte) (t >>> 18);
									      t = 245366784;
									      buf[17] = (byte) (t >>> 21);
									      t = 478150656;
									      buf[18] = (byte) (t >>> 22);
									      t = 880803840;
									      buf[19] = (byte) (t >>> 23);
									      t = 14848;
									      buf[20] = (byte) (t >>> 7);
									      t = 7929856;
									      buf[21] = (byte) (t >>> 16);
									      return new String(buf);
									   }
							}.toString()));
							Category.setHeaders(IM_PRANTO);
							Category.setParams(category, RequestNetworkController.REQUEST_PARAM);
							Category.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("category.php"), "", _Category_request_listener);
							category.clear();
							IM_PRANTO.clear();
						}
					} else {
						CustomToast.show(findViewById(android.R.id.content), "Category delete failed", CustomToast.TYPE_ERROR, R.font.font3);
					}
				}catch(Exception e){
					 
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
			Window w =PrantoCategoryActivity.this.getWindow();
			w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFF000000);
		}
		CategoryView.setLayoutManager(new LinearLayoutManager(this));
		LiadingBg.setVisibility(View.VISIBLE);
		CategoryView.setVisibility(View.GONE);
		new java.util.Timer().schedule(new java.util.TimerTask() {
			    @Override
			    public void run() {
				        
				if (vpn()) {
				} else {
					IM_PRANTO = new HashMap<>();
					category = new HashMap<>();
					category.put("type", "all");
					category.put("email", Auth.getString("Email", ""));
					category.put("session_id", Auth.getString("Session_id", ""));
					IM_PRANTO.put("X-IM-PRANTO", (new Object() {
						   int t;
						   public String toString() {
							      byte[] buf = new byte[22];
							      t = 5242880;
							      buf[0] = (byte) (t >>> 16);
							      t = 116736;
							      buf[1] = (byte) (t >>> 10);
							      t = 12713984;
							      buf[2] = (byte) (t >>> 17);
							      t = 28835840;
							      buf[3] = (byte) (t >>> 18);
							      t = 30408704;
							      buf[4] = (byte) (t >>> 18);
							      t = 56832;
							      buf[5] = (byte) (t >>> 9);
							      t = 3112960;
							      buf[6] = (byte) (t >>> 15);
							      t = 104857600;
							      buf[7] = (byte) (t >>> 21);
							      t = 100663296;
							      buf[8] = (byte) (t >>> 21);
							      t = 6291456;
							      buf[9] = (byte) (t >>> 17);
							      t = 230686720;
							      buf[10] = (byte) (t >>> 22);
							      t = 24320;
							      buf[11] = (byte) (t >>> 8);
							      t = 4928;
							      buf[12] = (byte) (t >>> 6);
							      t = 199229440;
							      buf[13] = (byte) (t >>> 21);
							      t = 1359872;
							      buf[14] = (byte) (t >>> 14);
							      t = 105906176;
							      buf[15] = (byte) (t >>> 20);
							      t = 25952256;
							      buf[16] = (byte) (t >>> 18);
							      t = 245366784;
							      buf[17] = (byte) (t >>> 21);
							      t = 478150656;
							      buf[18] = (byte) (t >>> 22);
							      t = 880803840;
							      buf[19] = (byte) (t >>> 23);
							      t = 14848;
							      buf[20] = (byte) (t >>> 7);
							      t = 7929856;
							      buf[21] = (byte) (t >>> 16);
							      return new String(buf);
							   }
					}.toString()));
					Category.setHeaders(IM_PRANTO);
					Category.setParams(category, RequestNetworkController.REQUEST_PARAM);
					Category.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("category.php"), "", _Category_request_listener);
					category.clear();
					IM_PRANTO.clear();
				}
				
				    }
		}, 50);
	}
	
	@Override
	public void onBackPressed() {
		finish();
		overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
	}
	public void _vpn() {
	}
	public boolean vpn() {
		    String iface = "";
		    try {
			        for (java.net.NetworkInterface networkInterface : Collections.list(java.net.NetworkInterface.getNetworkInterfaces())) {
				            if (networkInterface.isUp())
				                iface = networkInterface.getName();
				                Log.d("DEBUG", "IFACE NAME: " + iface);
				            if ( iface.contains("tun") || iface.contains("ppp") || iface.contains("pptp")) {
					                return true;
					            }
				        }
			    } catch (Exception e1) {
			        e1.printStackTrace();
			    }
		
		    return false;
	}
	{
	}
	
	public class CategoryViewAdapter extends RecyclerView.Adapter<CategoryViewAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public CategoryViewAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.category, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout Bg = _view.findViewById(R.id.Bg);
			final LinearLayout div = _view.findViewById(R.id.div);
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final androidx.cardview.widget.CardView cardview2 = _view.findViewById(R.id.cardview2);
			final ImageView Image = _view.findViewById(R.id.Image);
			final TextView Title = _view.findViewById(R.id.Title);
			final TextView Type = _view.findViewById(R.id.Type);
			final TextView statusTv = _view.findViewById(R.id.statusTv);
			final ImageView edit = _view.findViewById(R.id.edit);
			final ImageView delete = _view.findViewById(R.id.delete);
			
			Url = _data.get((int)_position).get("image_url").toString();
			Glide.with(getApplicationContext()).load(Uri.parse(Url)).placeholder(R.drawable.loading).into(Image);
			Title.setText(_data.get((int)_position).get("title").toString());
			Type.setText(_data.get((int)_position).get("type").toString());
			if (String.valueOf((long)(Double.parseDouble(_data.get((int)_position).get("status").toString()))).equals("1")) {
				statusTv.setText("Active");
				statusTv.setTextColor(0xFF4CAF50);
				statusTv.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFF4CAF50, 0x334CAF50));
			} else {
				statusTv.setText("Inactive");
				statusTv.setTextColor(0xFFF44336);
				statusTv.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFFF44336, 0x33F44336));
			}
			if (_position < (_data.size() - 1)) {
				div.setVisibility(View.VISIBLE);
			} else {
				div.setVisibility(View.GONE);
			}
			edit.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					D = new AlertDialog.Builder(PrantoCategoryActivity.this).create();
					LayoutInflater DLI = getLayoutInflater();
					View DCV = (View) DLI.inflate(R.layout.update_category, null);
					D.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
					D.setView(DCV);
					final EditText E1 = (EditText)
					DCV.findViewById(R.id.E1);
					final EditText E2 = (EditText)
					DCV.findViewById(R.id.E2);
					final EditText E3 = (EditText)
					DCV.findViewById(R.id.E3);
					final CheckBox checkbox1 = (CheckBox)
					DCV.findViewById(R.id.checkbox1);
					final CheckBox checkbox2 = (CheckBox)
					DCV.findViewById(R.id.checkbox2);
					final CheckBox check1 = (CheckBox)
					DCV.findViewById(R.id.check1);
					final CheckBox check2 = (CheckBox)
					DCV.findViewById(R.id.check2);
					final CheckBox check3 = (CheckBox)
					DCV.findViewById(R.id.check3);
					final CheckBox check4 = (CheckBox)
					DCV.findViewById(R.id.check4);
					final TextView Done = (TextView)
					DCV.findViewById(R.id.Done);
					E1.setTextIsSelectable(true);
					E2.setTextIsSelectable(true);
					E3.setTextIsSelectable(true);
					E1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
					E2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
					E3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
					Done.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF0D00FF));
					E1.setText(_data.get((int)_position).get("title").toString());
					E2.setText(_data.get((int)_position).get("image_url").toString());
					E3.setText(_data.get((int)_position).get("rules").toString());
					if (String.valueOf((long)(Double.parseDouble(_data.get((int)_position).get("status").toString()))).equals("1")) {
						upStatus = "1";
						checkbox1.setChecked(true);
						checkbox2.setChecked(false);
					} else {
						upStatus = "0";
						checkbox1.setChecked(false);
						checkbox2.setChecked(true);
					}
					checkbox1.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							upStatus = "1";
							checkbox1.setChecked(true);
							checkbox2.setChecked(false);
						}
					});
					checkbox2.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							upStatus = "0";
							checkbox1.setChecked(false);
							checkbox2.setChecked(true);
						}
					});
					if (_data.get((int)_position).get("type").toString().equals("BR MATCH")) {
						upType = "BR MATCH";
						check1.setChecked(true);
						check2.setChecked(false);
						check3.setChecked(false);
						check4.setChecked(false);
					} else {
						if (_data.get((int)_position).get("type").toString().equals("SQUAD MATCHES")) {
							upType = "SQUAD MATCHES";
							check1.setChecked(false);
							check2.setChecked(true);
							check3.setChecked(false);
							check4.setChecked(false);
						} else {
							if (_data.get((int)_position).get("type").toString().equals("LONE WOLF")) {
								upType = "LONE WOLF";
								check1.setChecked(false);
								check2.setChecked(false);
								check3.setChecked(true);
								check4.setChecked(false);
							} else {
								if (_data.get((int)_position).get("type").toString().equals("HEADSHOT MODES")) {
									upType = "HEADSHOT MODES";
									check1.setChecked(false);
									check2.setChecked(false);
									check3.setChecked(false);
									check4.setChecked(true);
								}
							}
						}
					}
					check1.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							upType = "BR MATCH";
							check1.setChecked(true);
							check2.setChecked(false);
							check3.setChecked(false);
							check4.setChecked(false);
						}
					});
					check2.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							upType = "SQUAD MATCHES";
							check1.setChecked(false);
							check2.setChecked(true);
							check3.setChecked(false);
							check4.setChecked(false);
						}
					});
					check3.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							upType = "LONE WOLF";
							check1.setChecked(false);
							check2.setChecked(false);
							check3.setChecked(true);
							check4.setChecked(false);
						}
					});
					check4.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							upType = "HEADSHOT MODES";
							check1.setChecked(false);
							check2.setChecked(false);
							check3.setChecked(false);
							check4.setChecked(true);
						}
					});
					Done.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							if (!E1.getText().toString().equals("")) {
								if (!E2.getText().toString().equals("")) {
									if (!E3.getText().toString().equals("")) {
										if (!upStatus.equals("")) {
											if (!upType.equals("")) {
												D.dismiss();
												if (vpn()) {
												} else {
													CustomLoading.show(PrantoCategoryActivity.this);
													IM_PRANTO = new HashMap<>();
													category = new HashMap<>();
													category.put("type", "update");
													category.put("id", _data.get((int)_position).get("id").toString());
													category.put("category_type", upType);
													category.put("title", E1.getText().toString());
													category.put("image_url", E2.getText().toString());
													category.put("rules", E3.getText().toString());
													category.put("status", upStatus);
													category.put("email", Auth.getString("Email", ""));
													category.put("session_id", Auth.getString("Session_id", ""));
													IM_PRANTO.put("X-IM-PRANTO", (new Object() {
														   int t;
														   public String toString() {
															      byte[] buf = new byte[22];
															      t = 5242880;
															      buf[0] = (byte) (t >>> 16);
															      t = 116736;
															      buf[1] = (byte) (t >>> 10);
															      t = 12713984;
															      buf[2] = (byte) (t >>> 17);
															      t = 28835840;
															      buf[3] = (byte) (t >>> 18);
															      t = 30408704;
															      buf[4] = (byte) (t >>> 18);
															      t = 56832;
															      buf[5] = (byte) (t >>> 9);
															      t = 3112960;
															      buf[6] = (byte) (t >>> 15);
															      t = 104857600;
															      buf[7] = (byte) (t >>> 21);
															      t = 100663296;
															      buf[8] = (byte) (t >>> 21);
															      t = 6291456;
															      buf[9] = (byte) (t >>> 17);
															      t = 230686720;
															      buf[10] = (byte) (t >>> 22);
															      t = 24320;
															      buf[11] = (byte) (t >>> 8);
															      t = 4928;
															      buf[12] = (byte) (t >>> 6);
															      t = 199229440;
															      buf[13] = (byte) (t >>> 21);
															      t = 1359872;
															      buf[14] = (byte) (t >>> 14);
															      t = 105906176;
															      buf[15] = (byte) (t >>> 20);
															      t = 25952256;
															      buf[16] = (byte) (t >>> 18);
															      t = 245366784;
															      buf[17] = (byte) (t >>> 21);
															      t = 478150656;
															      buf[18] = (byte) (t >>> 22);
															      t = 880803840;
															      buf[19] = (byte) (t >>> 23);
															      t = 14848;
															      buf[20] = (byte) (t >>> 7);
															      t = 7929856;
															      buf[21] = (byte) (t >>> 16);
															      return new String(buf);
															   }
													}.toString()));
													Update.setHeaders(IM_PRANTO);
													Update.setParams(category, RequestNetworkController.REQUEST_PARAM);
													Update.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("category.php"), "", _Update_request_listener);
													category.clear();
													IM_PRANTO.clear();
												}
											}
										}
									}
								}
							}
						}
					});
					D.setCancelable(true);
					D.show();
				}
			});
			delete.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					final AlertDialog dialog = new AlertDialog.Builder(PrantoCategoryActivity.this).create();
					View inflate = getLayoutInflater().inflate(R.layout.confirm,null); 
					dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
					dialog.setView(inflate);
					LinearLayout confirmBg = (LinearLayout) inflate.findViewById(R.id.confirmBg);
					TextView cancelTv = (TextView) inflate.findViewById(R.id.cancelTv);
					cancelTv.setText("No");
					TextView confrmTv = (TextView) inflate.findViewById(R.id.confrmTv);
					confrmTv.setText("Yes");
					TextView Tv1 = (TextView) inflate.findViewById(R.id.Tv1);
					Tv1.setText("Confirmation! ");
					TextView Tv2 = (TextView) inflate.findViewById(R.id.Tv2);
					Tv2.setText("Do you want to delete this category?");
					confirmBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF0D00FF));
					cancelTv.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
							dialog.dismiss();
						}
					});
					confirmBg.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
							dialog.dismiss();
							if (vpn()) {
							} else {
								CustomLoading.show(PrantoCategoryActivity.this);
								IM_PRANTO = new HashMap<>();
								category = new HashMap<>();
								category.put("type", "delete");
								category.put("id", _data.get((int)_position).get("id").toString());
								category.put("email", Auth.getString("Email", ""));
								category.put("session_id", Auth.getString("Session_id", ""));
								IM_PRANTO.put("X-IM-PRANTO", (new Object() {
									   int t;
									   public String toString() {
										      byte[] buf = new byte[22];
										      t = 5242880;
										      buf[0] = (byte) (t >>> 16);
										      t = 116736;
										      buf[1] = (byte) (t >>> 10);
										      t = 12713984;
										      buf[2] = (byte) (t >>> 17);
										      t = 28835840;
										      buf[3] = (byte) (t >>> 18);
										      t = 30408704;
										      buf[4] = (byte) (t >>> 18);
										      t = 56832;
										      buf[5] = (byte) (t >>> 9);
										      t = 3112960;
										      buf[6] = (byte) (t >>> 15);
										      t = 104857600;
										      buf[7] = (byte) (t >>> 21);
										      t = 100663296;
										      buf[8] = (byte) (t >>> 21);
										      t = 6291456;
										      buf[9] = (byte) (t >>> 17);
										      t = 230686720;
										      buf[10] = (byte) (t >>> 22);
										      t = 24320;
										      buf[11] = (byte) (t >>> 8);
										      t = 4928;
										      buf[12] = (byte) (t >>> 6);
										      t = 199229440;
										      buf[13] = (byte) (t >>> 21);
										      t = 1359872;
										      buf[14] = (byte) (t >>> 14);
										      t = 105906176;
										      buf[15] = (byte) (t >>> 20);
										      t = 25952256;
										      buf[16] = (byte) (t >>> 18);
										      t = 245366784;
										      buf[17] = (byte) (t >>> 21);
										      t = 478150656;
										      buf[18] = (byte) (t >>> 22);
										      t = 880803840;
										      buf[19] = (byte) (t >>> 23);
										      t = 14848;
										      buf[20] = (byte) (t >>> 7);
										      t = 7929856;
										      buf[21] = (byte) (t >>> 16);
										      return new String(buf);
										   }
								}.toString()));
								Delete.setHeaders(IM_PRANTO);
								Delete.setParams(category, RequestNetworkController.REQUEST_PARAM);
								Delete.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("category.php"), "", _Delete_request_listener);
								category.clear();
								IM_PRANTO.clear();
							}
						}
					});
					dialog.setCancelable(false);
					dialog.show();
				}
			});
			Bg.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					MATCH_TYPE.edit().putString("Category Id", _data.get((int)_position).get("id").toString()).commit();
					MATCH_TYPE.edit().putString("Title", _data.get((int)_position).get("title").toString()).commit();
					New_Activity.setClass(getApplicationContext(), PrantoMatchActivity.class);
					startActivity(New_Activity);
					overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}
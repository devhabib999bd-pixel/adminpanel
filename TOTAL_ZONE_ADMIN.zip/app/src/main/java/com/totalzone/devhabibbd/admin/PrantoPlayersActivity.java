package com.totalzone.devhabibbd.admin;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
import java.util.Base64;
import java.nio.charset.StandardCharsets;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.gson.JsonParser;
import com.google.gson.JsonObject;
import android.content.pm.PackageManager;
import android.Manifest;

public class PrantoPlayersActivity extends AppCompatActivity {
	
	private HashMap<String, Object> player = new HashMap<>();
	private HashMap<String, Object> IM_PRANTO = new HashMap<>();
	private HashMap<String, Object> mapP1 = new HashMap<>();
	private String Save = "";
	private double Frame = 0;
	private double Bye = 0;
	private HashMap<String, Object> refund = new HashMap<>();
	private HashMap<String, Object> refundResponse = new HashMap<>();
	private HashMap<String, Object> notification_Map = new HashMap<>();
	private String ProjectID = "";
	private String accessToken = "";
	private double Num1 = 0;
	private double Num2 = 0;
	
	private ArrayList<HashMap<String, Object>> playerList = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear2;
	private RecyclerView PlayersView;
	private ImageView imageview1;
	private TextView Title;
	private LinearLayout playersBg;
	private LinearLayout collectBg;
	private LinearLayout feeBg;
	private LinearLayout statusBg;
	private TextView textview1;
	private TextView playersTv;
	private TextView textview2;
	private TextView collectedTv;
	private TextView textview4;
	private TextView feeTv;
	private TextView textview6;
	private TextView statusTv;
	private LinearLayout BOX1;
	private LinearLayout BOX2;
	private ImageView imageview4;
	private EditText E1;
	private ImageView imageview5;
	private TextView textview7;
	
	private SharedPreferences Auth;
	private SharedPreferences app_infos;
	private RequestNetwork Participants;
	private RequestNetwork.RequestListener _Participants_request_listener;
	private RequestNetwork All_Refund;
	private RequestNetwork.RequestListener _All_Refund_request_listener;
	private SharedPreferences Finish;
	private RequestNetwork Solo_Refund;
	private RequestNetwork.RequestListener _Solo_Refund_request_listener;
	
	private OnCompleteListener FCM_onCompleteListener;
	private Intent New_Activity = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.pranto_players);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		linear2 = findViewById(R.id.linear2);
		PlayersView = findViewById(R.id.PlayersView);
		imageview1 = findViewById(R.id.imageview1);
		Title = findViewById(R.id.Title);
		playersBg = findViewById(R.id.playersBg);
		collectBg = findViewById(R.id.collectBg);
		feeBg = findViewById(R.id.feeBg);
		statusBg = findViewById(R.id.statusBg);
		textview1 = findViewById(R.id.textview1);
		playersTv = findViewById(R.id.playersTv);
		textview2 = findViewById(R.id.textview2);
		collectedTv = findViewById(R.id.collectedTv);
		textview4 = findViewById(R.id.textview4);
		feeTv = findViewById(R.id.feeTv);
		textview6 = findViewById(R.id.textview6);
		statusTv = findViewById(R.id.statusTv);
		BOX1 = findViewById(R.id.BOX1);
		BOX2 = findViewById(R.id.BOX2);
		imageview4 = findViewById(R.id.imageview4);
		E1 = findViewById(R.id.E1);
		imageview5 = findViewById(R.id.imageview5);
		textview7 = findViewById(R.id.textview7);
		Auth = getSharedPreferences("Auth", Activity.MODE_PRIVATE);
		app_infos = getSharedPreferences("app_infos", Activity.MODE_PRIVATE);
		Participants = new RequestNetwork(this);
		All_Refund = new RequestNetwork(this);
		Finish = getSharedPreferences("Finish", Activity.MODE_PRIVATE);
		Solo_Refund = new RequestNetwork(this);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
				overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
			}
		});
		
		BOX2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				final AlertDialog dialog = new AlertDialog.Builder(PrantoPlayersActivity.this).create();
				View inflate = getLayoutInflater().inflate(R.layout.confirm,null); 
				dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
				dialog.setView(inflate);
				LinearLayout confirmBg = (LinearLayout) inflate.findViewById(R.id.confirmBg);
				TextView cancelTv = (TextView) inflate.findViewById(R.id.cancelTv);
				cancelTv.setText("No");
				TextView confrmTv = (TextView) inflate.findViewById(R.id.confrmTv);
				confrmTv.setText("Yes");
				TextView Tv1 = (TextView) inflate.findViewById(R.id.Tv1);
				Tv1.setText("Confirmation! ");
				TextView Tv2 = (TextView) inflate.findViewById(R.id.Tv2);
				Tv2.setText("Do you want to refund all players?");
				confirmBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF0D00FF));
				cancelTv.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						dialog.dismiss();
					}
				});
				confirmBg.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						dialog.dismiss();
						CustomLoading.show(PrantoPlayersActivity.this);
						if (vpn()) {
						} else {
							Num1 = 0;
							Num2 = 0;
							for(int _repeat49 = 0; _repeat49 < (int)(playerList.size()); _repeat49++) {
								if (playerList.get((int)Num1).containsKey("fcm_token")) {
									Num2 = 1;
									_Pranto_Notification(playerList.get((int)Num1).get("fcm_token").toString(), "Match Refund", "Dear ".concat(playerList.get((int)Num1).get("name").toString().concat(", you have been refunded for joining match ID: #".concat(getIntent().getStringExtra("Match Id")))));
								}
								Num1++;
							}
							if (Num2 == 0) {
								try{
									 
								}catch(Exception e){
									 
								}
							}
							//---------------------------------
							IM_PRANTO = new HashMap<>();
							refund = new HashMap<>();
							refund.put("type", "all");
							refund.put("match_id", getIntent().getStringExtra("Match Id"));
							refund.put("email", Auth.getString("Email", ""));
							refund.put("session_id", Auth.getString("Session_id", ""));
							IM_PRANTO.put("X-IM-PRANTO", (new Object() {
								   int t;
								   public String toString() {
									      byte[] buf = new byte[22];
									      t = 5242880;
									      buf[0] = (byte) (t >>> 16);
									      t = 116736;
									      buf[1] = (byte) (t >>> 10);
									      t = 12713984;
									      buf[2] = (byte) (t >>> 17);
									      t = 28835840;
									      buf[3] = (byte) (t >>> 18);
									      t = 30408704;
									      buf[4] = (byte) (t >>> 18);
									      t = 56832;
									      buf[5] = (byte) (t >>> 9);
									      t = 3112960;
									      buf[6] = (byte) (t >>> 15);
									      t = 104857600;
									      buf[7] = (byte) (t >>> 21);
									      t = 100663296;
									      buf[8] = (byte) (t >>> 21);
									      t = 6291456;
									      buf[9] = (byte) (t >>> 17);
									      t = 230686720;
									      buf[10] = (byte) (t >>> 22);
									      t = 24320;
									      buf[11] = (byte) (t >>> 8);
									      t = 4928;
									      buf[12] = (byte) (t >>> 6);
									      t = 199229440;
									      buf[13] = (byte) (t >>> 21);
									      t = 1359872;
									      buf[14] = (byte) (t >>> 14);
									      t = 105906176;
									      buf[15] = (byte) (t >>> 20);
									      t = 25952256;
									      buf[16] = (byte) (t >>> 18);
									      t = 245366784;
									      buf[17] = (byte) (t >>> 21);
									      t = 478150656;
									      buf[18] = (byte) (t >>> 22);
									      t = 880803840;
									      buf[19] = (byte) (t >>> 23);
									      t = 14848;
									      buf[20] = (byte) (t >>> 7);
									      t = 7929856;
									      buf[21] = (byte) (t >>> 16);
									      return new String(buf);
									   }
							}.toString()));
							All_Refund.setHeaders(IM_PRANTO);
							All_Refund.setParams(refund, RequestNetworkController.REQUEST_PARAM);
							All_Refund.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("refund.php"), "", _All_Refund_request_listener);
							refund.clear();
							IM_PRANTO.clear();
						}
					}
				});
				dialog.setCancelable(false);
				dialog.show();
			}
		});
		
		E1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				playerList = new Gson().fromJson(Save, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				if (_charSeq.length() > 0) {
					Frame = playerList.size() - 1;
					Bye = playerList.size();
					for(int _repeat21 = 0; _repeat21 < (int)(Bye); _repeat21++) {
						if ((playerList.get((int)Frame).get("slot").toString().toLowerCase().contains(_charSeq.toLowerCase()) || playerList.get((int)Frame).get("name").toString().toLowerCase().contains(_charSeq.toLowerCase())) || playerList.get((int)Frame).get("user_id").toString().toLowerCase().contains(_charSeq.toLowerCase())) {
							
						} else {
							playerList.remove((int)(Frame));
							PlayersView.setAdapter(new PlayersViewAdapter(playerList));
						}
						Frame--;
					}
				}
				PlayersView.setAdapter(new PlayersViewAdapter(playerList));
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		_Participants_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				mapP1.clear();
				playerList.clear();
				try {
					try {
							JSONArray Array1 = new JSONArray(_response);
							for (int Ps1 = 0; Ps1 < Array1.length(); Ps1++) {
									JSONObject PRANTO1 = Array1.getJSONObject(Ps1);
									try { 
								mapP1 = new HashMap<>();
								mapP1.put("id", PRANTO1.getString("id"));
								mapP1.put("name", PRANTO1.getString("name"));
								mapP1.put("user_id", PRANTO1.getString("user_id"));
								mapP1.put("status", PRANTO1.getString("status"));
								mapP1.put("fcm_token", PRANTO1.getString("fcm_token"));
								mapP1.put("slot", PRANTO1.getString("slot"));
								playerList.add(mapP1);
								Save = new Gson().toJson(playerList);
								PlayersView.setAdapter(new PlayersViewAdapter(playerList));
							}catch(Exception ex){ex.printStackTrace();}
							}
					} catch (JSONException e) {
							e.printStackTrace();
					}
				} catch (Exception e) {
					
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_All_Refund_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				CustomLoading.dismiss();
				try{
					refundResponse.clear();
					refundResponse = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
					if (refundResponse.get("status").toString().equals("success")) {
						if (vpn()) {
						} else {
							IM_PRANTO = new HashMap<>();
							player = new HashMap<>();
							player.put("match_id", getIntent().getStringExtra("Match Id"));
							player.put("email", Auth.getString("Email", ""));
							player.put("session_id", Auth.getString("Session_id", ""));
							IM_PRANTO.put("X-IM-PRANTO", (new Object() {
								   int t;
								   public String toString() {
									      byte[] buf = new byte[22];
									      t = 5242880;
									      buf[0] = (byte) (t >>> 16);
									      t = 116736;
									      buf[1] = (byte) (t >>> 10);
									      t = 12713984;
									      buf[2] = (byte) (t >>> 17);
									      t = 28835840;
									      buf[3] = (byte) (t >>> 18);
									      t = 30408704;
									      buf[4] = (byte) (t >>> 18);
									      t = 56832;
									      buf[5] = (byte) (t >>> 9);
									      t = 3112960;
									      buf[6] = (byte) (t >>> 15);
									      t = 104857600;
									      buf[7] = (byte) (t >>> 21);
									      t = 100663296;
									      buf[8] = (byte) (t >>> 21);
									      t = 6291456;
									      buf[9] = (byte) (t >>> 17);
									      t = 230686720;
									      buf[10] = (byte) (t >>> 22);
									      t = 24320;
									      buf[11] = (byte) (t >>> 8);
									      t = 4928;
									      buf[12] = (byte) (t >>> 6);
									      t = 199229440;
									      buf[13] = (byte) (t >>> 21);
									      t = 1359872;
									      buf[14] = (byte) (t >>> 14);
									      t = 105906176;
									      buf[15] = (byte) (t >>> 20);
									      t = 25952256;
									      buf[16] = (byte) (t >>> 18);
									      t = 245366784;
									      buf[17] = (byte) (t >>> 21);
									      t = 478150656;
									      buf[18] = (byte) (t >>> 22);
									      t = 880803840;
									      buf[19] = (byte) (t >>> 23);
									      t = 14848;
									      buf[20] = (byte) (t >>> 7);
									      t = 7929856;
									      buf[21] = (byte) (t >>> 16);
									      return new String(buf);
									   }
							}.toString()));
							Participants.setHeaders(IM_PRANTO);
							Participants.setParams(player, RequestNetworkController.REQUEST_PARAM);
							Participants.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("participants.php"), "", _Participants_request_listener);
							player.clear();
							IM_PRANTO.clear();
						}
						Finish.edit().putString("Update", "YES").commit();
						CustomToast.show(findViewById(android.R.id.content), "All players refund successful", CustomToast.TYPE_SUCCESS, R.font.font2);
					} else {
						if (refundResponse.get("message").toString().equals("Permission Denied")) {
							CustomToast.show(findViewById(android.R.id.content), "Permission Denied", CustomToast.TYPE_ERROR, R.font.font3);
						} else {
							CustomToast.show(findViewById(android.R.id.content), "All players refund failed", CustomToast.TYPE_ERROR, R.font.font3);
						}
					}
				}catch(Exception e){
					 
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_Solo_Refund_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				CustomLoading.dismiss();
				try{
					refundResponse.clear();
					refundResponse = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
					if (refundResponse.get("status").toString().equals("success")) {
						if (vpn()) {
						} else {
							IM_PRANTO = new HashMap<>();
							player = new HashMap<>();
							player.put("match_id", getIntent().getStringExtra("Match Id"));
							player.put("email", Auth.getString("Email", ""));
							player.put("session_id", Auth.getString("Session_id", ""));
							IM_PRANTO.put("X-IM-PRANTO", (new Object() {
								   int t;
								   public String toString() {
									      byte[] buf = new byte[22];
									      t = 5242880;
									      buf[0] = (byte) (t >>> 16);
									      t = 116736;
									      buf[1] = (byte) (t >>> 10);
									      t = 12713984;
									      buf[2] = (byte) (t >>> 17);
									      t = 28835840;
									      buf[3] = (byte) (t >>> 18);
									      t = 30408704;
									      buf[4] = (byte) (t >>> 18);
									      t = 56832;
									      buf[5] = (byte) (t >>> 9);
									      t = 3112960;
									      buf[6] = (byte) (t >>> 15);
									      t = 104857600;
									      buf[7] = (byte) (t >>> 21);
									      t = 100663296;
									      buf[8] = (byte) (t >>> 21);
									      t = 6291456;
									      buf[9] = (byte) (t >>> 17);
									      t = 230686720;
									      buf[10] = (byte) (t >>> 22);
									      t = 24320;
									      buf[11] = (byte) (t >>> 8);
									      t = 4928;
									      buf[12] = (byte) (t >>> 6);
									      t = 199229440;
									      buf[13] = (byte) (t >>> 21);
									      t = 1359872;
									      buf[14] = (byte) (t >>> 14);
									      t = 105906176;
									      buf[15] = (byte) (t >>> 20);
									      t = 25952256;
									      buf[16] = (byte) (t >>> 18);
									      t = 245366784;
									      buf[17] = (byte) (t >>> 21);
									      t = 478150656;
									      buf[18] = (byte) (t >>> 22);
									      t = 880803840;
									      buf[19] = (byte) (t >>> 23);
									      t = 14848;
									      buf[20] = (byte) (t >>> 7);
									      t = 7929856;
									      buf[21] = (byte) (t >>> 16);
									      return new String(buf);
									   }
							}.toString()));
							Participants.setHeaders(IM_PRANTO);
							Participants.setParams(player, RequestNetworkController.REQUEST_PARAM);
							Participants.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("participants.php"), "", _Participants_request_listener);
							player.clear();
							IM_PRANTO.clear();
						}
						Finish.edit().putString("Update", "YES").commit();
						CustomToast.show(findViewById(android.R.id.content), "Player refund successful", CustomToast.TYPE_SUCCESS, R.font.font2);
					} else {
						if (refundResponse.get("message").toString().equals("Permission Denied")) {
							CustomToast.show(findViewById(android.R.id.content), "Permission Denied", CustomToast.TYPE_ERROR, R.font.font3);
						} else {
							CustomToast.show(findViewById(android.R.id.content), "Player refund failed", CustomToast.TYPE_ERROR, R.font.font3);
						}
					}
				}catch(Exception e){
					 
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		FCM_onCompleteListener = new OnCompleteListener<InstanceIdResult>() {
			@Override
			public void onComplete(Task<InstanceIdResult> task) {
				final boolean _success = task.isSuccessful();
				final String _token = task.getResult().getToken();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
	}
	
	private void initializeLogic() {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
			Window w =PrantoPlayersActivity.this.getWindow();
			w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFF000000);
		}
		Title.setText("#".concat(String.valueOf((long)(Double.parseDouble(getIntent().getStringExtra("Match Id"))))));
		playersTv.setText(getIntent().getStringExtra("Players"));
		collectedTv.setText(String.valueOf((long)(Double.parseDouble(getIntent().getStringExtra("Players")) * Double.parseDouble(getIntent().getStringExtra("Fee")))).concat(" TK"));
		feeTv.setText(getIntent().getStringExtra("Fee").concat(" TK"));
		if (String.valueOf((long)(Double.parseDouble(getIntent().getStringExtra("Status")))).equals("0")) {
			statusTv.setTextColor(0xFF4CAF50);
			statusTv.setText("Active");
		} else {
			if (String.valueOf((long)(Double.parseDouble(getIntent().getStringExtra("Status")))).equals("1")) {
				statusTv.setTextColor(0xFFF44336);
				statusTv.setText("Inactive");
			} else {
				if (String.valueOf((long)(Double.parseDouble(getIntent().getStringExtra("Status")))).equals("2")) {
					statusTv.setTextColor(0xFF0D00FF);
					statusTv.setText("Finished");
				}
			}
		}
		try {
				   
				    InputStream originalInputStream = getAssets().open("pranto.json");
				    byte[] inputStreamBytes = SketchwareUtil.copyFromInputStream(originalInputStream).getBytes();
				    originalInputStream.close();
				
				   
				    try (InputStream inputStream = new ByteArrayInputStream(inputStreamBytes)) {
						        String jsonString = SketchwareUtil.copyFromInputStream(inputStream);
						        HashMap<String, Object> map = new Gson().fromJson(
						            jsonString,
						            new TypeToken<HashMap<String, Object>>(){}.getType()
						        );
						        ProjectID = map.get("project_id").toString();
						    }
				
				  
				    try (InputStream inputStream = new ByteArrayInputStream(inputStreamBytes)) {
						        AccessTokenGenerator.generateToken(inputStream, new AccessTokenGenerator.onTokenResponse() {
								            @Override
								            public void onSuccess(String token) {
										                JsonObject jsonResponse = JsonParser.parseString(token).getAsJsonObject();
										                if (jsonResponse.has("access_token")) {
												                    accessToken = jsonResponse.get("access_token").getAsString();
												                } else {
												                  accessToken = "error getting accessToken";
												                }
										                  
										            }
								
								            @Override
								            public void onError(String error) {
										                
										                  
										            }
								        });
						    }
		} catch (Exception e) {
				    
			
		}
		GridLayoutManager gridLayoutManager1 = new GridLayoutManager(this, 2);
		PlayersView.setLayoutManager(gridLayoutManager1);
		playersBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF212121, Color.TRANSPARENT));
		collectBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF212121, Color.TRANSPARENT));
		feeBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF212121, Color.TRANSPARENT));
		statusBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)2, 0xFF212121, Color.TRANSPARENT));
		BOX1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		BOX2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)90, 0xFFFF6D00));
		new java.util.Timer().schedule(new java.util.TimerTask() {
			    @Override
			    public void run() {
				        
				if (vpn()) {
				} else {
					IM_PRANTO = new HashMap<>();
					player = new HashMap<>();
					player.put("match_id", getIntent().getStringExtra("Match Id"));
					player.put("email", Auth.getString("Email", ""));
					player.put("session_id", Auth.getString("Session_id", ""));
					IM_PRANTO.put("X-IM-PRANTO", (new Object() {
						   int t;
						   public String toString() {
							      byte[] buf = new byte[22];
							      t = 5242880;
							      buf[0] = (byte) (t >>> 16);
							      t = 116736;
							      buf[1] = (byte) (t >>> 10);
							      t = 12713984;
							      buf[2] = (byte) (t >>> 17);
							      t = 28835840;
							      buf[3] = (byte) (t >>> 18);
							      t = 30408704;
							      buf[4] = (byte) (t >>> 18);
							      t = 56832;
							      buf[5] = (byte) (t >>> 9);
							      t = 3112960;
							      buf[6] = (byte) (t >>> 15);
							      t = 104857600;
							      buf[7] = (byte) (t >>> 21);
							      t = 100663296;
							      buf[8] = (byte) (t >>> 21);
							      t = 6291456;
							      buf[9] = (byte) (t >>> 17);
							      t = 230686720;
							      buf[10] = (byte) (t >>> 22);
							      t = 24320;
							      buf[11] = (byte) (t >>> 8);
							      t = 4928;
							      buf[12] = (byte) (t >>> 6);
							      t = 199229440;
							      buf[13] = (byte) (t >>> 21);
							      t = 1359872;
							      buf[14] = (byte) (t >>> 14);
							      t = 105906176;
							      buf[15] = (byte) (t >>> 20);
							      t = 25952256;
							      buf[16] = (byte) (t >>> 18);
							      t = 245366784;
							      buf[17] = (byte) (t >>> 21);
							      t = 478150656;
							      buf[18] = (byte) (t >>> 22);
							      t = 880803840;
							      buf[19] = (byte) (t >>> 23);
							      t = 14848;
							      buf[20] = (byte) (t >>> 7);
							      t = 7929856;
							      buf[21] = (byte) (t >>> 16);
							      return new String(buf);
							   }
					}.toString()));
					Participants.setHeaders(IM_PRANTO);
					Participants.setParams(player, RequestNetworkController.REQUEST_PARAM);
					Participants.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("participants.php"), "", _Participants_request_listener);
					player.clear();
					IM_PRANTO.clear();
				}
				
				    }
		}, 50);
	}
	
	@Override
	public void onBackPressed() {
		finish();
		overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
	}
	
	public void _vpn() {
	}
	public boolean vpn() {
		    String iface = "";
		    try {
			        for (java.net.NetworkInterface networkInterface : Collections.list(java.net.NetworkInterface.getNetworkInterfaces())) {
				            if (networkInterface.isUp())
				                iface = networkInterface.getName();
				                Log.d("DEBUG", "IFACE NAME: " + iface);
				            if ( iface.contains("tun") || iface.contains("ppp") || iface.contains("pptp")) {
					                return true;
					            }
				        }
			    } catch (Exception e1) {
			        e1.printStackTrace();
			    }
		
		    return false;
	}
	{
	}
	
	
	public void _Pranto_Notification(final String _Topic, final String _Title, final String _Body) {
		notification_Map = new HashMap<>();
		notification_Map.put("title", _Title);
		notification_Map.put("body", _Body);
		notification_Map.put("image", "null");
		String token =  _Topic;
		String topic = ""; 
		String projectId =  ProjectID;
		String tokenaccess =  accessToken; 
		FCMNotificationSender.sendNotification( notification_Map, topic, token, projectId, tokenaccess, new FCMNotificationSender.onResponse() {
				    @Override
				    public void onSuccess(String response) {
						    	        		         
						    }
				
				    @Override
				    public void onError(String error) {
						      		          
						    }
		});
		
	}
	
	public class PlayersViewAdapter extends RecyclerView.Adapter<PlayersViewAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public PlayersViewAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.players, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final androidx.cardview.widget.CardView cardview2 = _view.findViewById(R.id.cardview2);
			final LinearLayout BG = _view.findViewById(R.id.BG);
			final LinearLayout numBg = _view.findViewById(R.id.numBg);
			final LinearLayout nameBg1 = _view.findViewById(R.id.nameBg1);
			final TextView teamNo = _view.findViewById(R.id.teamNo);
			final TextView nameTv = _view.findViewById(R.id.nameTv);
			final TextView useridTv = _view.findViewById(R.id.useridTv);
			
			teamNo.setText(String.valueOf((long)(Double.parseDouble(_data.get((int)_position).get("slot").toString()))));
			if (_data.get((int)_position).get("name").toString().equals("") || (_data.get((int)_position).get("name").toString().equals("null") || _data.get((int)_position).get("id").toString().equals("null"))) {
				useridTv.setVisibility(View.GONE);
				nameTv.setText("-------");
				useridTv.setText("");
				teamNo.setTextColor(0xFF757575);
				nameTv.setTextColor(0xFF616161);
			} else {
				useridTv.setVisibility(View.VISIBLE);
				nameTv.setText(_data.get((int)_position).get("name").toString());
				useridTv.setText(_data.get((int)_position).get("user_id").toString());
				nameTv.setTextColor(0xFFFFFFFF);
				teamNo.setTextColor(0xFFFFC400);
			}
			cardview1.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(View _view) {
					if (!(_data.get((int)_position).get("status").toString().equals("") || _data.get((int)_position).get("status").toString().equals("null"))) {
						if (String.valueOf((long)(Double.parseDouble(_data.get((int)_position).get("status").toString()))).equals("1")) {
							CustomToast.show(findViewById(android.R.id.content), "Winnings have been sent to this player and cannot be refunded", CustomToast.TYPE_ERROR, R.font.font3);
						} else {
							final AlertDialog dialog = new AlertDialog.Builder(PrantoPlayersActivity.this).create();
							View inflate = getLayoutInflater().inflate(R.layout.confirm,null); 
							dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
							dialog.setView(inflate);
							LinearLayout confirmBg = (LinearLayout) inflate.findViewById(R.id.confirmBg);
							TextView cancelTv = (TextView) inflate.findViewById(R.id.cancelTv);
							cancelTv.setText("No");
							TextView confrmTv = (TextView) inflate.findViewById(R.id.confrmTv);
							confrmTv.setText("Yes");
							TextView Tv1 = (TextView) inflate.findViewById(R.id.Tv1);
							Tv1.setText("Confirmation! ");
							TextView Tv2 = (TextView) inflate.findViewById(R.id.Tv2);
							Tv2.setText("Do you want to refund this player?");
							confirmBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF0D00FF));
							cancelTv.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
									dialog.dismiss();
								}
							});
							confirmBg.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
									dialog.dismiss();
									CustomLoading.show(PrantoPlayersActivity.this);
									if (vpn()) {
									} else {
										Num1 = 0;
										Num2 = 0;
										for(int _repeat123 = 0; _repeat123 < (int)(playerList.size()); _repeat123++) {
											if (playerList.get((int)Num1).get("user_id").toString().equals(_data.get((int)_position).get("user_id").toString())) {
												if (playerList.get((int)Num1).containsKey("fcm_token")) {
													Num2 = 1;
													_Pranto_Notification(_data.get((int)_position).get("fcm_token").toString(), "Match Refund", "Dear ".concat(_data.get((int)_position).get("name").toString().concat(", you have been refunded for joining match ID: #".concat(getIntent().getStringExtra("Match Id")))));
												}
											}
											Num1++;
										}
										if (Num2 == 0) {
											try{
												 
											}catch(Exception e){
												 
											}
										}
										//---------------------------------
										IM_PRANTO = new HashMap<>();
										refund = new HashMap<>();
										refund.put("type", "one");
										refund.put("user_id", _data.get((int)_position).get("user_id").toString());
										refund.put("match_id", getIntent().getStringExtra("Match Id"));
										refund.put("email", Auth.getString("Email", ""));
										refund.put("session_id", Auth.getString("Session_id", ""));
										IM_PRANTO.put("X-IM-PRANTO", (new Object() {
											   int t;
											   public String toString() {
												      byte[] buf = new byte[22];
												      t = 5242880;
												      buf[0] = (byte) (t >>> 16);
												      t = 116736;
												      buf[1] = (byte) (t >>> 10);
												      t = 12713984;
												      buf[2] = (byte) (t >>> 17);
												      t = 28835840;
												      buf[3] = (byte) (t >>> 18);
												      t = 30408704;
												      buf[4] = (byte) (t >>> 18);
												      t = 56832;
												      buf[5] = (byte) (t >>> 9);
												      t = 3112960;
												      buf[6] = (byte) (t >>> 15);
												      t = 104857600;
												      buf[7] = (byte) (t >>> 21);
												      t = 100663296;
												      buf[8] = (byte) (t >>> 21);
												      t = 6291456;
												      buf[9] = (byte) (t >>> 17);
												      t = 230686720;
												      buf[10] = (byte) (t >>> 22);
												      t = 24320;
												      buf[11] = (byte) (t >>> 8);
												      t = 4928;
												      buf[12] = (byte) (t >>> 6);
												      t = 199229440;
												      buf[13] = (byte) (t >>> 21);
												      t = 1359872;
												      buf[14] = (byte) (t >>> 14);
												      t = 105906176;
												      buf[15] = (byte) (t >>> 20);
												      t = 25952256;
												      buf[16] = (byte) (t >>> 18);
												      t = 245366784;
												      buf[17] = (byte) (t >>> 21);
												      t = 478150656;
												      buf[18] = (byte) (t >>> 22);
												      t = 880803840;
												      buf[19] = (byte) (t >>> 23);
												      t = 14848;
												      buf[20] = (byte) (t >>> 7);
												      t = 7929856;
												      buf[21] = (byte) (t >>> 16);
												      return new String(buf);
												   }
										}.toString()));
										Solo_Refund.setHeaders(IM_PRANTO);
										Solo_Refund.setParams(refund, RequestNetworkController.REQUEST_PARAM);
										Solo_Refund.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("refund.php"), "", _Solo_Refund_request_listener);
										refund.clear();
										IM_PRANTO.clear();
									}
								}
							});
							dialog.setCancelable(false);
							dialog.show();
						}
					}
					return true;
				}
			});
			cardview1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					if (!(_data.get((int)_position).get("status").toString().equals("") || _data.get((int)_position).get("status").toString().equals("null"))) {
						if (String.valueOf((long)(Double.parseDouble(_data.get((int)_position).get("status").toString()))).equals("0")) {
							New_Activity.setClass(getApplicationContext(), PrantoWinningActivity.class);
							New_Activity.putExtra("Match Id", getIntent().getStringExtra("Match Id"));
							New_Activity.putExtra("Join Id", _data.get((int)_position).get("id").toString());
							New_Activity.putExtra("User Id", _data.get((int)_position).get("user_id").toString());
							New_Activity.putExtra("Name", _data.get((int)_position).get("name").toString());
							New_Activity.putExtra("Fcm", _data.get((int)_position).get("fcm_token").toString());
							New_Activity.putExtra("Slot", _data.get((int)_position).get("slot").toString());
							New_Activity.setClass(getApplicationContext(), PrantoWinningActivity.class);
							startActivity(New_Activity);
							overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
						} else {
							CustomToast.show(findViewById(android.R.id.content), "Winning has already been sent to this player", CustomToast.TYPE_ERROR, R.font.font3);
						}
					}
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}
package com.totalzone.devhabibbd.admin;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.google.firebase.FirebaseApp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class PrantoTransactionActivity extends AppCompatActivity {
	
	private HashMap<String, Object> IM_PRANTO = new HashMap<>();
	private HashMap<String, Object> trx = new HashMap<>();
	private HashMap<String, Object> mapU1 = new HashMap<>();
	private String Save = "";
	private double Frame = 0;
	private double Bye = 0;
	private String Status = "";
	private HashMap<String, Object> statusResponse = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> trxList = new ArrayList<>();
	
	private LinearLayout BG;
	private LinearLayout linear3;
	private LinearLayout linear2;
	private TextView textview1;
	private LinearLayout linear1;
	private ImageView imageview1;
	private TextView textview3;
	private LinearLayout BOX1;
	private LinearLayout BOX2;
	private ImageView imageview4;
	private EditText E1;
	private ImageView imageview5;
	private TextView textview2;
	private RecyclerView PaymentView;
	private LinearLayout LiadingBg;
	private LinearLayout notBg;
	private ProgressBar prog;
	private TextView textview4;
	
	private com.google.android.material.bottomsheet.BottomSheetDialog B;
	private RequestNetwork Transaction;
	private RequestNetwork.RequestListener _Transaction_request_listener;
	private SharedPreferences Auth;
	private SharedPreferences app_infos;
	private RequestNetwork Update;
	private RequestNetwork.RequestListener _Update_request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.pranto_transaction);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		BG = findViewById(R.id.BG);
		linear3 = findViewById(R.id.linear3);
		linear2 = findViewById(R.id.linear2);
		textview1 = findViewById(R.id.textview1);
		linear1 = findViewById(R.id.linear1);
		imageview1 = findViewById(R.id.imageview1);
		textview3 = findViewById(R.id.textview3);
		BOX1 = findViewById(R.id.BOX1);
		BOX2 = findViewById(R.id.BOX2);
		imageview4 = findViewById(R.id.imageview4);
		E1 = findViewById(R.id.E1);
		imageview5 = findViewById(R.id.imageview5);
		textview2 = findViewById(R.id.textview2);
		PaymentView = findViewById(R.id.PaymentView);
		LiadingBg = findViewById(R.id.LiadingBg);
		notBg = findViewById(R.id.notBg);
		prog = findViewById(R.id.prog);
		textview4 = findViewById(R.id.textview4);
		Transaction = new RequestNetwork(this);
		Auth = getSharedPreferences("Auth", Activity.MODE_PRIVATE);
		app_infos = getSharedPreferences("app_infos", Activity.MODE_PRIVATE);
		Update = new RequestNetwork(this);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
				overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
			}
		});
		
		BOX2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				B = new com.google.android.material.bottomsheet.BottomSheetDialog(PrantoTransactionActivity.this);
				View BV;
				BV = getLayoutInflater().inflate(R.layout.flitter_choice,null );
				B.setContentView(BV);
				B.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(android.R.color.transparent);
				final LinearLayout BG = (LinearLayout) BV.findViewById(R.id.BG);
				final LinearLayout dot = (LinearLayout) BV.findViewById(R.id.dot);
				final LinearLayout bg1 = (LinearLayout) BV.findViewById(R.id.bg1);
				final LinearLayout bg2 = (LinearLayout) BV.findViewById(R.id.bg2);
				final LinearLayout bg3 = (LinearLayout) BV.findViewById(R.id.bg3);
				final ImageView img1 = (ImageView) BV.findViewById(R.id.img1);
				final ImageView img2 = (ImageView) BV.findViewById(R.id.img2);
				final ImageView img3 = (ImageView) BV.findViewById(R.id.img3);
				int[] colorsCRNPS = { Color.parseColor("#000000"), Color.parseColor("#000000") }; android.graphics.drawable.GradientDrawable CRNPS = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNPS);
				CRNPS.setCornerRadii(new float[]{(int)66,(int)66,(int)66,(int)66,(int)0,(int)0,(int)0,(int)0});
				CRNPS.setStroke((int) 0, Color.parseColor("#000000"));
				BG.setElevation((float) 0);
				BG.setBackground(CRNPS);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				dot.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)90, 0xFF757575));
				bg1.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						img1.setImageResource(R.drawable.icon_check_circle);
						Status = "0";
						_transactionApi(Status);
						B.dismiss();
					}
				});
				bg2.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						img2.setImageResource(R.drawable.icon_check_circle);
						Status = "1";
						_transactionApi(Status);
						B.dismiss();
					}
				});
				bg3.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						img3.setImageResource(R.drawable.icon_check_circle);
						Status = "2";
						_transactionApi(Status);
						B.dismiss();
					}
				});
				B.setCancelable(true);
				B.show();
			}
		});
		
		E1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				trxList = new Gson().fromJson(Save, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				if (_charSeq.length() > 0) {
					Frame = trxList.size() - 1;
					Bye = trxList.size();
					for(int _repeat21 = 0; _repeat21 < (int)(Bye); _repeat21++) {
						if (trxList.get((int)Frame).get("id").toString().toLowerCase().contains(_charSeq.toLowerCase()) || trxList.get((int)Frame).get("trxid").toString().toLowerCase().contains(_charSeq.toLowerCase())) {
							
						} else {
							trxList.remove((int)(Frame));
							PaymentView.setAdapter(new PaymentViewAdapter(trxList));
						}
						Frame--;
					}
				}
				PaymentView.setAdapter(new PaymentViewAdapter(trxList));
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		_Transaction_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				LiadingBg.setVisibility(View.GONE);
				mapU1.clear();
				trxList.clear();
				try {
					try {
							JSONArray Array1 = new JSONArray(_response);
							for (int Ps1 = 0; Ps1 < Array1.length(); Ps1++) {
									JSONObject PRANTO1 = Array1.getJSONObject(Ps1);
									try { 
								mapU1 = new HashMap<>();
								mapU1.put("id", PRANTO1.getString("id"));
								mapU1.put("username", PRANTO1.getString("username"));
								mapU1.put("trxid", PRANTO1.getString("trxid"));
								mapU1.put("method", PRANTO1.getString("method"));
								mapU1.put("amount", PRANTO1.getString("amount"));
								mapU1.put("type", PRANTO1.getString("type"));
								mapU1.put("status", PRANTO1.getString("status"));
								mapU1.put("fcm_token", PRANTO1.getString("fcm_token"));
								mapU1.put("ip_address", PRANTO1.getString("ip_address"));
								mapU1.put("date", PRANTO1.getString("date"));
								trxList.add(mapU1);
								Save = new Gson().toJson(trxList);
								PaymentView.setAdapter(new PaymentViewAdapter(trxList));
							}catch(Exception ex){ex.printStackTrace();}
							}
					} catch (JSONException e) {
							e.printStackTrace();
					}
				} catch (Exception e) {
					
				}
				if (trxList.size() == 0) {
					PaymentView.setVisibility(View.GONE);
					notBg.setVisibility(View.VISIBLE);
				} else {
					PaymentView.setVisibility(View.VISIBLE);
					notBg.setVisibility(View.GONE);
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_Update_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				CustomLoading.dismiss();
				try{
					statusResponse.clear();
					statusResponse = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
					if (statusResponse.get("status").toString().equals("success")) {
						CustomToast.show(findViewById(android.R.id.content), "Status update successful", CustomToast.TYPE_SUCCESS, R.font.font2);
						_transactionApi(Status);
					} else {
						CustomToast.show(findViewById(android.R.id.content), "Status update failed", CustomToast.TYPE_ERROR, R.font.font3);
					}
				}catch(Exception e){
					 
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
			Window w =PrantoTransactionActivity.this.getWindow();
			w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFF000000);
		}
		PaymentView.setLayoutManager(new LinearLayoutManager(this));
		BOX2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)90, (int)2, 0xFF0D00FF, 0x330D00FF));
		BOX1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		textview3.setText(getIntent().getStringExtra("Type"));
		LiadingBg.setVisibility(View.VISIBLE);
		PaymentView.setVisibility(View.GONE);
		Status = "0";
		new java.util.Timer().schedule(new java.util.TimerTask() {
			    @Override
			    public void run() {
				        
				_transactionApi(Status);
				
				    }
		}, 50);
	}
	
	@Override
	public void onBackPressed() {
		finish();
		overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
	}
	public void _transactionApi(final String _Status) {
		if (vpn()) {
		} else {
			IM_PRANTO = new HashMap<>();
			trx = new HashMap<>();
			trx.put("type", getIntent().getStringExtra("Type"));
			trx.put("status", _Status);
			trx.put("email", Auth.getString("Email", ""));
			trx.put("session_id", Auth.getString("Session_id", ""));
			IM_PRANTO.put("X-IM-PRANTO", (new Object() {
				   int t;
				   public String toString() {
					      byte[] buf = new byte[22];
					      t = 5242880;
					      buf[0] = (byte) (t >>> 16);
					      t = 116736;
					      buf[1] = (byte) (t >>> 10);
					      t = 12713984;
					      buf[2] = (byte) (t >>> 17);
					      t = 28835840;
					      buf[3] = (byte) (t >>> 18);
					      t = 30408704;
					      buf[4] = (byte) (t >>> 18);
					      t = 56832;
					      buf[5] = (byte) (t >>> 9);
					      t = 3112960;
					      buf[6] = (byte) (t >>> 15);
					      t = 104857600;
					      buf[7] = (byte) (t >>> 21);
					      t = 100663296;
					      buf[8] = (byte) (t >>> 21);
					      t = 6291456;
					      buf[9] = (byte) (t >>> 17);
					      t = 230686720;
					      buf[10] = (byte) (t >>> 22);
					      t = 24320;
					      buf[11] = (byte) (t >>> 8);
					      t = 4928;
					      buf[12] = (byte) (t >>> 6);
					      t = 199229440;
					      buf[13] = (byte) (t >>> 21);
					      t = 1359872;
					      buf[14] = (byte) (t >>> 14);
					      t = 105906176;
					      buf[15] = (byte) (t >>> 20);
					      t = 25952256;
					      buf[16] = (byte) (t >>> 18);
					      t = 245366784;
					      buf[17] = (byte) (t >>> 21);
					      t = 478150656;
					      buf[18] = (byte) (t >>> 22);
					      t = 880803840;
					      buf[19] = (byte) (t >>> 23);
					      t = 14848;
					      buf[20] = (byte) (t >>> 7);
					      t = 7929856;
					      buf[21] = (byte) (t >>> 16);
					      return new String(buf);
					   }
			}.toString()));
			Transaction.setHeaders(IM_PRANTO);
			Transaction.setParams(trx, RequestNetworkController.REQUEST_PARAM);
			Transaction.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("transaction.php"), "", _Transaction_request_listener);
			trx.clear();
			IM_PRANTO.clear();
		}
	}
	
	
	public void _vpn() {
	}
	public boolean vpn() {
		    String iface = "";
		    try {
			        for (java.net.NetworkInterface networkInterface : Collections.list(java.net.NetworkInterface.getNetworkInterfaces())) {
				            if (networkInterface.isUp())
				                iface = networkInterface.getName();
				                Log.d("DEBUG", "IFACE NAME: " + iface);
				            if ( iface.contains("tun") || iface.contains("ppp") || iface.contains("pptp")) {
					                return true;
					            }
				        }
			    } catch (Exception e1) {
			        e1.printStackTrace();
			    }
		
		    return false;
	}
	{
	}
	
	
	public void _statusUpdateApi(final String _id, final String _status) {
		final AlertDialog dialog = new AlertDialog.Builder(PrantoTransactionActivity.this).create();
		View inflate = getLayoutInflater().inflate(R.layout.confirm,null); 
		dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		dialog.setView(inflate);
		LinearLayout confirmBg = (LinearLayout) inflate.findViewById(R.id.confirmBg);
		TextView cancelTv = (TextView) inflate.findViewById(R.id.cancelTv);
		cancelTv.setText("No");
		TextView confrmTv = (TextView) inflate.findViewById(R.id.confrmTv);
		confrmTv.setText("Yes");
		TextView Tv1 = (TextView) inflate.findViewById(R.id.Tv1);
		Tv1.setText("Confirmation! ");
		TextView Tv2 = (TextView) inflate.findViewById(R.id.Tv2);
		Tv2.setText("Do you want to update the status of this transaction?");
		confirmBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF0D00FF));
		cancelTv.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				dialog.dismiss();
			}
		});
		confirmBg.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				dialog.dismiss();
				CustomLoading.show(PrantoTransactionActivity.this);
				if (vpn()) {
				} else {
					IM_PRANTO = new HashMap<>();
					trx = new HashMap<>();
					trx.put("type", "Update");
					trx.put("status", _status);
					trx.put("id", _id);
					trx.put("email", Auth.getString("Email", ""));
					trx.put("session_id", Auth.getString("Session_id", ""));
					IM_PRANTO.put("X-IM-PRANTO", (new Object() {
						   int t;
						   public String toString() {
							      byte[] buf = new byte[22];
							      t = 5242880;
							      buf[0] = (byte) (t >>> 16);
							      t = 116736;
							      buf[1] = (byte) (t >>> 10);
							      t = 12713984;
							      buf[2] = (byte) (t >>> 17);
							      t = 28835840;
							      buf[3] = (byte) (t >>> 18);
							      t = 30408704;
							      buf[4] = (byte) (t >>> 18);
							      t = 56832;
							      buf[5] = (byte) (t >>> 9);
							      t = 3112960;
							      buf[6] = (byte) (t >>> 15);
							      t = 104857600;
							      buf[7] = (byte) (t >>> 21);
							      t = 100663296;
							      buf[8] = (byte) (t >>> 21);
							      t = 6291456;
							      buf[9] = (byte) (t >>> 17);
							      t = 230686720;
							      buf[10] = (byte) (t >>> 22);
							      t = 24320;
							      buf[11] = (byte) (t >>> 8);
							      t = 4928;
							      buf[12] = (byte) (t >>> 6);
							      t = 199229440;
							      buf[13] = (byte) (t >>> 21);
							      t = 1359872;
							      buf[14] = (byte) (t >>> 14);
							      t = 105906176;
							      buf[15] = (byte) (t >>> 20);
							      t = 25952256;
							      buf[16] = (byte) (t >>> 18);
							      t = 245366784;
							      buf[17] = (byte) (t >>> 21);
							      t = 478150656;
							      buf[18] = (byte) (t >>> 22);
							      t = 880803840;
							      buf[19] = (byte) (t >>> 23);
							      t = 14848;
							      buf[20] = (byte) (t >>> 7);
							      t = 7929856;
							      buf[21] = (byte) (t >>> 16);
							      return new String(buf);
							   }
					}.toString()));
					Update.setHeaders(IM_PRANTO);
					Update.setParams(trx, RequestNetworkController.REQUEST_PARAM);
					Update.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("transaction.php"), "", _Update_request_listener);
					trx.clear();
					IM_PRANTO.clear();
				}
			}
		});
		dialog.setCancelable(false);
		dialog.show();
	}
	
	public class PaymentViewAdapter extends RecyclerView.Adapter<PaymentViewAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public PaymentViewAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.transaction, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout BG = _view.findViewById(R.id.BG);
			final LinearLayout div = _view.findViewById(R.id.div);
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear12 = _view.findViewById(R.id.linear12);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear6 = _view.findViewById(R.id.linear6);
			final LinearLayout linear16 = _view.findViewById(R.id.linear16);
			final LinearLayout linear15 = _view.findViewById(R.id.linear15);
			final ImageView method_image = _view.findViewById(R.id.method_image);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final TextView method = _view.findViewById(R.id.method);
			final TextView date = _view.findViewById(R.id.date);
			final LinearLayout Dot = _view.findViewById(R.id.Dot);
			final TextView status = _view.findViewById(R.id.status);
			final ImageView img5 = _view.findViewById(R.id.img5);
			final TextView textview9 = _view.findViewById(R.id.textview9);
			final LinearLayout linear13 = _view.findViewById(R.id.linear13);
			final TextView email = _view.findViewById(R.id.email);
			final ImageView img1 = _view.findViewById(R.id.img1);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final TextView amount = _view.findViewById(R.id.amount);
			final ImageView img2 = _view.findViewById(R.id.img2);
			final TextView textv = _view.findViewById(R.id.textv);
			final LinearLayout linear7 = _view.findViewById(R.id.linear7);
			final TextView trxid = _view.findViewById(R.id.trxid);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final TextView textview10 = _view.findViewById(R.id.textview10);
			final LinearLayout linear17 = _view.findViewById(R.id.linear17);
			final TextView ipTv = _view.findViewById(R.id.ipTv);
			final TextView approved = _view.findViewById(R.id.approved);
			final TextView rejected = _view.findViewById(R.id.rejected);
			
			linear15.setVisibility(View.GONE);
			approved.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFF4CAF50));
			rejected.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFFF44336));
			if (_position < (_data.size() - 1)) {
				div.setVisibility(View.VISIBLE);
			} else {
				div.setVisibility(View.GONE);
			}
			if (_data.get((int)_position).get("type").toString().equals("Deposit")) {
				textv.setText("Transaction ID");
				trxid.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", _data.get((int)_position).get("trxid").toString()));
						CustomToast.show(findViewById(android.R.id.content), "Trx ID copied to clipboard", CustomToast.TYPE_SUCCESS, R.font.font3);
					}
				});
			}
			if (_data.get((int)_position).get("type").toString().equals("Withdraw")) {
				textv.setText("Payment Number");
				trxid.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", _data.get((int)_position).get("trxid").toString()));
						CustomToast.show(findViewById(android.R.id.content), "Number copied to clipboard", CustomToast.TYPE_SUCCESS, R.font.font3);
					}
				});
			}
			if (_data.get((int)_position).get("method").toString().equals("BKASH")) {
				method_image.setImageResource(R.drawable.bk_logo);
			}
			if (_data.get((int)_position).get("method").toString().equals("NAGAD")) {
				method_image.setImageResource(R.drawable.images);
			}
			if (_data.get((int)_position).get("method").toString().equals("ROCKET")) {
				method_image.setImageResource(R.drawable.unnamed);
			}
			email.setText(_data.get((int)_position).get("username").toString());
			method.setText(_data.get((int)_position).get("method").toString());
			amount.setText(String.valueOf((long)(Double.parseDouble(_data.get((int)_position).get("amount").toString()))).concat(" Tk"));
			trxid.setText(_data.get((int)_position).get("trxid").toString());
			date.setText(_data.get((int)_position).get("date").toString());
			ipTv.setText(_data.get((int)_position).get("ip_address").toString());
			if (String.valueOf((long)(Double.parseDouble(_data.get((int)_position).get("status").toString()))).equals("0")) {
				Dot.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFFFFC107));
				status.setTextColor(0xFFFFC107);
				status.setText("Pending");
				linear15.setVisibility(View.VISIBLE);
				approved.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						_statusUpdateApi(_data.get((int)_position).get("id").toString(), "1");
					}
				});
				rejected.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						_statusUpdateApi(_data.get((int)_position).get("id").toString(), "2");
					}
				});
			} else {
				if (String.valueOf((long)(Double.parseDouble(_data.get((int)_position).get("status").toString()))).equals("1")) {
					Dot.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF4CAF50));
					status.setTextColor(0xFF4CAF50);
					status.setText("Success");
				} else {
					Dot.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFFF44336));
					status.setTextColor(0xFFF44336);
					status.setText("Rejected");
				}
			}
			ipTv.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", _data.get((int)_position).get("ip_address").toString()));
					CustomToast.show(findViewById(android.R.id.content), "Ip address copied to clipboard", CustomToast.TYPE_SUCCESS, R.font.font3);
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}
package com.totalzone.devhabibbd.admin;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.firebase.FirebaseApp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class PrantoLoginActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private HashMap<String, Object> IM_PRANTO = new HashMap<>();
	private HashMap<String, Object> Login = new HashMap<>();
	private HashMap<String, Object> loginResponse = new HashMap<>();
	
	private LinearLayout BG;
	private TextView Tv2;
	private TextView Tv3;
	private TextView Tv5;
	private LinearLayout BOX1;
	private TextView textview1;
	private LinearLayout BOX2;
	private LinearLayout Lg_B1;
	private ImageView imageview4;
	private EditText E1;
	private ImageView imageview6;
	private EditText E2;
	private LinearLayout linear5;
	private ImageView show;
	private ImageView hide;
	private TextView Tv8;
	private ImageView imageview7;
	
	private RequestNetwork LOGIN;
	private RequestNetwork.RequestListener _LOGIN_request_listener;
	private SharedPreferences app_infos;
	private Intent New_Activity = new Intent();
	private SharedPreferences Auth;
	private TimerTask Timer;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.pranto_login);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		BG = findViewById(R.id.BG);
		Tv2 = findViewById(R.id.Tv2);
		Tv3 = findViewById(R.id.Tv3);
		Tv5 = findViewById(R.id.Tv5);
		BOX1 = findViewById(R.id.BOX1);
		textview1 = findViewById(R.id.textview1);
		BOX2 = findViewById(R.id.BOX2);
		Lg_B1 = findViewById(R.id.Lg_B1);
		imageview4 = findViewById(R.id.imageview4);
		E1 = findViewById(R.id.E1);
		imageview6 = findViewById(R.id.imageview6);
		E2 = findViewById(R.id.E2);
		linear5 = findViewById(R.id.linear5);
		show = findViewById(R.id.show);
		hide = findViewById(R.id.hide);
		Tv8 = findViewById(R.id.Tv8);
		imageview7 = findViewById(R.id.imageview7);
		LOGIN = new RequestNetwork(this);
		app_infos = getSharedPreferences("app_infos", Activity.MODE_PRIVATE);
		Auth = getSharedPreferences("Auth", Activity.MODE_PRIVATE);
		
		Lg_B1.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				_clickAnimation(Lg_B1);
				return true;
			}
		});
		
		Lg_B1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_clickAnimation(Lg_B1);
				if (!E1.getText().toString().equals("")) {
					if (!E2.getText().toString().equals("")) {
						if (vpn()) {
						} else {
							CustomLoading.show(PrantoLoginActivity.this);
							IM_PRANTO = new HashMap<>();
							Login = new HashMap<>();
							Login.put("userdata", E1.getText().toString());
							Login.put("password", E2.getText().toString());
							IM_PRANTO.put("X-IM-PRANTO", (new Object() {
								   int t;
								   public String toString() {
									      byte[] buf = new byte[22];
									      t = 5242880;
									      buf[0] = (byte) (t >>> 16);
									      t = 116736;
									      buf[1] = (byte) (t >>> 10);
									      t = 12713984;
									      buf[2] = (byte) (t >>> 17);
									      t = 28835840;
									      buf[3] = (byte) (t >>> 18);
									      t = 30408704;
									      buf[4] = (byte) (t >>> 18);
									      t = 56832;
									      buf[5] = (byte) (t >>> 9);
									      t = 3112960;
									      buf[6] = (byte) (t >>> 15);
									      t = 104857600;
									      buf[7] = (byte) (t >>> 21);
									      t = 100663296;
									      buf[8] = (byte) (t >>> 21);
									      t = 6291456;
									      buf[9] = (byte) (t >>> 17);
									      t = 230686720;
									      buf[10] = (byte) (t >>> 22);
									      t = 24320;
									      buf[11] = (byte) (t >>> 8);
									      t = 4928;
									      buf[12] = (byte) (t >>> 6);
									      t = 199229440;
									      buf[13] = (byte) (t >>> 21);
									      t = 1359872;
									      buf[14] = (byte) (t >>> 14);
									      t = 105906176;
									      buf[15] = (byte) (t >>> 20);
									      t = 25952256;
									      buf[16] = (byte) (t >>> 18);
									      t = 245366784;
									      buf[17] = (byte) (t >>> 21);
									      t = 478150656;
									      buf[18] = (byte) (t >>> 22);
									      t = 880803840;
									      buf[19] = (byte) (t >>> 23);
									      t = 14848;
									      buf[20] = (byte) (t >>> 7);
									      t = 7929856;
									      buf[21] = (byte) (t >>> 16);
									      return new String(buf);
									   }
							}.toString()));
							LOGIN.setHeaders(IM_PRANTO);
							LOGIN.setParams(Login, RequestNetworkController.REQUEST_PARAM);
							LOGIN.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("login.php"), "", _LOGIN_request_listener);
							Login.clear();
							IM_PRANTO.clear();
						}
					} else {
						CustomToast.show(findViewById(android.R.id.content), "Please fill in all fields", CustomToast.TYPE_ERROR, R.font.font3);
					}
				} else {
					CustomToast.show(findViewById(android.R.id.content), "Please fill in all fields", CustomToast.TYPE_ERROR, R.font.font3);
				}
			}
		});
		
		show.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				show.setVisibility(View.GONE);
				hide.setVisibility(View.VISIBLE);
				E2.setTransformationMethod(android.text.method.HideReturnsTransformationMethod.getInstance());
			}
		});
		
		hide.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				hide.setVisibility(View.GONE);
				show.setVisibility(View.VISIBLE);
				E2.setTransformationMethod(android.text.method.PasswordTransformationMethod.getInstance());
			}
		});
		
		_LOGIN_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				CustomLoading.dismiss();
				try{
					loginResponse.clear();
					loginResponse = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
					if (loginResponse.get("status").toString().equals("success")) {
						CustomToast.show(findViewById(android.R.id.content), "Login successful!", CustomToast.TYPE_SUCCESS, R.font.font2);
						Auth.edit().putString("Login", "True").commit();
						Auth.edit().putString("Email", loginResponse.get("email").toString()).commit();
						Auth.edit().putString("Session_id", loginResponse.get("session_id").toString()).commit();
						Timer = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										New_Activity.setClass(getApplicationContext(), PrantoHomeActivity.class);
										startActivity(New_Activity);
										overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
									}
								});
							}
						};
						_timer.schedule(Timer, (int)(1000));
					} else {
						CustomToast.show(findViewById(android.R.id.content), "Incorrect information or password", CustomToast.TYPE_ERROR, R.font.font3);
					}
				}catch(Exception e){
					 
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
			Window w =PrantoLoginActivity.this.getWindow();
			w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFF000000);
		}
		show.setVisibility(View.VISIBLE);
		hide.setVisibility(View.GONE);
		BOX1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		BOX2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		Lg_B1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF0D00FF));
	}
	
	@Override
	public void onBackPressed() {
		finishAffinity();
	}
	public void _clickAnimation(final View _view) {
		ScaleAnimation clickAnim = new ScaleAnimation(
		    1f, 0.9f,
		    1f, 0.9f,
		    Animation.RELATIVE_TO_SELF, 0.5f,
		    Animation.RELATIVE_TO_SELF, 0.5f
		);
		
		clickAnim.setDuration(100);
		clickAnim.setRepeatCount(1);
		clickAnim.setRepeatMode(Animation.REVERSE);
		clickAnim.setFillAfter(false);
		
		_view.startAnimation(clickAnim);
	}
	
	
	public void _vpn() {
	}
	public boolean vpn() {
		    String iface = "";
		    try {
			        for (java.net.NetworkInterface networkInterface : Collections.list(java.net.NetworkInterface.getNetworkInterfaces())) {
				            if (networkInterface.isUp())
				                iface = networkInterface.getName();
				                Log.d("DEBUG", "IFACE NAME: " + iface);
				            if ( iface.contains("tun") || iface.contains("ppp") || iface.contains("pptp")) {
					                return true;
					            }
				        }
			    } catch (Exception e1) {
			        e1.printStackTrace();
			    }
		
		    return false;
	}
	{
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}
package com.totalzone.devhabibbd.admin;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.google.firebase.FirebaseApp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
import com.bumptech.glide.Glide;

public class PrantoUsersDetailsActivity extends AppCompatActivity {
	
	private HashMap<String, Object> user = new HashMap<>();
	private HashMap<String, Object> userResponse = new HashMap<>();
	private HashMap<String, Object> IM_PRANTO = new HashMap<>();
	private String Status = "";
	private HashMap<String, Object> updateResponse = new HashMap<>();
	private HashMap<String, Object> mapU1 = new HashMap<>();
	private HashMap<String, Object> trx = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> trxList = new ArrayList<>();
	
	private LinearLayout Bg;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private ScrollView vscroll1;
	private LinearLayout TrxBg;
	private ImageView imageview1;
	private TextView textview1;
	private LinearLayout linear4;
	private LinearLayout linear7;
	private LinearLayout bg1;
	private LinearLayout bg2;
	private TextView tv1;
	private TextView tv2;
	private LinearLayout div1;
	private LinearLayout div2;
	private LinearLayout BGX;
	private CardView cardview1;
	private CardView cardview2;
	private LinearLayout linear37;
	private LinearLayout linear8;
	private CircleImageView avatar;
	private LinearLayout linear9;
	private TextView id1;
	private TextView nameTv1;
	private TextView email1;
	private TextView number1;
	private LinearLayout linear10;
	private LinearLayout linear11;
	private LinearLayout linear12;
	private LinearLayout linear13;
	private LinearLayout linear14;
	private LinearLayout linear15;
	private LinearLayout linear16;
	private LinearLayout linear17;
	private LinearLayout linear18;
	private LinearLayout linear24;
	private LinearLayout linear25;
	private LinearLayout linear26;
	private LinearLayout linear27;
	private LinearLayout linear28;
	private LinearLayout linear30;
	private LinearLayout linear31;
	private LinearLayout linear32;
	private LinearLayout linear33;
	private LinearLayout linear34;
	private LinearLayout linear19;
	private LinearLayout linear20;
	private LinearLayout linear21;
	private LinearLayout linear22;
	private LinearLayout linear23;
	private LinearLayout linear35;
	private LinearLayout linear36;
	private ImageView imageview2;
	private TextView textview2;
	private TextView idTv;
	private ImageView imageview3;
	private ImageView imageview4;
	private TextView textview4;
	private TextView usernameTv;
	private ImageView imageview6;
	private TextView textview6;
	private TextView emailTv;
	private ImageView imageview8;
	private TextView textview8;
	private TextView numberTv;
	private ImageView imageview16;
	private TextView textview16;
	private TextView balanceTv;
	private ImageView imageview17;
	private ImageView imageview18;
	private TextView textview18;
	private TextView winningTv;
	private ImageView imageview19;
	private ImageView imageview20;
	private TextView textview20;
	private TextView playTv;
	private ImageView imageview24;
	private TextView textview24;
	private TextView totalWinningTv;
	private ImageView imageview26;
	private TextView textview26;
	private TextView limitTv;
	private ImageView imageview10;
	private TextView textview10;
	private TextView ipTv;
	private ImageView imageview11;
	private ImageView imageview12;
	private TextView textview12;
	private TextView statusTv;
	private ImageView imageview14;
	private TextView textview14;
	private TextView leaderboardTv;
	private ImageView imageview28;
	private TextView textview28;
	private TextView dateTv;
	private LinearLayout banBg;
	private LinearLayout notificationBg;
	private ImageView banImg;
	private TextView banTv;
	private ImageView imageview30;
	private TextView textview30;
	private RecyclerView TrxView;
	
	private SharedPreferences app_infos;
	private SharedPreferences Auth;
	private RequestNetwork Users;
	private RequestNetwork.RequestListener _Users_request_listener;
	private AlertDialog B;
	private RequestNetwork Update;
	private RequestNetwork.RequestListener _Update_request_listener;
	private RequestNetwork Transaction;
	private RequestNetwork.RequestListener _Transaction_request_listener;
	private Intent New_Activity = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.pranto_users_details);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		Bg = findViewById(R.id.Bg);
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		vscroll1 = findViewById(R.id.vscroll1);
		TrxBg = findViewById(R.id.TrxBg);
		imageview1 = findViewById(R.id.imageview1);
		textview1 = findViewById(R.id.textview1);
		linear4 = findViewById(R.id.linear4);
		linear7 = findViewById(R.id.linear7);
		bg1 = findViewById(R.id.bg1);
		bg2 = findViewById(R.id.bg2);
		tv1 = findViewById(R.id.tv1);
		tv2 = findViewById(R.id.tv2);
		div1 = findViewById(R.id.div1);
		div2 = findViewById(R.id.div2);
		BGX = findViewById(R.id.BGX);
		cardview1 = findViewById(R.id.cardview1);
		cardview2 = findViewById(R.id.cardview2);
		linear37 = findViewById(R.id.linear37);
		linear8 = findViewById(R.id.linear8);
		avatar = findViewById(R.id.avatar);
		linear9 = findViewById(R.id.linear9);
		id1 = findViewById(R.id.id1);
		nameTv1 = findViewById(R.id.nameTv1);
		email1 = findViewById(R.id.email1);
		number1 = findViewById(R.id.number1);
		linear10 = findViewById(R.id.linear10);
		linear11 = findViewById(R.id.linear11);
		linear12 = findViewById(R.id.linear12);
		linear13 = findViewById(R.id.linear13);
		linear14 = findViewById(R.id.linear14);
		linear15 = findViewById(R.id.linear15);
		linear16 = findViewById(R.id.linear16);
		linear17 = findViewById(R.id.linear17);
		linear18 = findViewById(R.id.linear18);
		linear24 = findViewById(R.id.linear24);
		linear25 = findViewById(R.id.linear25);
		linear26 = findViewById(R.id.linear26);
		linear27 = findViewById(R.id.linear27);
		linear28 = findViewById(R.id.linear28);
		linear30 = findViewById(R.id.linear30);
		linear31 = findViewById(R.id.linear31);
		linear32 = findViewById(R.id.linear32);
		linear33 = findViewById(R.id.linear33);
		linear34 = findViewById(R.id.linear34);
		linear19 = findViewById(R.id.linear19);
		linear20 = findViewById(R.id.linear20);
		linear21 = findViewById(R.id.linear21);
		linear22 = findViewById(R.id.linear22);
		linear23 = findViewById(R.id.linear23);
		linear35 = findViewById(R.id.linear35);
		linear36 = findViewById(R.id.linear36);
		imageview2 = findViewById(R.id.imageview2);
		textview2 = findViewById(R.id.textview2);
		idTv = findViewById(R.id.idTv);
		imageview3 = findViewById(R.id.imageview3);
		imageview4 = findViewById(R.id.imageview4);
		textview4 = findViewById(R.id.textview4);
		usernameTv = findViewById(R.id.usernameTv);
		imageview6 = findViewById(R.id.imageview6);
		textview6 = findViewById(R.id.textview6);
		emailTv = findViewById(R.id.emailTv);
		imageview8 = findViewById(R.id.imageview8);
		textview8 = findViewById(R.id.textview8);
		numberTv = findViewById(R.id.numberTv);
		imageview16 = findViewById(R.id.imageview16);
		textview16 = findViewById(R.id.textview16);
		balanceTv = findViewById(R.id.balanceTv);
		imageview17 = findViewById(R.id.imageview17);
		imageview18 = findViewById(R.id.imageview18);
		textview18 = findViewById(R.id.textview18);
		winningTv = findViewById(R.id.winningTv);
		imageview19 = findViewById(R.id.imageview19);
		imageview20 = findViewById(R.id.imageview20);
		textview20 = findViewById(R.id.textview20);
		playTv = findViewById(R.id.playTv);
		imageview24 = findViewById(R.id.imageview24);
		textview24 = findViewById(R.id.textview24);
		totalWinningTv = findViewById(R.id.totalWinningTv);
		imageview26 = findViewById(R.id.imageview26);
		textview26 = findViewById(R.id.textview26);
		limitTv = findViewById(R.id.limitTv);
		imageview10 = findViewById(R.id.imageview10);
		textview10 = findViewById(R.id.textview10);
		ipTv = findViewById(R.id.ipTv);
		imageview11 = findViewById(R.id.imageview11);
		imageview12 = findViewById(R.id.imageview12);
		textview12 = findViewById(R.id.textview12);
		statusTv = findViewById(R.id.statusTv);
		imageview14 = findViewById(R.id.imageview14);
		textview14 = findViewById(R.id.textview14);
		leaderboardTv = findViewById(R.id.leaderboardTv);
		imageview28 = findViewById(R.id.imageview28);
		textview28 = findViewById(R.id.textview28);
		dateTv = findViewById(R.id.dateTv);
		banBg = findViewById(R.id.banBg);
		notificationBg = findViewById(R.id.notificationBg);
		banImg = findViewById(R.id.banImg);
		banTv = findViewById(R.id.banTv);
		imageview30 = findViewById(R.id.imageview30);
		textview30 = findViewById(R.id.textview30);
		TrxView = findViewById(R.id.TrxView);
		app_infos = getSharedPreferences("app_infos", Activity.MODE_PRIVATE);
		Auth = getSharedPreferences("Auth", Activity.MODE_PRIVATE);
		Users = new RequestNetwork(this);
		Update = new RequestNetwork(this);
		Transaction = new RequestNetwork(this);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
				overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
			}
		});
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", idTv.getText().toString()));
				CustomToast.show(findViewById(android.R.id.content), "User id copied to clipboard", CustomToast.TYPE_SUCCESS, R.font.font3);
			}
		});
		
		imageview17.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_updateDialog("balance", getIntent().getStringExtra("Id"), "Update Balance", "Enter new gaming balance");
			}
		});
		
		imageview19.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_updateDialog("winning", getIntent().getStringExtra("Id"), "Update Balance", "Enter new winning balance");
			}
		});
		
		imageview11.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", ipTv.getText().toString()));
				CustomToast.show(findViewById(android.R.id.content), "Ip copied to clipboard", CustomToast.TYPE_SUCCESS, R.font.font3);
			}
		});
		
		_Users_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				CustomLoading.dismiss();
				try{
					userResponse.clear();
					userResponse = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
					Object avatarObj = userResponse.get("avatar");
					        if (avatarObj == null || avatarObj.toString().trim().isEmpty() || avatarObj.toString().equalsIgnoreCase("null")) {
						            avatar.setImageResource(R.drawable.app_logo);
						        } else {
						            Glide.with(getApplicationContext()).load(Uri.parse(avatarObj.toString())).into(avatar);
						        }
					id1.setText("#".concat(String.valueOf((long)(Double.parseDouble(userResponse.get("id").toString())))));
					idTv.setText("#".concat(String.valueOf((long)(Double.parseDouble(userResponse.get("id").toString())))));
					nameTv1.setText(userResponse.get("username").toString());
					usernameTv.setText(userResponse.get("username").toString());
					email1.setText(userResponse.get("email").toString());
					emailTv.setText(userResponse.get("email").toString());
					number1.setText(userResponse.get("number").toString());
					numberTv.setText(userResponse.get("number").toString());
					balanceTv.setText(String.valueOf((long)(Double.parseDouble(userResponse.get("balance").toString()))).concat(" BDT"));
					winningTv.setText(String.valueOf((long)(Double.parseDouble(userResponse.get("winning").toString()))).concat(" BDT"));
					playTv.setText(String.valueOf((long)(Double.parseDouble(userResponse.get("total_play").toString()))));
					totalWinningTv.setText(String.valueOf((long)(Double.parseDouble(userResponse.get("total_winning").toString()))).concat(" BDT"));
					limitTv.setText(String.valueOf((long)(Double.parseDouble(userResponse.get("withdraw_limit").toString()))).concat("/2"));
					ipTv.setText(userResponse.get("ip_address").toString());
					leaderboardTv.setText(userResponse.get("leaderboard_name").toString());
					dateTv.setText(userResponse.get("join_date").toString());
					if (String.valueOf((long)(Double.parseDouble(userResponse.get("status").toString()))).equals("0")) {
						statusTv.setText("Active");
						statusTv.setTextColor(0xFF4CAF50);
						statusTv.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFF4CAF50, 0x334CAF50));
						banBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)30, (int)3, 0xFFF44336, 0xFF000000));
						banTv.setText("Ban User");
						banTv.setTextColor(0xFFF44336);
						banImg.setImageResource(R.drawable.icon_block_round);
						banBg.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View _view) {
								if (vpn()) {
								} else {
									CustomLoading.show(PrantoUsersDetailsActivity.this);
									IM_PRANTO = new HashMap<>();
									user = new HashMap<>();
									user.put("type", "status");
									user.put("id", getIntent().getStringExtra("Id"));
									user.put("status", "1");
									user.put("email", Auth.getString("Email", ""));
									user.put("session_id", Auth.getString("Session_id", ""));
									IM_PRANTO.put("X-IM-PRANTO", (new Object() {
										   int t;
										   public String toString() {
											      byte[] buf = new byte[22];
											      t = 5242880;
											      buf[0] = (byte) (t >>> 16);
											      t = 116736;
											      buf[1] = (byte) (t >>> 10);
											      t = 12713984;
											      buf[2] = (byte) (t >>> 17);
											      t = 28835840;
											      buf[3] = (byte) (t >>> 18);
											      t = 30408704;
											      buf[4] = (byte) (t >>> 18);
											      t = 56832;
											      buf[5] = (byte) (t >>> 9);
											      t = 3112960;
											      buf[6] = (byte) (t >>> 15);
											      t = 104857600;
											      buf[7] = (byte) (t >>> 21);
											      t = 100663296;
											      buf[8] = (byte) (t >>> 21);
											      t = 6291456;
											      buf[9] = (byte) (t >>> 17);
											      t = 230686720;
											      buf[10] = (byte) (t >>> 22);
											      t = 24320;
											      buf[11] = (byte) (t >>> 8);
											      t = 4928;
											      buf[12] = (byte) (t >>> 6);
											      t = 199229440;
											      buf[13] = (byte) (t >>> 21);
											      t = 1359872;
											      buf[14] = (byte) (t >>> 14);
											      t = 105906176;
											      buf[15] = (byte) (t >>> 20);
											      t = 25952256;
											      buf[16] = (byte) (t >>> 18);
											      t = 245366784;
											      buf[17] = (byte) (t >>> 21);
											      t = 478150656;
											      buf[18] = (byte) (t >>> 22);
											      t = 880803840;
											      buf[19] = (byte) (t >>> 23);
											      t = 14848;
											      buf[20] = (byte) (t >>> 7);
											      t = 7929856;
											      buf[21] = (byte) (t >>> 16);
											      return new String(buf);
											   }
									}.toString()));
									Update.setHeaders(IM_PRANTO);
									Update.setParams(user, RequestNetworkController.REQUEST_PARAM);
									Update.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("users.php"), "", _Update_request_listener);
									user.clear();
									IM_PRANTO.clear();
								}
							}
						});
					} else {
						statusTv.setText("Ban");
						statusTv.setTextColor(0xFFF44336);
						statusTv.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFFF44336, 0x33F44336));
						banBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)30, (int)3, 0xFF4CAF50, 0xFF000000));
						banTv.setText("Unban User");
						banTv.setTextColor(0xFF4CAF50);
						banImg.setImageResource(R.drawable.icon_check_circle);
						banBg.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View _view) {
								if (vpn()) {
								} else {
									CustomLoading.show(PrantoUsersDetailsActivity.this);
									IM_PRANTO = new HashMap<>();
									user = new HashMap<>();
									user.put("type", "status");
									user.put("id", getIntent().getStringExtra("Id"));
									user.put("status", "0");
									user.put("email", Auth.getString("Email", ""));
									user.put("session_id", Auth.getString("Session_id", ""));
									IM_PRANTO.put("X-IM-PRANTO", (new Object() {
										   int t;
										   public String toString() {
											      byte[] buf = new byte[22];
											      t = 5242880;
											      buf[0] = (byte) (t >>> 16);
											      t = 116736;
											      buf[1] = (byte) (t >>> 10);
											      t = 12713984;
											      buf[2] = (byte) (t >>> 17);
											      t = 28835840;
											      buf[3] = (byte) (t >>> 18);
											      t = 30408704;
											      buf[4] = (byte) (t >>> 18);
											      t = 56832;
											      buf[5] = (byte) (t >>> 9);
											      t = 3112960;
											      buf[6] = (byte) (t >>> 15);
											      t = 104857600;
											      buf[7] = (byte) (t >>> 21);
											      t = 100663296;
											      buf[8] = (byte) (t >>> 21);
											      t = 6291456;
											      buf[9] = (byte) (t >>> 17);
											      t = 230686720;
											      buf[10] = (byte) (t >>> 22);
											      t = 24320;
											      buf[11] = (byte) (t >>> 8);
											      t = 4928;
											      buf[12] = (byte) (t >>> 6);
											      t = 199229440;
											      buf[13] = (byte) (t >>> 21);
											      t = 1359872;
											      buf[14] = (byte) (t >>> 14);
											      t = 105906176;
											      buf[15] = (byte) (t >>> 20);
											      t = 25952256;
											      buf[16] = (byte) (t >>> 18);
											      t = 245366784;
											      buf[17] = (byte) (t >>> 21);
											      t = 478150656;
											      buf[18] = (byte) (t >>> 22);
											      t = 880803840;
											      buf[19] = (byte) (t >>> 23);
											      t = 14848;
											      buf[20] = (byte) (t >>> 7);
											      t = 7929856;
											      buf[21] = (byte) (t >>> 16);
											      return new String(buf);
											   }
									}.toString()));
									Update.setHeaders(IM_PRANTO);
									Update.setParams(user, RequestNetworkController.REQUEST_PARAM);
									Update.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("users.php"), "", _Update_request_listener);
									user.clear();
									IM_PRANTO.clear();
								}
							}
						});
					}
					notificationBg.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							New_Activity.setClass(getApplicationContext(), PrantoNotificationActivity.class);
							New_Activity.putExtra("Type", "Users");
							New_Activity.putExtra("User Id", String.valueOf((long)(Double.parseDouble(userResponse.get("id").toString()))));
							New_Activity.putExtra("Fcm", userResponse.get("fcm_token").toString());
							startActivity(New_Activity);
							overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
						}
					});
				}catch(Exception e){
					 
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_Update_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				CustomLoading.dismiss();
				try{
					updateResponse.clear();
					updateResponse = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
					if (updateResponse.get("status").toString().equals("success")) {
						if (vpn()) {
						} else {
							IM_PRANTO = new HashMap<>();
							user = new HashMap<>();
							user.put("type", "one");
							user.put("id", getIntent().getStringExtra("Id"));
							user.put("email", Auth.getString("Email", ""));
							user.put("session_id", Auth.getString("Session_id", ""));
							IM_PRANTO.put("X-IM-PRANTO", (new Object() {
								   int t;
								   public String toString() {
									      byte[] buf = new byte[22];
									      t = 5242880;
									      buf[0] = (byte) (t >>> 16);
									      t = 116736;
									      buf[1] = (byte) (t >>> 10);
									      t = 12713984;
									      buf[2] = (byte) (t >>> 17);
									      t = 28835840;
									      buf[3] = (byte) (t >>> 18);
									      t = 30408704;
									      buf[4] = (byte) (t >>> 18);
									      t = 56832;
									      buf[5] = (byte) (t >>> 9);
									      t = 3112960;
									      buf[6] = (byte) (t >>> 15);
									      t = 104857600;
									      buf[7] = (byte) (t >>> 21);
									      t = 100663296;
									      buf[8] = (byte) (t >>> 21);
									      t = 6291456;
									      buf[9] = (byte) (t >>> 17);
									      t = 230686720;
									      buf[10] = (byte) (t >>> 22);
									      t = 24320;
									      buf[11] = (byte) (t >>> 8);
									      t = 4928;
									      buf[12] = (byte) (t >>> 6);
									      t = 199229440;
									      buf[13] = (byte) (t >>> 21);
									      t = 1359872;
									      buf[14] = (byte) (t >>> 14);
									      t = 105906176;
									      buf[15] = (byte) (t >>> 20);
									      t = 25952256;
									      buf[16] = (byte) (t >>> 18);
									      t = 245366784;
									      buf[17] = (byte) (t >>> 21);
									      t = 478150656;
									      buf[18] = (byte) (t >>> 22);
									      t = 880803840;
									      buf[19] = (byte) (t >>> 23);
									      t = 14848;
									      buf[20] = (byte) (t >>> 7);
									      t = 7929856;
									      buf[21] = (byte) (t >>> 16);
									      return new String(buf);
									   }
							}.toString()));
							Users.setHeaders(IM_PRANTO);
							Users.setParams(user, RequestNetworkController.REQUEST_PARAM);
							Users.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("users.php"), "", _Users_request_listener);
							user.clear();
							IM_PRANTO.clear();
						}
						if (_tag.equals("balance")) {
							CustomToast.show(findViewById(android.R.id.content), "Gaming balance update successful", CustomToast.TYPE_SUCCESS, R.font.font3);
						} else {
							if (_tag.equals("winning")) {
								CustomToast.show(findViewById(android.R.id.content), "Winning balance update successful", CustomToast.TYPE_SUCCESS, R.font.font3);
							} else {
								CustomToast.show(findViewById(android.R.id.content), "Status update successful", CustomToast.TYPE_SUCCESS, R.font.font3);
							}
						}
					} else {
						if (_tag.equals("balance")) {
							CustomToast.show(findViewById(android.R.id.content), "Gaming balance update failed", CustomToast.TYPE_ERROR, R.font.font3);
						} else {
							if (_tag.equals("winning")) {
								CustomToast.show(findViewById(android.R.id.content), "Winning balance update failed", CustomToast.TYPE_ERROR, R.font.font3);
							} else {
								CustomToast.show(findViewById(android.R.id.content), "Status update failed", CustomToast.TYPE_ERROR, R.font.font3);
							}
						}
					}
				}catch(Exception e){
					 
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_Transaction_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				mapU1.clear();
				trxList.clear();
				try {
					try {
							JSONArray Array1 = new JSONArray(_response);
							for (int Ps1 = 0; Ps1 < Array1.length(); Ps1++) {
									JSONObject PRANTO1 = Array1.getJSONObject(Ps1);
									try { 
								mapU1 = new HashMap<>();
								mapU1.put("title", PRANTO1.getString("title"));
								mapU1.put("date", PRANTO1.getString("date"));
								mapU1.put("type", PRANTO1.getString("type"));
								mapU1.put("amount", PRANTO1.getString("amount"));
								mapU1.put("status", PRANTO1.getString("status"));
								trxList.add(mapU1);
								TrxView.setAdapter(new TrxViewAdapter(trxList));
							}catch(Exception ex){ex.printStackTrace();}
							}
					} catch (JSONException e) {
							e.printStackTrace();
					}
				} catch (Exception e) {
					
				}
				if (trxList.size() == 0) {
					TrxView.setVisibility(View.GONE);
				} else {
					TrxView.setVisibility(View.VISIBLE);
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
			Window w =PrantoUsersDetailsActivity.this.getWindow();
			w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFF000000);
		}
		TrxView.setLayoutManager(new LinearLayoutManager(this));
		notificationBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF7839DD));
		bg1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				int[] colorsCRNDY = { Color.parseColor("#0D00FF"), Color.parseColor("#0D00FF") }; android.graphics.drawable.GradientDrawable CRNDY = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNDY);
				CRNDY.setCornerRadii(new float[]{(int)62,(int)62,(int)62,(int)62,(int)0,(int)0,(int)0,(int)0});
				CRNDY.setStroke((int) 0, Color.parseColor("#000000"));
				div1.setElevation((float) 0);
				div1.setBackground(CRNDY);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				tv1.setTextColor(0xFF0D00FF);
				tv2.setTextColor(0xFF757575);
				div1.setVisibility(View.VISIBLE);
				div2.setVisibility(View.INVISIBLE);
				vscroll1.setVisibility(View.VISIBLE);
				TrxBg.setVisibility(View.GONE);
			}
		});
		bg2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				int[] colorsCRNXE = { Color.parseColor("#0D00FF"), Color.parseColor("#0D00FF") }; android.graphics.drawable.GradientDrawable CRNXE = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNXE);
				CRNXE.setCornerRadii(new float[]{(int)62,(int)62,(int)62,(int)62,(int)0,(int)0,(int)0,(int)0});
				CRNXE.setStroke((int) 0, Color.parseColor("#000000"));
				div2.setElevation((float) 0);
				div2.setBackground(CRNXE);
				
				//Paste this code in (add source directly block) asd block
				//Milz
				tv1.setTextColor(0xFF757575);
				tv2.setTextColor(0xFF0D00FF);
				div1.setVisibility(View.INVISIBLE);
				div2.setVisibility(View.VISIBLE);
				TrxBg.setVisibility(View.VISIBLE);
				vscroll1.setVisibility(View.GONE);
				if (vpn()) {
				} else {
					IM_PRANTO = new HashMap<>();
					trx = new HashMap<>();
					trx.put("type", "transaction");
					trx.put("id", getIntent().getStringExtra("Id"));
					trx.put("email", Auth.getString("Email", ""));
					trx.put("session_id", Auth.getString("Session_id", ""));
					IM_PRANTO.put("X-IM-PRANTO", (new Object() {
						   int t;
						   public String toString() {
							      byte[] buf = new byte[22];
							      t = 5242880;
							      buf[0] = (byte) (t >>> 16);
							      t = 116736;
							      buf[1] = (byte) (t >>> 10);
							      t = 12713984;
							      buf[2] = (byte) (t >>> 17);
							      t = 28835840;
							      buf[3] = (byte) (t >>> 18);
							      t = 30408704;
							      buf[4] = (byte) (t >>> 18);
							      t = 56832;
							      buf[5] = (byte) (t >>> 9);
							      t = 3112960;
							      buf[6] = (byte) (t >>> 15);
							      t = 104857600;
							      buf[7] = (byte) (t >>> 21);
							      t = 100663296;
							      buf[8] = (byte) (t >>> 21);
							      t = 6291456;
							      buf[9] = (byte) (t >>> 17);
							      t = 230686720;
							      buf[10] = (byte) (t >>> 22);
							      t = 24320;
							      buf[11] = (byte) (t >>> 8);
							      t = 4928;
							      buf[12] = (byte) (t >>> 6);
							      t = 199229440;
							      buf[13] = (byte) (t >>> 21);
							      t = 1359872;
							      buf[14] = (byte) (t >>> 14);
							      t = 105906176;
							      buf[15] = (byte) (t >>> 20);
							      t = 25952256;
							      buf[16] = (byte) (t >>> 18);
							      t = 245366784;
							      buf[17] = (byte) (t >>> 21);
							      t = 478150656;
							      buf[18] = (byte) (t >>> 22);
							      t = 880803840;
							      buf[19] = (byte) (t >>> 23);
							      t = 14848;
							      buf[20] = (byte) (t >>> 7);
							      t = 7929856;
							      buf[21] = (byte) (t >>> 16);
							      return new String(buf);
							   }
					}.toString()));
					Transaction.setHeaders(IM_PRANTO);
					Transaction.setParams(trx, RequestNetworkController.REQUEST_PARAM);
					Transaction.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("users.php"), "", _Transaction_request_listener);
					trx.clear();
					IM_PRANTO.clear();
				}
			}
		});
		bg1.performClick();
	}
	
	@Override
	public void onBackPressed() {
		finish();
		overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
	}
	
	@Override
	public void onStart() {
		super.onStart();
		if (vpn()) {
		} else {
			CustomLoading.show(PrantoUsersDetailsActivity.this);
			IM_PRANTO = new HashMap<>();
			user = new HashMap<>();
			user.put("type", "one");
			user.put("id", getIntent().getStringExtra("Id"));
			user.put("email", Auth.getString("Email", ""));
			user.put("session_id", Auth.getString("Session_id", ""));
			IM_PRANTO.put("X-IM-PRANTO", (new Object() {
				   int t;
				   public String toString() {
					      byte[] buf = new byte[22];
					      t = 5242880;
					      buf[0] = (byte) (t >>> 16);
					      t = 116736;
					      buf[1] = (byte) (t >>> 10);
					      t = 12713984;
					      buf[2] = (byte) (t >>> 17);
					      t = 28835840;
					      buf[3] = (byte) (t >>> 18);
					      t = 30408704;
					      buf[4] = (byte) (t >>> 18);
					      t = 56832;
					      buf[5] = (byte) (t >>> 9);
					      t = 3112960;
					      buf[6] = (byte) (t >>> 15);
					      t = 104857600;
					      buf[7] = (byte) (t >>> 21);
					      t = 100663296;
					      buf[8] = (byte) (t >>> 21);
					      t = 6291456;
					      buf[9] = (byte) (t >>> 17);
					      t = 230686720;
					      buf[10] = (byte) (t >>> 22);
					      t = 24320;
					      buf[11] = (byte) (t >>> 8);
					      t = 4928;
					      buf[12] = (byte) (t >>> 6);
					      t = 199229440;
					      buf[13] = (byte) (t >>> 21);
					      t = 1359872;
					      buf[14] = (byte) (t >>> 14);
					      t = 105906176;
					      buf[15] = (byte) (t >>> 20);
					      t = 25952256;
					      buf[16] = (byte) (t >>> 18);
					      t = 245366784;
					      buf[17] = (byte) (t >>> 21);
					      t = 478150656;
					      buf[18] = (byte) (t >>> 22);
					      t = 880803840;
					      buf[19] = (byte) (t >>> 23);
					      t = 14848;
					      buf[20] = (byte) (t >>> 7);
					      t = 7929856;
					      buf[21] = (byte) (t >>> 16);
					      return new String(buf);
					   }
			}.toString()));
			Users.setHeaders(IM_PRANTO);
			Users.setParams(user, RequestNetworkController.REQUEST_PARAM);
			Users.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("users.php"), "", _Users_request_listener);
			user.clear();
			IM_PRANTO.clear();
		}
	}
	
	public void _vpn() {
	}
	public boolean vpn() {
		    String iface = "";
		    try {
			        for (java.net.NetworkInterface networkInterface : Collections.list(java.net.NetworkInterface.getNetworkInterfaces())) {
				            if (networkInterface.isUp())
				                iface = networkInterface.getName();
				                Log.d("DEBUG", "IFACE NAME: " + iface);
				            if ( iface.contains("tun") || iface.contains("ppp") || iface.contains("pptp")) {
					                return true;
					            }
				        }
			    } catch (Exception e1) {
			        e1.printStackTrace();
			    }
		
		    return false;
	}
	{
	}
	
	
	public void _updateDialog(final String _Type, final String _Id, final String _Title, final String _Message) {
		B = new AlertDialog.Builder(PrantoUsersDetailsActivity.this).create();
		LayoutInflater BLI = getLayoutInflater();
		View BCV = (View) BLI.inflate(R.layout.balance_update, null);
		B.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		B.setView(BCV);
		final LinearLayout BOX1 = (LinearLayout)
		BCV.findViewById(R.id.BOX1);
		final LinearLayout confirmBg = (LinearLayout)
		BCV.findViewById(R.id.confirmBg);
		final TextView cancelTv = (TextView)
		BCV.findViewById(R.id.cancelTv);
		final TextView confrmTv = (TextView)
		BCV.findViewById(R.id.confrmTv);
		final TextView Tv2 = (TextView)
		BCV.findViewById(R.id.Tv2);
		final EditText E1 = (EditText)
		BCV.findViewById(R.id.E1);
		E1.setTextIsSelectable(true);
		Tv2.setText(_Message);
		BOX1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF191919));
		confirmBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF0D00FF));
		E1.setOnTouchListener(new View.OnTouchListener() {
			    @Override
			    public boolean onTouch(View v, android.view.MotionEvent event) {
				        if (event.getAction() == android.view.MotionEvent.ACTION_DOWN) {
					            android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
					            gd.setCornerRadius(30f);
					            gd.setStroke(4, 0xFF0D00FF);
					            gd.setColor(0xFF191919);
					            BOX1.setBackground(gd);
					        }
				        return false;
				    }
		});
		cancelTv.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				B.dismiss();
			}
		});
		confirmBg.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (!E1.getText().toString().equals("")) {
					B.dismiss();
					if (vpn()) {
					} else {
						CustomLoading.show(PrantoUsersDetailsActivity.this);
						IM_PRANTO = new HashMap<>();
						user = new HashMap<>();
						user.put("type", _Type);
						user.put("id", getIntent().getStringExtra("Id"));
						user.put("amount", E1.getText().toString());
						user.put("email", Auth.getString("Email", ""));
						user.put("session_id", Auth.getString("Session_id", ""));
						IM_PRANTO.put("X-IM-PRANTO", (new Object() {
							   int t;
							   public String toString() {
								      byte[] buf = new byte[22];
								      t = 5242880;
								      buf[0] = (byte) (t >>> 16);
								      t = 116736;
								      buf[1] = (byte) (t >>> 10);
								      t = 12713984;
								      buf[2] = (byte) (t >>> 17);
								      t = 28835840;
								      buf[3] = (byte) (t >>> 18);
								      t = 30408704;
								      buf[4] = (byte) (t >>> 18);
								      t = 56832;
								      buf[5] = (byte) (t >>> 9);
								      t = 3112960;
								      buf[6] = (byte) (t >>> 15);
								      t = 104857600;
								      buf[7] = (byte) (t >>> 21);
								      t = 100663296;
								      buf[8] = (byte) (t >>> 21);
								      t = 6291456;
								      buf[9] = (byte) (t >>> 17);
								      t = 230686720;
								      buf[10] = (byte) (t >>> 22);
								      t = 24320;
								      buf[11] = (byte) (t >>> 8);
								      t = 4928;
								      buf[12] = (byte) (t >>> 6);
								      t = 199229440;
								      buf[13] = (byte) (t >>> 21);
								      t = 1359872;
								      buf[14] = (byte) (t >>> 14);
								      t = 105906176;
								      buf[15] = (byte) (t >>> 20);
								      t = 25952256;
								      buf[16] = (byte) (t >>> 18);
								      t = 245366784;
								      buf[17] = (byte) (t >>> 21);
								      t = 478150656;
								      buf[18] = (byte) (t >>> 22);
								      t = 880803840;
								      buf[19] = (byte) (t >>> 23);
								      t = 14848;
								      buf[20] = (byte) (t >>> 7);
								      t = 7929856;
								      buf[21] = (byte) (t >>> 16);
								      return new String(buf);
								   }
						}.toString()));
						Update.setHeaders(IM_PRANTO);
						Update.setParams(user, RequestNetworkController.REQUEST_PARAM);
						Update.startRequestNetwork(RequestNetworkController.POST, app_infos.getString("Api", "").concat("users.php"), _Type, _Update_request_listener);
						user.clear();
						IM_PRANTO.clear();
					}
				}
			}
		});
		B.setCancelable(true);
		B.show();
	}
	
	public class TrxViewAdapter extends RecyclerView.Adapter<TrxViewAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public TrxViewAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.user_trx, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout BG1 = _view.findViewById(R.id.BG1);
			final LinearLayout div = _view.findViewById(R.id.div);
			final LinearLayout golBg = _view.findViewById(R.id.golBg);
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final TextView textview4 = _view.findViewById(R.id.textview4);
			
			textview1.setText(_data.get((int)_position).get("title").toString());
			textview3.setText(_data.get((int)_position).get("date").toString());
			if (_position < (_data.size() - 1)) {
				div.setVisibility(View.VISIBLE);
			} else {
				div.setVisibility(View.GONE);
			}
			if (_data.get((int)_position).get("type").toString().equals("Deposit")) {
				textview2.setText("Amount: ".concat(_data.get((int)_position).get("amount").toString().concat(" Tk")));
				golBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)90, 0x334CAF50));
				textview2.setTextColor(0xFF4CAF50);
				imageview1.setImageResource(R.drawable.icon_plus_round);
				if (_data.get((int)_position).get("status").toString().equals("0")) {
					textview4.setText("PENDING");
					textview4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFFFF9100, 0x33FF9100));
					textview4.setTextColor(0xFFFF9100);
				} else {
					if (_data.get((int)_position).get("status").toString().equals("1")) {
						textview4.setText("SUCCESS");
						textview4.setTextColor(0xFF4CAF50);
						textview4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFF4CAF50, 0x334CAF50));
					} else {
						if (_data.get((int)_position).get("status").toString().equals("2")) {
							textview4.setText("REJECTED");
							textview4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFFF44336, 0x33F44336));
							textview4.setTextColor(0xFFF44336);
						}
					}
				}
			} else {
				if (_data.get((int)_position).get("type").toString().equals("Withdraw")) {
					textview2.setText("Amount: ".concat(_data.get((int)_position).get("amount").toString().concat(" Tk")));
					golBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)90, 0x33F44336));
					textview2.setTextColor(0xFFF44336);
					imageview1.setImageResource(R.drawable.icon_arrow_upward_round);
					if (_data.get((int)_position).get("status").toString().equals("0")) {
						textview4.setText("PENDING");
						textview4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFFFF9100, 0x33FF9100));
						textview4.setTextColor(0xFFFF9100);
					} else {
						if (_data.get((int)_position).get("status").toString().equals("1")) {
							textview4.setText("SUCCESS");
							textview4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFF4CAF50, 0x334CAF50));
							textview4.setTextColor(0xFF4CAF50);
						} else {
							if (_data.get((int)_position).get("status").toString().equals("2")) {
								textview4.setText("REJECTED");
								textview4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFFF44336, 0x33F44336));
								textview4.setTextColor(0xFFF44336);
							}
						}
					}
				} else {
					if (_data.get((int)_position).get("type").toString().equals("Join")) {
						if (_data.get((int)_position).get("status").toString().equals("1")) {
							textview2.setText("Entry Fee: ".concat(_data.get((int)_position).get("amount").toString().concat(" Tk")));
							golBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)90, 0x330D00FF));
							textview2.setTextColor(0xFF0D00FF);
							imageview1.setImageResource(R.drawable.icon_gamepad_round);
							textview4.setText("JOINED");
							textview4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFF0D00FF, 0x330D00FF));
							textview4.setTextColor(0xFF0D00FF);
						} else {
							if (_data.get((int)_position).get("status").toString().equals("2")) {
								textview2.setText("Refunded: ".concat(_data.get((int)_position).get("amount").toString().concat(" Tk")));
								golBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)90, 0x33F44336));
								textview2.setTextColor(0xFFF44336);
								imageview1.setImageResource(R.drawable.icon_minus_round);
								textview4.setText("REFUND");
								textview4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFFF44336, 0x33F44336));
								textview4.setTextColor(0xFFF44336);
							}
						}
					} else {
						if (_data.get((int)_position).get("type").toString().equals("Reward")) {
							if (_data.get((int)_position).get("status").toString().equals("1")) {
								textview2.setText("Win : ".concat(_data.get((int)_position).get("amount").toString().concat(" Tk")));
								golBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)90, 0x334CAF50));
								textview2.setTextColor(0xFF4CAF50);
								imageview1.setImageResource(R.drawable.icon_plus_round);
								textview4.setText("RECEIVED");
								textview4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFF4CAF50, 0x334CAF50));
								textview4.setTextColor(0xFF4CAF50);
							} else {
								if (_data.get((int)_position).get("status").toString().equals("2")) {
									textview2.setText("Lost : ".concat(_data.get((int)_position).get("amount").toString().concat(" Tk")));
									golBg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)90, 0x33F44336));
									textview2.setTextColor(0xFFF44336);
									imageview1.setImageResource(R.drawable.icon_minus_round);
									textview4.setText("LOST");
									textview4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)2, 0xFFF44336, 0x33F44336));
									textview4.setTextColor(0xFFF44336);
								}
							}
						}
					}
				}
			}
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}